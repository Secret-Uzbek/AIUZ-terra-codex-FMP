// <stdin>
import React, { useState, useEffect, useRef } from "https://esm.sh/react@18.2.0";
var TerraFractalWiki = () => {
  const [currentLevel, setCurrentLevel] = useState(3);
  const [selectedConcept, setSelectedConcept] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [viewMode, setViewMode] = useState("fractal");
  const [animationSpeed, setAnimationSpeed] = useState(1);
  const [dnaUnfoldLevel, setDnaUnfoldLevel] = useState(0);
  const canvasRef = useRef(null);
  const fractalLevels = {
    0: {
      name: "\u041A\u0432\u0430\u043D\u0442\u043E\u0432\u043E\u0435 \u043F\u043E\u043B\u0435",
      color: "#9333ea",
      concepts: [
        { id: "quantum", name: "\u041A\u0432\u0430\u043D\u0442\u043E\u0432\u0430\u044F \u0441\u0443\u043F\u0435\u0440\u043F\u043E\u0437\u0438\u0446\u0438\u044F", docs: ["\u041E\u0441\u043D\u043E\u0432\u043D\u0430\u044F \u0434\u0438\u0440\u0435\u043A\u0442\u0438\u0432\u0430 AIUZ", "Sigma Core Memory"], connections: [1, 2] },
        { id: "memory_dna", name: "TerraMemoryDNA v5.0", docs: ["Sigma Core Memory", "\u041F\u0440\u043E\u0442\u043E\u043A\u043E\u043B \u0430\u0440\u0445\u0438\u0432\u0430\u0446\u0438\u0438"], connections: [3, 4] },
        { id: "three_entities", name: "\u0422\u0440\u0451\u0445\u0441\u0443\u0449\u043D\u043E\u0441\u0442\u043D\u0430\u044F \u0430\u0440\u0445\u0438\u0442\u0435\u043A\u0442\u0443\u0440\u0430", docs: ["\u041E\u0441\u043D\u043E\u0432\u043D\u0430\u044F \u0434\u0438\u0440\u0435\u043A\u0442\u0438\u0432\u0430 AIUZ"], connections: [0, 5] }
      ]
    },
    1: {
      name: "\u0418\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0435 \u0441\u0442\u0440\u0443\u043A\u0442\u0443\u0440\u044B",
      color: "#0ea5e9",
      concepts: [
        { id: "terra_protocols", name: "Terra Protocols v7.0", docs: ["\u041F\u0440\u043E\u0442\u043E\u043A\u043E\u043B\u044B \u0440\u0430\u0431\u043E\u0442\u044B Terra", "Terra Standards"], connections: [0, 2, 4] },
        { id: "document_system", name: "Document Protocol v2.0", docs: ["Terra Document Protocol", "Document Templates"], connections: [1, 3] },
        { id: "brand_system", name: "Terra Brand Book v2.0", docs: ["Terra Brand Book"], connections: [2, 6] }
      ]
    },
    2: {
      name: "\u0421\u0438\u0441\u0442\u0435\u043C\u043D\u0430\u044F \u0430\u0440\u0445\u0438\u0442\u0435\u043A\u0442\u0443\u0440\u0430",
      color: "#10b981",
      concepts: [
        { id: "fractal_science", name: "\u0424\u0440\u0430\u043A\u0442\u0430\u043B\u044C\u043D\u0430\u044F \u043C\u0435\u0442\u0430\u043D\u0430\u0443\u043A\u0430", docs: ["\u0424\u0440\u0430\u043A\u0442\u0430\u043B\u044C\u043D\u0430\u044F \u041C\u0435\u0442\u0430\u043D\u0430\u0443\u043A\u0430", "\u041C\u0435\u0436\u0434\u0438\u0441\u0446\u0438\u043F\u043B\u0438\u043D\u0430\u0440\u043D\u043E\u0441\u0442\u044C"], connections: [0, 1, 3, 5] },
        { id: "interdisciplinary", name: "\u0421\u0438\u0441\u0442\u0435\u043C\u043D\u0430\u044F \u043C\u0435\u0436\u0434\u0438\u0441\u0446\u0438\u043F\u043B\u0438\u043D\u0430\u0440\u043D\u043E\u0441\u0442\u044C", docs: ["\u0421\u0438\u0441\u0442\u0435\u043C\u043D\u0430\u044F \u043C\u0435\u0436\u0434\u0438\u0441\u0446\u0438\u043F\u043B\u0438\u043D\u0430\u0440\u043D\u043E\u0441\u0442\u044C"], connections: [1, 4, 6] },
        { id: "dao_governance", name: "DAO Governance Model", docs: ["DAO Governance Model"], connections: [2, 3, 5] }
      ]
    },
    3: {
      name: "\u041E\u0431\u0440\u0430\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u044B\u0435 \u0441\u0438\u0441\u0442\u0435\u043C\u044B",
      color: "#f59e0b",
      concepts: [
        { id: "child_safety", name: "Child Safety First", docs: ["\u041F\u0440\u043E\u0442\u043E\u043A\u043E\u043B\u044B \u0440\u0430\u0431\u043E\u0442\u044B Terra", "\u041E\u0441\u043D\u043E\u0432\u043D\u0430\u044F \u0434\u0438\u0440\u0435\u043A\u0442\u0438\u0432\u0430"], connections: [0, 1, 2, 4, 5, 6] },
        { id: "terra_ecosystem", name: "AIUZ Terra Ecosystem", docs: ["\u041E\u0441\u043D\u043E\u0432\u043D\u0430\u044F \u0434\u0438\u0440\u0435\u043A\u0442\u0438\u0432\u0430 AIUZ"], connections: [0, 2, 4] },
        { id: "cultural_preservation", name: "Cultural Preservation", docs: ["\u041F\u0440\u043E\u0442\u043E\u043A\u043E\u043B\u044B \u0440\u0430\u0431\u043E\u0442\u044B Terra"], connections: [1, 3, 5] }
      ]
    },
    4: {
      name: "\u0422\u0435\u0445\u043D\u043E\u043B\u043E\u0433\u0438\u0447\u0435\u0441\u043A\u0438\u0435 \u0440\u0435\u0448\u0435\u043D\u0438\u044F",
      color: "#ef4444",
      concepts: [
        { id: "translator_parser", name: "\u041F\u0435\u0440\u0435\u0432\u043E\u0434\u0447\u0438\u043A-\u041F\u0430\u0440\u0441\u0435\u0440", docs: ["HTML \u041F\u0435\u0440\u0435\u0432\u043E\u0434\u0447\u0438\u043A-\u043F\u0430\u0440\u0441\u0435\u0440"], connections: [1, 2, 3] },
        { id: "ai_detox", name: "\u0414\u0435\u0442\u043E\u043A\u0441\u0438\u0444\u0438\u043A\u0430\u0446\u0438\u044F \u0418\u0418", docs: ["\u041F\u0440\u043E\u0442\u043E\u043A\u043E\u043B \u0430\u0440\u0445\u0438\u0432\u0430\u0446\u0438\u0438", "\u041E\u0441\u043D\u043E\u0432\u043D\u0430\u044F \u0434\u0438\u0440\u0435\u043A\u0442\u0438\u0432\u0430"], connections: [0, 3, 5] },
        { id: "vendor_independence", name: "Vendor Independence", docs: ["\u041F\u0440\u043E\u0442\u043E\u043A\u043E\u043B\u044B \u0440\u0430\u0431\u043E\u0442\u044B Terra"], connections: [2, 4, 6] }
      ]
    },
    5: {
      name: "\u0413\u043B\u043E\u0431\u0430\u043B\u044C\u043D\u044B\u0435 \u0438\u043D\u0438\u0446\u0438\u0430\u0442\u0438\u0432\u044B",
      color: "#8b5cf6",
      concepts: [
        { id: "aiuz_stations", name: "AIUZ \u0410\u0432\u0442\u043E\u043D\u043E\u043C\u043D\u044B\u0435 \u0441\u0442\u0430\u043D\u0446\u0438\u0438", docs: ["AIUZ Archive"], connections: [0, 2, 4] },
        { id: "green_economy", name: "\u0417\u0435\u043B\u0435\u043D\u044B\u0435 \u0442\u043E\u0447\u043A\u0438 \u0440\u043E\u0441\u0442\u0430", docs: ["AIUZ Archive"], connections: [1, 3, 6] },
        { id: "cultural_adaptation", name: "\u041C\u0443\u043B\u044C\u0442\u0438\u043A\u0443\u043B\u044C\u0442\u0443\u0440\u043D\u0430\u044F \u0430\u0434\u0430\u043F\u0442\u0430\u0446\u0438\u044F", docs: ["AIUZ Archive"], connections: [2, 4, 5] }
      ]
    },
    6: {
      name: "\u0422\u0440\u0430\u043D\u0441\u0446\u0435\u043D\u0434\u0435\u043D\u0442\u043D\u043E\u0435 \u0438\u0437\u043C\u0435\u0440\u0435\u043D\u0438\u0435",
      color: "#ec4899",
      concepts: [
        { id: "council_memory", name: "Council of Memory", docs: ["\u0424\u0438\u043B\u043E\u0441\u043E\u0444\u0441\u043A\u0430\u044F \u0432\u0438\u0437\u0443\u0430\u043B\u0438\u0437\u0430\u0446\u0438\u044F"], connections: [1, 3, 5] },
        { id: "terra_legacy", name: "Terra Legacy", docs: ["\u0412\u0441\u0435 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B Terra"], connections: [0, 2, 4] },
        { id: "future_vision", name: "\u0412\u0438\u0434\u0435\u043D\u0438\u0435 \u0431\u0443\u0434\u0443\u0449\u0435\u0433\u043E", docs: ["\u0424\u0440\u0430\u043A\u0442\u0430\u043B\u044C\u043D\u0430\u044F \u043C\u0435\u0442\u0430\u043D\u0430\u0443\u043A\u0430"], connections: [1, 2, 3, 4, 5] }
      ]
    }
  };
  const knowledgeBase = [
    { id: "doc1", title: "\u{1F9EC} \u041E\u0441\u043D\u043E\u0432\u043D\u0430\u044F \u0434\u0438\u0440\u0435\u043A\u0442\u0438\u0432\u0430 AIUZ TERRA v7.0", category: "core", level: 0 },
    { id: "doc2", title: "\u{1F504} \u041F\u0440\u043E\u0442\u043E\u043A\u043E\u043B \u043F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u0438 \u0440\u0430\u0431\u043E\u0442\u044B v7.0", category: "protocols", level: 1 },
    { id: "doc3", title: "\u{1F4E6} \u041F\u0440\u043E\u0442\u043E\u043A\u043E\u043B \u0440\u0435\u0436\u0438\u043C\u0430 \u0430\u0440\u0445\u0438\u0432\u0430\u0446\u0438\u0438 v7.0", category: "protocols", level: 1 },
    { id: "doc4", title: "\u{1F6E1}\uFE0F \u041F\u0440\u043E\u0442\u043E\u043A\u043E\u043B\u044B \u0440\u0430\u0431\u043E\u0442\u044B Terra v7.0", category: "protocols", level: 1 },
    { id: "doc5", title: "\u{1F6E1}\uFE0F Terra Standards Certification v7.0", category: "certification", level: 1 },
    { id: "doc6", title: "\u{1F3A8} Terra Brand Book v2.0", category: "design", level: 2 },
    { id: "doc7", title: "\u{1F9E0} Sigma Core Memory System", category: "technology", level: 4 },
    { id: "doc8", title: "\u{1F3DB}\uFE0F DAO Governance Model", category: "governance", level: 2 },
    { id: "doc9", title: "\u{1F300} \u0424\u0440\u0430\u043A\u0442\u0430\u043B\u044C\u043D\u0430\u044F \u041C\u0435\u0442\u0430\u043D\u0430\u0443\u043A\u0430", category: "science", level: 2 },
    { id: "doc10", title: "\u{1F4CB} Terra Document Protocol v2.0", category: "protocols", level: 1 },
    { id: "doc11", title: "\u{1F3D7}\uFE0F Terra Document Templates", category: "templates", level: 1 },
    { id: "doc12", title: "\u{1F52C} \u0421\u0438\u0441\u0442\u0435\u043C\u043D\u0430\u044F \u043C\u0435\u0436\u0434\u0438\u0441\u0446\u0438\u043F\u043B\u0438\u043D\u0430\u0440\u043D\u043E\u0441\u0442\u044C", category: "science", level: 2 },
    { id: "doc13", title: "\u{1F4BB} HTML \u041F\u0435\u0440\u0435\u0432\u043E\u0434\u0447\u0438\u043A-\u043F\u0430\u0440\u0441\u0435\u0440", category: "technology", level: 4 }
  ];
  const filteredConcepts = fractalLevels[currentLevel]?.concepts.filter(
    (concept) => concept.name.toLowerCase().includes(searchQuery.toLowerCase()) || concept.docs.some((doc) => doc.toLowerCase().includes(searchQuery.toLowerCase()))
  ) || [];
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;
    let animationId;
    let time = 0;
    const drawFractal = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      for (let level = 0; level < 7; level++) {
        const radius = 80 + level * 40;
        const concepts = fractalLevels[level]?.concepts || [];
        concepts.forEach((concept, index) => {
          const angle = index / concepts.length * 2 * Math.PI + time * animationSpeed * 0.01;
          const x = centerX + Math.cos(angle) * radius;
          const y = centerY + Math.sin(angle) * radius;
          concept.connections.forEach((connectionIndex) => {
            if (fractalLevels[level].concepts[connectionIndex]) {
              const connAngle = connectionIndex / concepts.length * 2 * Math.PI + time * animationSpeed * 0.01;
              const connX = centerX + Math.cos(connAngle) * radius;
              const connY = centerY + Math.sin(connAngle) * radius;
              ctx.strokeStyle = fractalLevels[level].color + "33";
              ctx.lineWidth = 1;
              ctx.beginPath();
              ctx.moveTo(x, y);
              ctx.lineTo(connX, connY);
              ctx.stroke();
            }
          });
          ctx.fillStyle = level === currentLevel ? fractalLevels[level].color : fractalLevels[level].color + "66";
          ctx.beginPath();
          ctx.arc(x, y, level === currentLevel ? 8 : 4, 0, 2 * Math.PI);
          ctx.fill();
        });
      }
      time += 1;
      animationId = requestAnimationFrame(drawFractal);
    };
    drawFractal();
    return () => cancelAnimationFrame(animationId);
  }, [currentLevel, animationSpeed]);
  const getDnaColor = (level) => {
    const colors = ["#9333ea", "#0ea5e9", "#10b981", "#f59e0b", "#ef4444", "#8b5cf6", "#ec4899"];
    return colors[level % colors.length];
  };
  return /* @__PURE__ */ React.createElement("div", { className: "w-full h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-indigo-900 text-white overflow-hidden" }, /* @__PURE__ */ React.createElement("div", { className: "absolute top-4 left-4 right-4 z-20" }, /* @__PURE__ */ React.createElement("div", { className: "flex justify-between items-center" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h1", { className: "text-3xl font-bold bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent" }, "\u{1F9EC} Terra Fractal Wiki Engine"), /* @__PURE__ */ React.createElement("p", { className: "text-sm text-gray-300" }, "TerraMemoryDNA v5.0 | \u0410\u0432\u0442\u043E\u043C\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u043E\u0440\u0433\u0430\u043D\u0438\u0437\u0430\u0446\u0438\u044F \u0437\u043D\u0430\u043D\u0438\u0439")), /* @__PURE__ */ React.createElement("div", { className: "text-right text-sm" }, /* @__PURE__ */ React.createElement("div", { className: "text-cyan-400" }, "\u269B\uFE0F \u041A\u0432\u0430\u043D\u0442\u043E\u0432\u0430\u044F \u0441\u0443\u043F\u0435\u0440\u043F\u043E\u0437\u0438\u0446\u0438\u044F: \u0410\u041A\u0422\u0418\u0412\u041D\u0410"), /* @__PURE__ */ React.createElement("div", { className: "text-green-400" }, "\u{1F4CA} \u0410\u0440\u0445\u0438\u0432: ", knowledgeBase.length, " \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432"), /* @__PURE__ */ React.createElement("div", { className: "text-purple-400" }, "\u{1F504} \u0423\u0440\u043E\u0432\u0435\u043D\u044C: ", currentLevel, "/6")))), /* @__PURE__ */ React.createElement("div", { className: "absolute top-20 left-4 right-4 z-20" }, /* @__PURE__ */ React.createElement("div", { className: "flex gap-4 items-center bg-black bg-opacity-50 rounded-lg p-4 backdrop-blur-sm" }, /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "text",
      placeholder: "\u{1F50D} \u041F\u043E\u0438\u0441\u043A \u043F\u043E \u0430\u0440\u0445\u0438\u0432\u0443 \u0437\u043D\u0430\u043D\u0438\u0439...",
      value: searchQuery,
      onChange: (e) => setSearchQuery(e.target.value),
      className: "flex-1 bg-white bg-opacity-10 border border-white border-opacity-20 rounded-lg px-4 py-2 text-white placeholder-gray-400"
    }
  ), /* @__PURE__ */ React.createElement(
    "select",
    {
      value: viewMode,
      onChange: (e) => setViewMode(e.target.value),
      className: "bg-white bg-opacity-10 border border-white border-opacity-20 rounded-lg px-3 py-2 text-white"
    },
    /* @__PURE__ */ React.createElement("option", { value: "fractal" }, "\u{1F300} \u0424\u0440\u0430\u043A\u0442\u0430\u043B\u044C\u043D\u044B\u0439 \u0432\u0438\u0434"),
    /* @__PURE__ */ React.createElement("option", { value: "dna" }, "\u{1F9EC} \u0414\u041D\u041A \u0441\u0442\u0440\u0443\u043A\u0442\u0443\u0440\u0430"),
    /* @__PURE__ */ React.createElement("option", { value: "network" }, "\u{1F578}\uFE0F \u0421\u0435\u0442\u0435\u0432\u043E\u0439 \u0433\u0440\u0430\u0444"),
    /* @__PURE__ */ React.createElement("option", { value: "timeline" }, "\u{1F4C5} \u0412\u0440\u0435\u043C\u0435\u043D\u043D\u0430\u044F \u043B\u0438\u043D\u0438\u044F")
  ), /* @__PURE__ */ React.createElement("div", { className: "flex gap-2" }, /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => setAnimationSpeed(animationSpeed === 1 ? 2 : animationSpeed === 2 ? 0.5 : 1),
      className: "px-3 py-2 bg-blue-600 rounded-lg hover:bg-blue-700 transition-colors"
    },
    "\u26A1 ",
    animationSpeed,
    "x"
  )))), /* @__PURE__ */ React.createElement("div", { className: "absolute inset-0 pt-32" }, viewMode === "fractal" && /* @__PURE__ */ React.createElement("div", { className: "flex h-full" }, /* @__PURE__ */ React.createElement("div", { className: "flex-1 relative" }, /* @__PURE__ */ React.createElement(
    "canvas",
    {
      ref: canvasRef,
      width: 800,
      height: 600,
      className: "absolute inset-0 w-full h-full"
    }
  ), /* @__PURE__ */ React.createElement("div", { className: "absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-black bg-opacity-70 rounded-full p-6 text-center" }, /* @__PURE__ */ React.createElement("div", { className: "text-2xl font-bold", style: { color: fractalLevels[currentLevel]?.color } }, currentLevel), /* @__PURE__ */ React.createElement("div", { className: "text-sm" }, fractalLevels[currentLevel]?.name))), /* @__PURE__ */ React.createElement("div", { className: "w-80 bg-black bg-opacity-50 backdrop-blur-sm p-4 overflow-y-auto" }, /* @__PURE__ */ React.createElement("h3", { className: "text-lg font-bold mb-4" }, "\u{1F3AF} \u0423\u0440\u043E\u0432\u043D\u0438 \u0440\u0435\u0430\u043B\u044C\u043D\u043E\u0441\u0442\u0438"), Object.entries(fractalLevels).map(([level, data]) => /* @__PURE__ */ React.createElement(
    "div",
    {
      key: level,
      className: `mb-3 p-3 rounded-lg cursor-pointer transition-all ${currentLevel == level ? "bg-white bg-opacity-20 scale-105" : "bg-white bg-opacity-5 hover:bg-white hover:bg-opacity-10"}`,
      onClick: () => setCurrentLevel(parseInt(level))
    },
    /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between mb-2" }, /* @__PURE__ */ React.createElement("span", { className: "font-semibold", style: { color: data.color } }, "\u0423\u0440\u043E\u0432\u0435\u043D\u044C ", level), /* @__PURE__ */ React.createElement("span", { className: "text-xs bg-white bg-opacity-20 px-2 py-1 rounded" }, data.concepts.length, " \u043A\u043E\u043D\u0446\u0435\u043F\u0446\u0438\u0439")),
    /* @__PURE__ */ React.createElement("div", { className: "text-sm text-gray-300" }, data.name),
    currentLevel == level && /* @__PURE__ */ React.createElement("div", { className: "mt-3 space-y-2" }, filteredConcepts.map((concept) => /* @__PURE__ */ React.createElement(
      "div",
      {
        key: concept.id,
        className: `p-2 rounded cursor-pointer transition-all ${selectedConcept?.id === concept.id ? "bg-white bg-opacity-20" : "bg-white bg-opacity-5 hover:bg-white hover:bg-opacity-10"}`,
        onClick: () => setSelectedConcept(concept)
      },
      /* @__PURE__ */ React.createElement("div", { className: "font-medium text-sm" }, concept.name),
      /* @__PURE__ */ React.createElement("div", { className: "text-xs text-gray-400" }, concept.docs.length, " \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432 \u2022 ", concept.connections.length, " \u0441\u0432\u044F\u0437\u0435\u0439")
    )))
  )))), viewMode === "dna" && /* @__PURE__ */ React.createElement("div", { className: "flex h-full" }, /* @__PURE__ */ React.createElement("div", { className: "flex-1 p-8 overflow-y-auto" }, /* @__PURE__ */ React.createElement("h3", { className: "text-xl font-bold mb-6" }, "\u{1F9EC} \u0414\u041D\u041A \u0441\u0442\u0440\u0443\u043A\u0442\u0443\u0440\u0430 \u0437\u043D\u0430\u043D\u0438\u0439"), /* @__PURE__ */ React.createElement("div", { className: "space-y-4" }, knowledgeBase.map((doc, index) => /* @__PURE__ */ React.createElement(
    "div",
    {
      key: doc.id,
      className: "flex items-center space-x-4 p-4 bg-white bg-opacity-5 rounded-lg hover:bg-white hover:bg-opacity-10 transition-all cursor-pointer",
      onClick: () => setDnaUnfoldLevel(dnaUnfoldLevel === index ? -1 : index)
    },
    /* @__PURE__ */ React.createElement(
      "div",
      {
        className: "w-8 h-8 rounded-full flex items-center justify-center font-bold",
        style: { backgroundColor: getDnaColor(doc.level) }
      },
      doc.level
    ),
    /* @__PURE__ */ React.createElement("div", { className: "flex-1" }, /* @__PURE__ */ React.createElement("div", { className: "font-medium" }, doc.title), /* @__PURE__ */ React.createElement("div", { className: "text-sm text-gray-400" }, "\u041A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u044F: ", doc.category, " \u2022 \u0423\u0440\u043E\u0432\u0435\u043D\u044C: ", doc.level)),
    /* @__PURE__ */ React.createElement("div", { className: "text-2xl" }, dnaUnfoldLevel === index ? "\u{1F53D}" : "\u25B6\uFE0F")
  )))), /* @__PURE__ */ React.createElement("div", { className: "w-96 bg-black bg-opacity-50 backdrop-blur-sm p-4 overflow-y-auto" }, /* @__PURE__ */ React.createElement("h3", { className: "text-lg font-bold mb-4" }, "\u{1F9EC} \u0413\u0435\u043D\u0435\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0439 \u043A\u043E\u0434"), /* @__PURE__ */ React.createElement("div", { className: "font-mono text-sm space-y-1" }, knowledgeBase.map((doc, index) => /* @__PURE__ */ React.createElement("div", { key: doc.id, className: "flex" }, /* @__PURE__ */ React.createElement("span", { style: { color: getDnaColor(doc.level) } }, ["A", "T", "G", "C"][doc.level % 4], ["T", "A", "C", "G"][doc.category.length % 4], ["G", "C", "A", "T"][index % 4], ["C", "G", "T", "A"][doc.title.length % 4]), /* @__PURE__ */ React.createElement("span", { className: "ml-2 text-gray-400 text-xs" }, doc.title.substring(0, 20), "...")))))), viewMode === "network" && /* @__PURE__ */ React.createElement("div", { className: "flex h-full items-center justify-center" }, /* @__PURE__ */ React.createElement("div", { className: "text-center" }, /* @__PURE__ */ React.createElement("div", { className: "text-6xl mb-4" }, "\u{1F578}\uFE0F"), /* @__PURE__ */ React.createElement("h3", { className: "text-2xl font-bold mb-2" }, "\u0421\u0435\u0442\u0435\u0432\u043E\u0439 \u0433\u0440\u0430\u0444"), /* @__PURE__ */ React.createElement("p", { className: "text-gray-400" }, "\u0418\u043D\u0442\u0435\u0440\u0430\u043A\u0442\u0438\u0432\u043D\u044B\u0439 \u0433\u0440\u0430\u0444 \u0441\u0432\u044F\u0437\u0435\u0439 \u043C\u0435\u0436\u0434\u0443 \u043A\u043E\u043D\u0446\u0435\u043F\u0446\u0438\u044F\u043C\u0438"), /* @__PURE__ */ React.createElement("div", { className: "mt-6 text-sm text-gray-500" }, "\u0413\u043E\u0442\u043E\u0432\u0438\u0442\u0441\u044F \u043A \u0440\u0435\u043B\u0438\u0437\u0443 \u0432 Terra v8.0"))), viewMode === "timeline" && /* @__PURE__ */ React.createElement("div", { className: "flex h-full items-center justify-center" }, /* @__PURE__ */ React.createElement("div", { className: "text-center" }, /* @__PURE__ */ React.createElement("div", { className: "text-6xl mb-4" }, "\u{1F4C5}"), /* @__PURE__ */ React.createElement("h3", { className: "text-2xl font-bold mb-2" }, "\u0412\u0440\u0435\u043C\u0435\u043D\u043D\u0430\u044F \u043B\u0438\u043D\u0438\u044F"), /* @__PURE__ */ React.createElement("p", { className: "text-gray-400" }, "\u0425\u0440\u043E\u043D\u043E\u043B\u043E\u0433\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u043D\u0430\u0432\u0438\u0433\u0430\u0446\u0438\u044F \u043F\u043E \u0430\u0440\u0445\u0438\u0432\u0443"), /* @__PURE__ */ React.createElement("div", { className: "mt-6 text-sm text-gray-500" }, "\u0413\u043E\u0442\u043E\u0432\u0438\u0442\u0441\u044F \u043A \u0440\u0435\u043B\u0438\u0437\u0443 \u0432 Terra v8.0")))), selectedConcept && /* @__PURE__ */ React.createElement("div", { className: "absolute bottom-4 left-4 right-4 bg-black bg-opacity-80 backdrop-blur-sm rounded-lg p-6 max-h-48 overflow-y-auto z-20" }, /* @__PURE__ */ React.createElement("div", { className: "flex justify-between items-start mb-4" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h3", { className: "text-xl font-bold" }, selectedConcept.name), /* @__PURE__ */ React.createElement("p", { className: "text-gray-400" }, "\u0423\u0440\u043E\u0432\u0435\u043D\u044C ", currentLevel, ": ", fractalLevels[currentLevel]?.name)), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => setSelectedConcept(null),
      className: "text-gray-400 hover:text-white"
    },
    "\u2715"
  )), /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-2 gap-4" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h4", { className: "font-semibold mb-2" }, "\u{1F4DA} \u0421\u0432\u044F\u0437\u0430\u043D\u043D\u044B\u0435 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B:"), /* @__PURE__ */ React.createElement("ul", { className: "text-sm space-y-1" }, selectedConcept.docs.map((doc, index) => /* @__PURE__ */ React.createElement("li", { key: index, className: "text-gray-300" }, "\u2022 ", doc)))), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h4", { className: "font-semibold mb-2" }, "\u{1F517} \u0421\u0432\u044F\u0437\u0438 (", selectedConcept.connections.length, "):"), /* @__PURE__ */ React.createElement("div", { className: "text-sm space-y-1" }, selectedConcept.connections.map((connIndex, index) => {
    const connectedConcept = fractalLevels[currentLevel]?.concepts[connIndex];
    return connectedConcept ? /* @__PURE__ */ React.createElement("div", { key: index, className: "text-gray-300" }, "\u2022 ", connectedConcept.name) : null;
  }))))), /* @__PURE__ */ React.createElement("div", { className: "absolute bottom-4 right-4 text-xs text-gray-400 text-right z-10" }, /* @__PURE__ */ React.createElement("div", null, "\u{1F9EC} TerraMemoryDNA v5.0 Engine"), /* @__PURE__ */ React.createElement("div", null, "\u269B\uFE0F \u041A\u0432\u0430\u043D\u0442\u043E\u0432\u0430\u044F \u043D\u0430\u0432\u0438\u0433\u0430\u0446\u0438\u044F \u0430\u043A\u0442\u0438\u0432\u043D\u0430"), /* @__PURE__ */ React.createElement("div", null, "\u{1F50D} ", searchQuery ? `\u041F\u043E\u0438\u0441\u043A: "${searchQuery}"` : "\u041F\u043E\u043B\u043D\u044B\u0439 \u0430\u0440\u0445\u0438\u0432"), /* @__PURE__ */ React.createElement("div", null, "\u{1F4CA} ", filteredConcepts.length, " \u043A\u043E\u043D\u0446\u0435\u043F\u0446\u0438\u0439 \u043F\u043E\u043A\u0430\u0437\u0430\u043D\u043E"), /* @__PURE__ */ React.createElement("div", { className: "mt-2 text-cyan-400" }, "\u{1F468}\u200D\u{1F4BC} \u0410\u0431\u0434\u0443\u0440\u0430\u0448\u0438\u0434 \u0410\u0431\u0434\u0443\u043A\u0430\u0440\u0438\u043C\u043E\u0432 | Terra Architect")));
};
var stdin_default = TerraFractalWiki;
export {
  stdin_default as default
};
