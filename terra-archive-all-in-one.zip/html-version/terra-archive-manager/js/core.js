const archiveList = JSON.parse(localStorage.getItem('terraArchives')) || [];
const archiveListElement = document.getElementById('archiveList');
const statusMessage = document.getElementById('statusMessage');

function renderArchives() {
  archiveListElement.innerHTML = '';
  archiveList.forEach((item, index) => {
    const li = document.createElement('li');
    li.textContent = `[${index + 1}] ${item.title || "Без названия"} — ${item.date}`;
    archiveListElement.appendChild(li);
  });
}

function archiveInput() {
  const fileInput = document.getElementById('fileInput');
  const textInput = document.getElementById('textInput').value.trim();

  if (fileInput.files.length > 0) {
    for (const file of fileInput.files) {
      const reader = new FileReader();
      reader.onload = function (e) {
        saveArchive(file.name, e.target.result);
      };
      reader.readAsText(file);
    }
    statusMessage.textContent = `Загружено файлов: ${fileInput.files.length}`;
  } else if (textInput !== '') {
    saveArchive('Вставленный текст', textInput);
    statusMessage.textContent = `Архивировано: текст`;
  } else {
    statusMessage.textContent = 'Нет данных для архивации.';
  }

  setTimeout(() => statusMessage.textContent = '', 3000);
}

function saveArchive(title, content) {
  const date = new Date().toLocaleString();
  archiveList.push({ title, content, date });
  localStorage.setItem('terraArchives', JSON.stringify(archiveList));
  renderArchives();
}

document.addEventListener('DOMContentLoaded', renderArchives);
