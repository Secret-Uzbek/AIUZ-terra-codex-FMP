const thesaurusData = {
  "архив": ["сборник", "хранилище", "коллекция", "документы"],
  "память": ["воспоминание", "знание", "запоминание", "сознание"],
  "терра": ["земля", "основа", "фундамент", "ядро"]
};

function lookupTerm() {
  const term = document.getElementById('searchTerm').value.trim().toLowerCase();
  const output = document.getElementById('thesaurusOutput');
  const synonyms = thesaurusData[term];

  if (synonyms) {
    output.textContent = `🔍 ${term}:
- ${synonyms.join('\n- ')}`;
  } else {
    output.textContent = 'Нет данных. Попробуйте запрос к Википедии...';
    queryWikipedia(term);
  }
}
