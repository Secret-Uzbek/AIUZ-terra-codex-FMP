function queryWikipedia(term) {
  const apiURL = `https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(term)}`;
  fetch(apiURL)
    .then(res => res.ok ? res.json() : Promise.reject(res.status))
    .then(data => {
      document.getElementById('externalOutput').textContent =
        `🌐 Wikipedia:\n${data.extract || "Нет описания."}`;
    })
    .catch(() => {
      document.getElementById('externalOutput').textContent =
        "Не удалось подключиться к Wikipedia.";
    });
}

function queryWikidataLabel(term) {
  const sparqlQuery = `
    SELECT ?item ?itemLabel WHERE {
      ?item rdfs:label "${term}"@en.
      SERVICE wikibase:label { bd:serviceParam wikibase:language "[AUTO_LANGUAGE],en". }
    } LIMIT 1
  `;
  const endpoint = "https://query.wikidata.org/sparql";
  const fullURL = endpoint + "?format=json&query=" + encodeURIComponent(sparqlQuery);

  fetch(fullURL)
    .then(res => res.json())
    .then(data => {
      const bindings = data.results.bindings;
      if (bindings.length > 0) {
        const label = bindings[0].itemLabel.value;
        document.getElementById('externalOutput').textContent += `\n🌐 Wikidata:\n${label}`;
      }
    })
    .catch(() => {
      document.getElementById('externalOutput').textContent += `\nОшибка Wikidata`;
    });
}
