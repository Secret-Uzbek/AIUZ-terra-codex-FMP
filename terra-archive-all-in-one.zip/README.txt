Terra Archive Manager — ALL-IN-ONE PACK

Содержимое:
- html-version/  → обычная HTML-версия, запускается в браузере без установки
- react-version/ → версия на React, тоже работает локально
- offline-ready, AI-enhanced, license-safe, child-friendly

Открыть: index.html из любой папки.

Собрано Code GPT специально для Terra Ecosystem.
