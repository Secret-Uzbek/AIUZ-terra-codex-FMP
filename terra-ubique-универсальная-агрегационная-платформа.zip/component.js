// <stdin>
import React, { useState, useEffect } from "https://esm.sh/react@18.2.0";
import { Search, MapPin, Truck, Briefcase, Home, Settings, Star, Filter, Globe, Shield, Zap, Users, Clock, Package, Phone, Mail, ChevronRight, Menu, X, Heart, Eye } from "https://esm.sh/lucide-react?deps=react@18.2.0,react-dom@18.2.0";
var { useStoredState, useUser } = hatch;
var TerraUbique = () => {
  const [activeCategory, setActiveCategory] = useStoredState("activeCategory", "logistics");
  const [searchQuery, setSearchQuery] = useStoredState("searchQuery", "");
  const [userLocation, setUserLocation] = useStoredState("userLocation", "\u0422\u0430\u0448\u043A\u0435\u043D\u0442");
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [favorites, setFavorites] = useStoredState("favorites", []);
  const [recentViews, setRecentViews] = useStoredState("recentViews", []);
  const user = useUser();
  const categories = {
    logistics: {
      name: "\u041B\u043E\u0433\u0438\u0441\u0442\u0438\u043A\u0430",
      icon: Truck,
      color: "bg-blue-500",
      description: "\u0413\u0440\u0443\u0437\u043E\u043F\u0435\u0440\u0435\u0432\u043E\u0437\u043A\u0438, \u0434\u043E\u0441\u0442\u0430\u0432\u043A\u0430, \u044D\u043A\u0441\u043F\u0435\u0434\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0435",
      subcategories: ["\u0413\u0440\u0443\u0437\u043E\u043F\u0435\u0440\u0435\u0432\u043E\u0437\u043A\u0438", "\u041A\u0443\u0440\u044C\u0435\u0440\u0441\u043A\u0430\u044F \u0434\u043E\u0441\u0442\u0430\u0432\u043A\u0430", "\u041C\u0435\u0436\u0434\u0443\u043D\u0430\u0440\u043E\u0434\u043D\u044B\u0435 \u043F\u0435\u0440\u0435\u0432\u043E\u0437\u043A\u0438", "\u0421\u043A\u043B\u0430\u0434\u0441\u043A\u0438\u0435 \u0443\u0441\u043B\u0443\u0433\u0438"]
    },
    jobs: {
      name: "\u0420\u0430\u0431\u043E\u0442\u0430",
      icon: Briefcase,
      color: "bg-green-500",
      description: "\u0412\u0430\u043A\u0430\u043D\u0441\u0438\u0438, \u0444\u0440\u0438\u043B\u0430\u043D\u0441, \u0430\u0443\u0442\u0441\u043E\u0440\u0441\u0438\u043D\u0433",
      subcategories: ["\u041F\u043E\u0441\u0442\u043E\u044F\u043D\u043D\u0430\u044F \u0440\u0430\u0431\u043E\u0442\u0430", "\u0412\u0440\u0435\u043C\u0435\u043D\u043D\u0430\u044F \u0440\u0430\u0431\u043E\u0442\u0430", "\u0424\u0440\u0438\u043B\u0430\u043D\u0441", "\u0423\u0434\u0430\u043B\u0435\u043D\u043D\u0430\u044F \u0440\u0430\u0431\u043E\u0442\u0430"]
    },
    equipment: {
      name: "\u0422\u0435\u0445\u043D\u0438\u043A\u0430",
      icon: Settings,
      color: "bg-orange-500",
      description: "\u0410\u0440\u0435\u043D\u0434\u0430 \u0442\u0435\u0445\u043D\u0438\u043A\u0438, \u0438\u043D\u0441\u0442\u0440\u0443\u043C\u0435\u043D\u0442\u043E\u0432, \u043E\u0431\u043E\u0440\u0443\u0434\u043E\u0432\u0430\u043D\u0438\u044F",
      subcategories: ["\u0421\u0442\u0440\u043E\u0438\u0442\u0435\u043B\u044C\u043D\u0430\u044F \u0442\u0435\u0445\u043D\u0438\u043A\u0430", "\u0421\u0435\u043B\u044C\u0445\u043E\u0437\u0442\u0435\u0445\u043D\u0438\u043A\u0430", "\u0418\u043D\u0441\u0442\u0440\u0443\u043C\u0435\u043D\u0442\u044B", "\u041F\u0440\u043E\u043C\u044B\u0448\u043B\u0435\u043D\u043D\u043E\u0435 \u043E\u0431\u043E\u0440\u0443\u0434\u043E\u0432\u0430\u043D\u0438\u0435"]
    },
    services: {
      name: "\u0423\u0441\u043B\u0443\u0433\u0438",
      icon: Users,
      color: "bg-purple-500",
      description: "\u041F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0435 \u0438 \u0431\u044B\u0442\u043E\u0432\u044B\u0435 \u0443\u0441\u043B\u0443\u0433\u0438",
      subcategories: ["\u0420\u0435\u043C\u043E\u043D\u0442 \u0438 \u0441\u0442\u0440\u043E\u0438\u0442\u0435\u043B\u044C\u0441\u0442\u0432\u043E", "\u0423\u0431\u043E\u0440\u043A\u0430", "IT-\u0443\u0441\u043B\u0443\u0433\u0438", "\u041A\u043E\u043D\u0441\u0430\u043B\u0442\u0438\u043D\u0433"]
    },
    rental: {
      name: "\u0410\u0440\u0435\u043D\u0434\u0430",
      icon: Home,
      color: "bg-pink-500",
      description: "\u041D\u0435\u0434\u0432\u0438\u0436\u0438\u043C\u043E\u0441\u0442\u044C, \u0442\u0440\u0430\u043D\u0441\u043F\u043E\u0440\u0442, \u043E\u0441\u043E\u0431\u044B\u0435 \u043E\u0431\u044A\u0435\u043A\u0442\u044B",
      subcategories: ["\u041D\u0435\u0434\u0432\u0438\u0436\u0438\u043C\u043E\u0441\u0442\u044C", "\u0410\u0432\u0442\u043E\u043C\u043E\u0431\u0438\u043B\u0438", "\u0421\u043F\u0435\u0446\u0442\u0440\u0430\u043D\u0441\u043F\u043E\u0440\u0442", "\u0423\u043D\u0438\u043A\u0430\u043B\u044C\u043D\u044B\u0435 \u043E\u0431\u044A\u0435\u043A\u0442\u044B"]
    }
  };
  const officialDataSources = {
    government: {
      portal: "https://gov.uz/oz",
      // Официальный государственный портал РУз
      description: "\u0422\u0440\u0451\u0445\u044A\u044F\u0437\u044B\u0447\u043D\u044B\u0439 \u043F\u043E\u0440\u0442\u0430\u043B (\u0443\u0437\u0431/\u0440\u0443\u0441/\u0430\u043D\u0433\u043B)",
      apiEndpoints: [
        "/api/transport/statistics",
        "/api/logistics/corridors",
        "/api/business/registry"
      ]
    },
    legal: {
      portal: "https://lex.uz/uz/",
      description: "\u041C\u0438\u043D\u044E\u0441\u0442 - \u0442\u0435\u043A\u0441\u0442\u044B \u0437\u0430\u043A\u043E\u043D\u043E\u0432 \u0438 \u0430\u043A\u0442\u043E\u0432",
      apiEndpoints: [
        "/api/transport/regulations",
        "/api/business/legislation",
        "/api/customs/procedures"
      ]
    },
    transport: {
      railways: "\u0423\u0437\u0431\u0435\u043A\u0438\u0441\u0442\u043E\u043D \u0422\u0435\u043C\u0438\u0440 \u0419\u0443\u043B\u043B\u0430\u0440\u0438",
      highways: "\u0410\u0432\u0442\u043E\u0434\u043E\u0440 \u0423\u0437\u0431\u0435\u043A\u0438\u0441\u0442\u0430\u043D",
      aviation: "\u0423\u0437\u0431\u0435\u043A\u0438\u0441\u0442\u043E\u043D \u0425\u0430\u0432\u043E \u0419\u0443\u043B\u043B\u0430\u0440\u0438",
      statistics: {
        trucks: "26,000 \u0444\u0443\u0440 \u0434\u043E 20\u0442",
        totalVehicles: "240,917 \u0433\u0440\u0443\u0437\u043E\u0432\u044B\u0445 (\u0444\u0438\u0437\u043B\u0438\u0446\u0430)",
        dominance: "90.8% \u0430\u0432\u0442\u043E\u0442\u0440\u0430\u043D\u0441\u043F\u043E\u0440\u0442",
        railwayLength: "4000+ \u043A\u043C",
        corridors: ["TRACECA", "CAREC", "SCO"]
      }
    },
    logistics: {
      centers: ["\u041D\u0430\u0432\u043E\u0438 \u0425\u0430\u0431", "\u0410\u043D\u0433\u0440\u0435\u043D \u041B\u043E\u0433\u0438\u0441\u0442\u0438\u043A", "\u0422\u0430\u0448\u043A\u0435\u043D\u0442 \u041C\u0426\u041B"],
      corridors: {
        carec2a: "\u0410\u0441\u0442\u0440\u0430\u0445\u0430\u043D\u044C\u2013\u0411\u0435\u0439\u043D\u0435\u0443\u2013\u0411\u0443\u0445\u0430\u0440\u0430\u2013\u0422\u0430\u0448\u043A\u0435\u043D\u0442\u2013\u0410\u043D\u0434\u0438\u0436\u0430\u043D\u2013\u041E\u0448\u2013\u0418\u0440\u043A\u0435\u0448\u0442\u0430\u043C",
        carec6a: "\u0410\u0441\u0442\u0440\u0430\u0445\u0430\u043D\u044C\u2013\u0411\u0435\u0439\u043D\u0435\u0443\u2013\u0411\u0443\u0445\u0430\u0440\u0430\u2013\u0413\u0443\u0437\u0430\u0440\u2013\u0425\u0430\u0439\u0440\u0430\u0442\u043E\u043D\u2013\u041C\u0430\u0437\u0430\u0440-\u0438-\u0428\u0430\u0440\u0438\u0444",
        afghanistan: "\u0422\u0435\u0440\u043C\u0435\u0437\u2013\u041C\u0430\u0437\u0430\u0440\u0438-\u0428\u0430\u0440\u0438\u0444\u2013\u0413\u0435\u0440\u0430\u0442\u2013\u0411\u0430\u043D\u0434\u0430\u0440-\u0410\u0431\u0431\u0430\u0441"
      }
    }
  };
  const mockListings = {
    logistics: [
      {
        id: 1,
        title: "\u0413\u0440\u0443\u0437\u043E\u043F\u0435\u0440\u0435\u0432\u043E\u0437\u043A\u0438 \u043F\u043E CAREC \u043A\u043E\u0440\u0438\u0434\u043E\u0440\u0430\u043C",
        provider: "\u0423\u0437\u0431\u0435\u043A\u0438\u0441\u0442\u043E\u043D \u0422\u0435\u043C\u0438\u0440 \u0419\u0443\u043B\u043B\u0430\u0440\u0438 (\u0441\u0435\u0440\u0442\u0438\u0444\u0438\u0446\u0438\u0440\u043E\u0432\u0430\u043D\u043E)",
        price: "\u043E\u0442 45,000 \u0441\u0443\u043C/\u043A\u043C",
        rating: 4.9,
        verified: true,
        governmentApproved: true,
        location: "\u0422\u0430\u0448\u043A\u0435\u043D\u0442",
        description: "\u0416\u0435\u043B\u0435\u0437\u043D\u043E\u0434\u043E\u0440\u043E\u0436\u043D\u044B\u0435 \u043F\u0435\u0440\u0435\u0432\u043E\u0437\u043A\u0438 \u043F\u043E \u043C\u0435\u0436\u0434\u0443\u043D\u0430\u0440\u043E\u0434\u043D\u044B\u043C \u043A\u043E\u0440\u0438\u0434\u043E\u0440\u0430\u043C \u0426\u0410\u0420\u042D\u0421",
        features: ["CAREC 2a/2b/6a \u043A\u043E\u0440\u0438\u0434\u043E\u0440\u044B", "\u0413\u043E\u0441\u0443\u0434\u0430\u0440\u0441\u0442\u0432\u0435\u043D\u043D\u0430\u044F \u0432\u0435\u0440\u0438\u0444\u0438\u043A\u0430\u0446\u0438\u044F", "\u041C\u0414\u041F \u043A\u043D\u0438\u0436\u043A\u0438", "ISO 9001:2008"],
        officialSource: "gov.uz/transport"
      },
      {
        id: 2,
        title: "\u0410\u0432\u0438\u0430\u0445\u0430\u0431 \u041D\u0430\u0432\u043E\u0438 - \u043C\u0443\u043B\u044C\u0442\u0438\u043C\u043E\u0434\u0430\u043B\u044C\u043D\u0430\u044F \u043B\u043E\u0433\u0438\u0441\u0442\u0438\u043A\u0430",
        provider: "Navoi International Airport Hub",
        price: "\u043E\u0442 $4.50/\u043A\u0433",
        rating: 4.8,
        verified: true,
        governmentApproved: true,
        location: "\u041D\u0430\u0432\u043E\u0438",
        description: "\u041C\u0435\u0436\u0434\u0443\u043D\u0430\u0440\u043E\u0434\u043D\u044B\u0439 \u043C\u0443\u043B\u044C\u0442\u0438\u043C\u043E\u0434\u0430\u043B\u044C\u043D\u044B\u0439 \u0446\u0435\u043D\u0442\u0440 - \u043A\u0440\u0443\u043F\u043D\u0435\u0439\u0448\u0438\u0439 \u0432 \u0426\u0435\u043D\u0442\u0440\u0430\u043B\u044C\u043D\u043E\u0439 \u0410\u0437\u0438\u0438",
        features: ["60,000 \u0442\u043E\u043D\u043D/\u0433\u043E\u0434 \u0433\u0440\u0443\u0437\u043E\u043E\u0431\u043E\u0440\u043E\u0442", "\u0415\u0432\u0440\u043E\u043F\u0430-\u0410\u0437\u0438\u044F \u043C\u0430\u0440\u0448\u0440\u0443\u0442\u044B", "\u0422\u0430\u043C\u043E\u0436\u0435\u043D\u043D\u0430\u044F \u0437\u043E\u043D\u0430", "\u0418\u043D\u0442\u0435\u0433\u0440\u0430\u0446\u0438\u044F \u0436/\u0434+\u0430\u0432\u0442\u043E+\u0430\u0432\u0438\u0430"],
        officialSource: "gov.uz/aviation"
      },
      {
        id: 3,
        title: "AIRCUZ - \u041C\u0435\u0436\u0434\u0443\u043D\u0430\u0440\u043E\u0434\u043D\u044B\u0435 \u0430\u0432\u0442\u043E\u043F\u0435\u0440\u0435\u0432\u043E\u0437\u043A\u0438",
        provider: "\u0410\u0441\u0441\u043E\u0446\u0438\u0430\u0446\u0438\u044F \u043C\u0435\u0436\u0434\u0443\u043D\u0430\u0440\u043E\u0434\u043D\u044B\u0445 \u0430\u0432\u0442\u043E\u043F\u0435\u0440\u0435\u0432\u043E\u0437\u0447\u0438\u043A\u043E\u0432",
        price: "\u043E\u0442 75,000 \u0441\u0443\u043C/\u043A\u043C",
        rating: 4.7,
        verified: true,
        governmentApproved: true,
        location: "\u0420\u0435\u0441\u043F\u0443\u0431\u043B\u0438\u043A\u0430 \u0423\u0437\u0431\u0435\u043A\u0438\u0441\u0442\u0430\u043D",
        description: "\u041E\u0444\u0438\u0446\u0438\u0430\u043B\u044C\u043D\u0430\u044F \u0430\u0441\u0441\u043E\u0446\u0438\u0430\u0446\u0438\u044F 130+ \u043A\u043E\u043C\u043F\u0430\u043D\u0438\u0439 \u0441 \u041C\u0414\u041F \u0433\u0430\u0440\u0430\u043D\u0442\u0438\u044F\u043C\u0438",
        features: ["12,632 \u043A\u043D\u0438\u0436\u043A\u0438 \u041C\u0414\u041F (2011)", "280,000 \u0442\u043E\u043D\u043D \u0433\u0440\u0443\u0437\u043E\u043E\u0431\u043E\u0440\u043E\u0442", "\u041C\u0421\u0410\u0422 \u0447\u043B\u0435\u043D\u0441\u0442\u0432\u043E", "\u0424\u0410\u041F\u042D \u0426\u0410\u0420\u042D\u0421"],
        officialSource: "aircuz.uz"
      },
      {
        id: 4,
        title: "\u0422\u0440\u0430\u043D\u0441\u0430\u0444\u0433\u0430\u043D\u0441\u043A\u0438\u0439 \u043A\u043E\u0440\u0438\u0434\u043E\u0440 \u0422\u0435\u0440\u043C\u0435\u0437-\u0413\u0435\u0440\u0430\u0442",
        provider: "\u0421\u043F\u0435\u0446\u0438\u0430\u043B\u044C\u043D\u0430\u044F \u0438\u043D\u0434\u0443\u0441\u0442\u0440\u0438\u0430\u043B\u044C\u043D\u0430\u044F \u0437\u043E\u043D\u0430 \u0425\u0430\u0439\u0440\u0430\u0442\u043E\u043D",
        price: "\u043E\u0442 $3.20/\u043A\u043C",
        rating: 4.6,
        verified: true,
        governmentApproved: true,
        location: "\u0422\u0435\u0440\u043C\u0435\u0437-\u0410\u0444\u0433\u0430\u043D\u0438\u0441\u0442\u0430\u043D",
        description: "\u0421\u0442\u0440\u0430\u0442\u0435\u0433\u0438\u0447\u0435\u0441\u043A\u0438\u0439 \u043A\u043E\u0440\u0438\u0434\u043E\u0440 \u0432 \u041F\u0435\u0440\u0441\u0438\u0434\u0441\u043A\u0438\u0439 \u0437\u0430\u043B\u0438\u0432 \u0447\u0435\u0440\u0435\u0437 \u0410\u0444\u0433\u0430\u043D\u0438\u0441\u0442\u0430\u043D",
        features: ["\u0422\u0435\u0440\u043C\u0435\u0437-\u041C\u0430\u0437\u0430\u0440\u0438-\u0428\u0430\u0440\u0438\u0444-\u0413\u0435\u0440\u0430\u0442", "\u0411\u0430\u043D\u0434\u0430\u0440-\u0410\u0431\u0431\u0430\u0441/\u0427\u043E\u0431\u0430\u0445\u043E\u0440 \u043F\u043E\u0440\u0442\u044B", "\u0410\u0411\u0420 \u0444\u0438\u043D\u0430\u043D\u0441\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0435", "75\u043A\u043C \u0432 \u0410\u0444\u0433\u0430\u043D\u0438\u0441\u0442\u0430\u043D\u0435"],
        officialSource: "gov.uz/carec"
      }
    ],
    jobs: [
      {
        id: 5,
        title: "\u0421\u043F\u0435\u0446\u0438\u0430\u043B\u0438\u0441\u0442 \u043F\u043E \u0442\u0440\u0430\u043D\u0441\u043F\u043E\u0440\u0442\u043D\u043E\u0439 \u043B\u043E\u0433\u0438\u0441\u0442\u0438\u043A\u0435",
        provider: "\u0423\u0437\u0431\u0435\u043A\u0438\u0441\u0442\u043E\u043D \u0422\u0435\u043C\u0438\u0440 \u0419\u0443\u043B\u043B\u0430\u0440\u0438",
        price: "\u043E\u0442 8,500,000 \u0441\u0443\u043C/\u043C\u0435\u0441\u044F\u0446",
        rating: 4.9,
        verified: true,
        governmentApproved: true,
        location: "\u0422\u0430\u0448\u043A\u0435\u043D\u0442",
        description: "\u0423\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u0435 \u043C\u0435\u0436\u0434\u0443\u043D\u0430\u0440\u043E\u0434\u043D\u044B\u043C\u0438 \u0433\u0440\u0443\u0437\u043E\u043F\u0435\u0440\u0435\u0432\u043E\u0437\u043A\u0430\u043C\u0438 \u043F\u043E \u043A\u043E\u0440\u0438\u0434\u043E\u0440\u0430\u043C \u0426\u0410\u0420\u042D\u0421",
        features: ["\u0413\u043E\u0441\u0443\u0434\u0430\u0440\u0441\u0442\u0432\u0435\u043D\u043D\u043E\u0435 \u043F\u0440\u0435\u0434\u043F\u0440\u0438\u044F\u0442\u0438\u0435", "ISO 9001:2008 \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u0435", "CAREC \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B", "\u0421\u043E\u0446\u043F\u0430\u043A\u0435\u0442 \u043F\u043E\u043B\u043D\u044B\u0439"],
        officialSource: "uzbekistan-railway.uz"
      },
      {
        id: 6,
        title: "\u0422\u0430\u043C\u043E\u0436\u0435\u043D\u043D\u044B\u0439 \u0431\u0440\u043E\u043A\u0435\u0440-\u044D\u043A\u0441\u043F\u0435\u0434\u0438\u0442\u043E\u0440",
        provider: "\u0413\u043E\u0441\u0443\u0434\u0430\u0440\u0441\u0442\u0432\u0435\u043D\u043D\u044B\u0439 \u0442\u0430\u043C\u043E\u0436\u0435\u043D\u043D\u044B\u0439 \u043A\u043E\u043C\u0438\u0442\u0435\u0442",
        price: "\u043E\u0442 6,000,000 \u0441\u0443\u043C/\u043C\u0435\u0441\u044F\u0446",
        rating: 4.8,
        verified: true,
        governmentApproved: true,
        location: "\u0422\u0435\u0440\u043C\u0435\u0437/\u0422\u0430\u0448\u043A\u0435\u043D\u0442/\u041D\u0430\u0432\u043E\u0438",
        description: "\u0421\u0435\u0440\u0442\u0438\u0444\u0438\u0446\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u043E\u0435 \u0442\u0430\u043C\u043E\u0436\u0435\u043D\u043D\u043E\u0435 \u043E\u0444\u043E\u0440\u043C\u043B\u0435\u043D\u0438\u0435 \u0433\u0440\u0443\u0437\u043E\u0432",
        features: ["\u041B\u0438\u0446\u0435\u043D\u0437\u0438\u044F \u0413\u0422\u041A", "\u041C\u0414\u041F \u043F\u0440\u043E\u0446\u0435\u0434\u0443\u0440\u044B", "TRACECA \u043A\u043E\u0440\u0438\u0434\u043E\u0440\u044B", "\u041B\u044C\u0433\u043E\u0442\u044B \u0433\u043E\u0441\u0441\u043B\u0443\u0436\u0430\u0449\u0435\u0433\u043E"],
        officialSource: "customs.gov.uz"
      },
      {
        id: 7,
        title: "\u0418\u043D\u0436\u0435\u043D\u0435\u0440 \u043B\u043E\u0433\u0438\u0441\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u0446\u0435\u043D\u0442\u0440\u043E\u0432",
        provider: "\u0426\u0435\u043D\u0442\u0440 \u043B\u043E\u0433\u0438\u0441\u0442\u0438\u043A\u0438 \u0410\u043D\u0433\u0440\u0435\u043D",
        price: "\u043E\u0442 7,200,000 \u0441\u0443\u043C/\u043C\u0435\u0441\u044F\u0446",
        rating: 4.7,
        verified: true,
        governmentApproved: true,
        location: "\u0410\u043D\u0433\u0440\u0435\u043D/\u041D\u0430\u0432\u043E\u0438",
        description: "\u042D\u043A\u0441\u043F\u043B\u0443\u0430\u0442\u0430\u0446\u0438\u044F \u0441\u043E\u0432\u0440\u0435\u043C\u0435\u043D\u043D\u044B\u0445 \u0441\u043A\u043B\u0430\u0434\u0441\u043A\u0438\u0445 \u0442\u0435\u0440\u043C\u0438\u043D\u0430\u043B\u043E\u0432",
        features: ["8.6 \u0433\u0430 \u0442\u0435\u0440\u0440\u0438\u0442\u043E\u0440\u0438\u044F", "22 \u043A\u043E\u043D\u0442\u0435\u0439\u043D\u0435\u0440\u0430/\u0447\u0430\u0441", "1500 \u0442\u043E\u043D\u043D \u0441\u043A\u043B\u0430\u0434\u044B", "\u041F\u0435\u0440\u0435\u0432\u0430\u043B \u041A\u0430\u043C\u0447\u0438\u043A"],
        officialSource: "angren-logistics.uz"
      }
    ],
    equipment: [
      {
        id: 8,
        title: "\u0413\u0440\u0443\u0437\u043E\u0432\u0430\u044F \u0442\u0435\u0445\u043D\u0438\u043A\u0430 \u043F\u043E \u0441\u0442\u0430\u043D\u0434\u0430\u0440\u0442\u0430\u043C \u0415\u0432\u0440\u043E-4",
        provider: "\u0410\u0432\u0442\u043E\u0434\u043E\u0440 \u0423\u0437\u0431\u0435\u043A\u0438\u0441\u0442\u0430\u043D",
        price: "\u043E\u0442 1,200,000 \u0441\u0443\u043C/\u0434\u0435\u043D\u044C",
        rating: 4.8,
        verified: true,
        governmentApproved: true,
        location: "\u0420\u0435\u0441\u043F\u0443\u0431\u043B\u0438\u043A\u0430 \u0423\u0437\u0431\u0435\u043A\u0438\u0441\u0442\u0430\u043D",
        description: "\u0421\u0435\u0440\u0442\u0438\u0444\u0438\u0446\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0439 \u0430\u0432\u0442\u043E\u043F\u0430\u0440\u043A \u0434\u043B\u044F \u043C\u0435\u0436\u0434\u0443\u043D\u0430\u0440\u043E\u0434\u043D\u044B\u0445 \u043F\u0435\u0440\u0435\u0432\u043E\u0437\u043E\u043A",
        features: ["\u0415\u0432\u0440\u043E-4 \u0441\u0442\u0430\u043D\u0434\u0430\u0440\u0442", "\u041C\u0435\u0436\u0434\u0443\u043D\u0430\u0440\u043E\u0434\u043D\u044B\u0435 \u043B\u0438\u0446\u0435\u043D\u0437\u0438\u0438", "GPS \u043C\u043E\u043D\u0438\u0442\u043E\u0440\u0438\u043D\u0433", "517\u043A\u043C \u043D\u043E\u0432\u044B\u0445 \u0434\u043E\u0440\u043E\u0433 (2012)"],
        officialSource: "autodor.gov.uz"
      },
      {
        id: 9,
        title: "\u0416\u0435\u043B\u0435\u0437\u043D\u043E\u0434\u043E\u0440\u043E\u0436\u043D\u044B\u0435 \u0432\u0430\u0433\u043E\u043D\u044B \u0438 \u043B\u043E\u043A\u043E\u043C\u043E\u0442\u0438\u0432\u044B",
        provider: "\u0423\u0437\u0431\u0435\u043A\u0438\u0441\u0442\u043E\u043D \u0422\u0435\u043C\u0438\u0440 \u0419\u0443\u043B\u043B\u0430\u0440\u0438",
        price: "\u043E\u0442 2,500,000 \u0441\u0443\u043C/\u0441\u0443\u0442\u043A\u0438",
        rating: 4.9,
        verified: true,
        governmentApproved: true,
        location: "\u0416/\u0434 \u0441\u0435\u0442\u044C \u0423\u0437\u0431\u0435\u043A\u0438\u0441\u0442\u0430\u043D\u0430",
        description: "\u041C\u043E\u0434\u0435\u0440\u043D\u0438\u0437\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0439 \u043F\u043E\u0434\u0432\u0438\u0436\u043D\u043E\u0439 \u0441\u043E\u0441\u0442\u0430\u0432 \u0441 \u0410\u0411\u0420 \u0444\u0438\u043D\u0430\u043D\u0441\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0435\u043C",
        features: ["100-160 \u043A\u043C/\u0447 \u0441\u043A\u043E\u0440\u043E\u0441\u0442\u044C", "\u042D\u043B\u0435\u043A\u0442\u0440\u0438\u0444\u0438\u043A\u0430\u0446\u0438\u044F \u043B\u0438\u043D\u0438\u0439", "660\u043A\u043C \u043E\u0431\u043D\u043E\u0432\u043B\u0435\u043D\u044B", "\u041E\u043F\u0442\u0438\u043A\u043E-\u0432\u043E\u043B\u043E\u043A\u043E\u043D\u043D\u0430\u044F \u0441\u0432\u044F\u0437\u044C"],
        officialSource: "railway.gov.uz"
      },
      {
        id: 10,
        title: "\u0410\u0432\u0438\u0430\u0433\u0440\u0443\u0437\u043E\u0432\u0430\u044F \u0442\u0435\u0445\u043D\u0438\u043A\u0430 \u0438 \u043A\u043E\u043D\u0442\u0435\u0439\u043D\u0435\u0440\u044B",
        provider: "\u041D\u0430\u0432\u043E\u0438 \u0410\u0432\u0438\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0439 \u0425\u0430\u0431",
        price: "\u043E\u0442 800,000 \u0441\u0443\u043C/\u0447\u0430\u0441",
        rating: 4.7,
        verified: true,
        governmentApproved: true,
        location: "\u041D\u0430\u0432\u043E\u0438",
        description: "\u0421\u043F\u0435\u0446\u0438\u0430\u043B\u0438\u0437\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u043E\u0435 \u043E\u0431\u043E\u0440\u0443\u0434\u043E\u0432\u0430\u043D\u0438\u0435 \u0434\u043B\u044F \u0430\u0432\u0438\u0430\u0433\u0440\u0443\u0437\u043E\u0432",
        features: ["\u0411\u043E\u0438\u043D\u0433-767 \u0433\u0440\u0443\u0437\u043E\u0432\u044B\u0435", "\u041A\u043E\u043D\u0442\u0435\u0439\u043D\u0435\u0440\u043D\u044B\u0435 \u0442\u0435\u0440\u043C\u0438\u043D\u0430\u043B\u044B", "400 \u043F\u0430\u0441\u0441\u0430\u0436\u0438\u0440\u043E\u0432/\u0447\u0430\u0441", "\u041C\u0443\u043B\u044C\u0442\u0438\u043C\u043E\u0434\u0430\u043B\u044C\u043D\u043E\u0441\u0442\u044C"],
        officialSource: "navoi-airport.uz"
      }
    ],
    services: [
      {
        id: 11,
        title: "\u0422\u0430\u043C\u043E\u0436\u0435\u043D\u043D\u043E\u0435 \u043E\u0444\u043E\u0440\u043C\u043B\u0435\u043D\u0438\u0435 \u0433\u0440\u0443\u0437\u043E\u0432",
        provider: "\u0413\u043E\u0441\u0443\u0434\u0430\u0440\u0441\u0442\u0432\u0435\u043D\u043D\u044B\u0439 \u0442\u0430\u043C\u043E\u0436\u0435\u043D\u043D\u044B\u0439 \u043A\u043E\u043C\u0438\u0442\u0435\u0442",
        price: "\u043E\u0442 150,000 \u0441\u0443\u043C \u0437\u0430 \u0434\u0435\u043A\u043B\u0430\u0440\u0430\u0446\u0438\u044E",
        rating: 4.8,
        verified: true,
        governmentApproved: true,
        location: "\u0412\u0441\u0435 \u043F\u0443\u043D\u043A\u0442\u044B \u043F\u0440\u043E\u043F\u0443\u0441\u043A\u0430",
        description: "\u041E\u0444\u0438\u0446\u0438\u0430\u043B\u044C\u043D\u044B\u0435 \u0442\u0430\u043C\u043E\u0436\u0435\u043D\u043D\u044B\u0435 \u043F\u0440\u043E\u0446\u0435\u0434\u0443\u0440\u044B \u043F\u043E \u0441\u0442\u0430\u043D\u0434\u0430\u0440\u0442\u0430\u043C \u0412\u0422\u041E",
        features: ["\u042D\u043B\u0435\u043A\u0442\u0440\u043E\u043D\u043D\u043E\u0435 \u0434\u0435\u043A\u043B\u0430\u0440\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0435", "\u041C\u0414\u041F \u043F\u0440\u043E\u0446\u0435\u0434\u0443\u0440\u044B", "\u0422\u0440\u0430\u043D\u0437\u0438\u0442\u043D\u044B\u0435 \u0440\u0435\u0436\u0438\u043C\u044B", "CAREC \u0443\u043F\u0440\u043E\u0449\u0435\u043D\u0438\u044F"],
        officialSource: "customs.gov.uz"
      },
      {
        id: 12,
        title: "\u0421\u0435\u0440\u0442\u0438\u0444\u0438\u043A\u0430\u0446\u0438\u044F ISO 9001:2008 \u0434\u043B\u044F \u043B\u043E\u0433\u0438\u0441\u0442\u0438\u043A\u0438",
        provider: "\u0423\u0437\u0441\u0442\u0430\u043D\u0434\u0430\u0440\u0442",
        price: "\u043E\u0442 5,000,000 \u0441\u0443\u043C \u0437\u0430 \u0441\u0435\u0440\u0442\u0438\u0444\u0438\u043A\u0430\u0442",
        rating: 4.9,
        verified: true,
        governmentApproved: true,
        location: "\u0422\u0430\u0448\u043A\u0435\u043D\u0442",
        description: "\u041E\u0431\u044F\u0437\u0430\u0442\u0435\u043B\u044C\u043D\u0430\u044F \u0441\u0435\u0440\u0442\u0438\u0444\u0438\u043A\u0430\u0446\u0438\u044F \u0434\u043B\u044F \u043C\u0435\u0436\u0434\u0443\u043D\u0430\u0440\u043E\u0434\u043D\u044B\u0445 \u043F\u0435\u0440\u0435\u0432\u043E\u0437\u0447\u0438\u043A\u043E\u0432",
        features: ["\u041C\u0435\u0436\u0434\u0443\u043D\u0430\u0440\u043E\u0434\u043D\u043E\u0435 \u043F\u0440\u0438\u0437\u043D\u0430\u043D\u0438\u0435", "\u041A\u043E\u043D\u043A\u0443\u0440\u0435\u043D\u0442\u043E\u0441\u043F\u043E\u0441\u043E\u0431\u043D\u043E\u0441\u0442\u044C", "\u041A\u0430\u0447\u0435\u0441\u0442\u0432\u043E \u0443\u0441\u043B\u0443\u0433", "\u042D\u043A\u0441\u043F\u043E\u0440\u0442\u043D\u0430\u044F \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u043A\u0430"],
        officialSource: "uzstandard.uz"
      }
    ],
    rental: [
      {
        id: 13,
        title: "\u0421\u043A\u043B\u0430\u0434\u0441\u043A\u0438\u0435 \u0442\u0435\u0440\u043C\u0438\u043D\u0430\u043B\u044B \u0432 \u043B\u043E\u0433\u0438\u0441\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u0437\u043E\u043D\u0430\u0445",
        provider: "\u0421\u0418\u042D\u0417 \u041D\u0430\u0432\u043E\u0438 / \u0421\u0418\u0417 \u0410\u043D\u0433\u0440\u0435\u043D",
        price: "\u043E\u0442 25,000 \u0441\u0443\u043C/\u043C\xB2/\u043C\u0435\u0441\u044F\u0446",
        rating: 4.8,
        verified: true,
        governmentApproved: true,
        location: "\u041D\u0430\u0432\u043E\u0438/\u0410\u043D\u0433\u0440\u0435\u043D",
        description: "\u0421\u043F\u0435\u0446\u0438\u0430\u043B\u0438\u0437\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0435 \u0441\u043A\u043B\u0430\u0434\u0441\u043A\u0438\u0435 \u043A\u043E\u043C\u043F\u043B\u0435\u043A\u0441\u044B \u0432 \u0441\u0432\u043E\u0431\u043E\u0434\u043D\u044B\u0445 \u0437\u043E\u043D\u0430\u0445",
        features: ["\u0422\u0430\u043C\u043E\u0436\u0435\u043D\u043D\u044B\u0435 \u043B\u044C\u0433\u043E\u0442\u044B", "\u041C\u0443\u043B\u044C\u0442\u0438\u043C\u043E\u0434\u0430\u043B\u044C\u043D\u043E\u0441\u0442\u044C", "\u0421\u043E\u0432\u0440\u0435\u043C\u0435\u043D\u043D\u043E\u0435 \u043E\u0431\u043E\u0440\u0443\u0434\u043E\u0432\u0430\u043D\u0438\u0435", "\u041E\u0441\u043E\u0431\u044B\u0439 \u043F\u0440\u0430\u0432\u043E\u0432\u043E\u0439 \u0440\u0435\u0436\u0438\u043C"],
        officialSource: "fez.gov.uz"
      },
      {
        id: 14,
        title: "\u0425\u043E\u043B\u043E\u0434\u0438\u043B\u044C\u043D\u043E-\u0441\u043A\u043B\u0430\u0434\u0441\u043A\u043E\u0439 \u043A\u043E\u043C\u043F\u043B\u0435\u043A\u0441",
        provider: "Sergeli-Agrofresh",
        price: "\u043E\u0442 45,000 \u0441\u0443\u043C/\u0442\u043E\u043D\u043D\u0430/\u0441\u0443\u0442\u043A\u0438",
        rating: 4.9,
        verified: true,
        governmentApproved: true,
        location: "\u0422\u0430\u0448\u043A\u0435\u043D\u0442",
        description: "\u041A\u0440\u0443\u043F\u043D\u0435\u0439\u0448\u0438\u0439 \u0432 \u0423\u0437\u0431\u0435\u043A\u0438\u0441\u0442\u0430\u043D\u0435 - 14,000\u043C\xB2 / 10-16,000 \u0442\u043E\u043D\u043D",
        features: ["\u0415\u0432\u0440\u043E\u043F\u0435\u0439\u0441\u043A\u043E\u0435 \u043E\u0431\u043E\u0440\u0443\u0434\u043E\u0432\u0430\u043D\u0438\u0435", "\u0410\u0432\u0442\u043E\u043C\u0430\u0442\u0438\u0437\u0430\u0446\u0438\u044F T\xB0/\u0432\u043B\u0430\u0436\u043D\u043E\u0441\u0442\u044C", "\u0421\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u043A\u0430/\u043C\u0430\u0440\u043A\u0438\u0440\u043E\u0432\u043A\u0430", "\u0421\u0435\u043B\u044C\u0445\u043E\u0437\u043F\u0440\u043E\u0434\u0443\u043A\u0446\u0438\u044F"],
        officialSource: "minagro.gov.uz"
      }
    ]
  };
  const currentListings = mockListings[activeCategory] || [];
  const addToFavorites = (item) => {
    setFavorites([...favorites, item.id]);
  };
  const addToRecentViews = (item) => {
    const updated = [item.id, ...recentViews.filter((id) => id !== item.id)].slice(0, 10);
    setRecentViews(updated);
  };
  return /* @__PURE__ */ React.createElement("div", { className: "min-h-screen bg-gray-50" }, /* @__PURE__ */ React.createElement("header", { className: "bg-white shadow-sm border-b-2 border-blue-500" }, /* @__PURE__ */ React.createElement("div", { className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" }, /* @__PURE__ */ React.createElement("div", { className: "flex justify-between items-center h-16" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-3" }, /* @__PURE__ */ React.createElement("div", { className: "w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg flex items-center justify-center" }, /* @__PURE__ */ React.createElement(Globe, { className: "w-6 h-6 text-white" })), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h1", { className: "text-xl font-bold text-gray-900" }, "Terra Ubique"), /* @__PURE__ */ React.createElement("p", { className: "text-xs text-gray-600" }, "\u0423\u043D\u0438\u0432\u0435\u0440\u0441\u0430\u043B\u044C\u043D\u0430\u044F \u0430\u0433\u0440\u0435\u0433\u0430\u0446\u0438\u043E\u043D\u043D\u0430\u044F \u043F\u043B\u0430\u0442\u0444\u043E\u0440\u043C\u0430"))), /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-4" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-1 text-sm text-gray-600" }, /* @__PURE__ */ React.createElement(MapPin, { className: "w-4 h-4" }), /* @__PURE__ */ React.createElement("span", null, userLocation)), /* @__PURE__ */ React.createElement("div", { className: "w-8 h-8 rounded-full bg-gradient-to-r from-purple-400 to-pink-400 flex items-center justify-center text-white text-sm font-medium" }, user.name.charAt(0).toUpperCase()))))), /* @__PURE__ */ React.createElement("div", { className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6" }, /* @__PURE__ */ React.createElement("div", { className: "mb-8" }, /* @__PURE__ */ React.createElement("h2", { className: "text-2xl font-bold text-gray-900 mb-4" }, "\u0427\u0442\u043E \u0432\u044B \u0438\u0449\u0435\u0442\u0435?"), /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4" }, Object.entries(categories).map(([key, category]) => {
    const IconComponent = category.icon;
    return /* @__PURE__ */ React.createElement(
      "button",
      {
        key,
        onClick: () => setActiveCategory(key),
        className: `p-4 rounded-xl border-2 transition-all duration-200 ${activeCategory === key ? "border-blue-500 bg-blue-50 shadow-md" : "border-gray-200 bg-white hover:border-gray-300 hover:shadow-sm"}`
      },
      /* @__PURE__ */ React.createElement("div", { className: `w-12 h-12 rounded-lg ${category.color} flex items-center justify-center mb-3 mx-auto` }, /* @__PURE__ */ React.createElement(IconComponent, { className: "w-6 h-6 text-white" })),
      /* @__PURE__ */ React.createElement("h3", { className: "font-semibold text-gray-900 text-sm" }, category.name),
      /* @__PURE__ */ React.createElement("p", { className: "text-xs text-gray-600 mt-1" }, category.description)
    );
  }))), /* @__PURE__ */ React.createElement("div", { className: "mb-6" }, /* @__PURE__ */ React.createElement("div", { className: "flex flex-col sm:flex-row gap-4" }, /* @__PURE__ */ React.createElement("div", { className: "flex-1 relative" }, /* @__PURE__ */ React.createElement(Search, { className: "absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" }), /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "text",
      placeholder: `\u041F\u043E\u0438\u0441\u043A \u0432 \u043A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u0438 "${categories[activeCategory]?.name}"...`,
      value: searchQuery,
      onChange: (e) => setSearchQuery(e.target.value),
      className: "w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
    }
  )), /* @__PURE__ */ React.createElement("button", { className: "px-6 py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors flex items-center space-x-2" }, /* @__PURE__ */ React.createElement(Filter, { className: "w-5 h-5" }), /* @__PURE__ */ React.createElement("span", null, "\u0424\u0438\u043B\u044C\u0442\u0440\u044B")))), /* @__PURE__ */ React.createElement("div", { className: "mb-6 p-6 bg-gradient-to-r from-blue-500 to-purple-600 rounded-xl text-white" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-3 mb-3" }, /* @__PURE__ */ React.createElement("div", { className: "w-12 h-12 bg-white bg-opacity-20 rounded-lg flex items-center justify-center" }, React.createElement(categories[activeCategory]?.icon, { className: "w-6 h-6" })), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h3", { className: "text-xl font-bold" }, categories[activeCategory]?.name), /* @__PURE__ */ React.createElement("p", { className: "text-blue-100" }, categories[activeCategory]?.description))), /* @__PURE__ */ React.createElement("div", { className: "flex flex-wrap gap-2" }, categories[activeCategory]?.subcategories.map((sub, index) => /* @__PURE__ */ React.createElement("span", { key: index, className: "px-3 py-1 bg-white bg-opacity-20 rounded-full text-sm" }, sub)))), /* @__PURE__ */ React.createElement("div", { className: "mb-6" }, /* @__PURE__ */ React.createElement("div", { className: "flex justify-between items-center mb-4" }, /* @__PURE__ */ React.createElement("h3", { className: "text-lg font-semibold text-gray-900" }, "\u041D\u0430\u0439\u0434\u0435\u043D\u043E ", currentListings.length, " \u043F\u0440\u0435\u0434\u043B\u043E\u0436\u0435\u043D\u0438\u0439"), /* @__PURE__ */ React.createElement("select", { className: "px-4 py-2 border border-gray-300 rounded-lg" }, /* @__PURE__ */ React.createElement("option", null, "\u041F\u043E \u0440\u0435\u043B\u0435\u0432\u0430\u043D\u0442\u043D\u043E\u0441\u0442\u0438"), /* @__PURE__ */ React.createElement("option", null, "\u041F\u043E \u0446\u0435\u043D\u0435 (\u0432\u043E\u0437\u0440\u0430\u0441\u0442\u0430\u043D\u0438\u0435)"), /* @__PURE__ */ React.createElement("option", null, "\u041F\u043E \u0446\u0435\u043D\u0435 (\u0443\u0431\u044B\u0432\u0430\u043D\u0438\u0435)"), /* @__PURE__ */ React.createElement("option", null, "\u041F\u043E \u0440\u0435\u0439\u0442\u0438\u043D\u0433\u0443"))), /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" }, currentListings.map((item) => /* @__PURE__ */ React.createElement("div", { key: item.id, className: "bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden hover:shadow-md transition-shadow" }, /* @__PURE__ */ React.createElement("div", { className: "h-48 bg-gradient-to-br from-gray-200 to-gray-300 relative" }, /* @__PURE__ */ React.createElement("div", { className: "absolute top-3 right-3 flex space-x-2" }, item.verified && /* @__PURE__ */ React.createElement("span", { className: "px-2 py-1 bg-green-500 text-white rounded-full text-xs flex items-center space-x-1" }, /* @__PURE__ */ React.createElement(Shield, { className: "w-3 h-3" }), /* @__PURE__ */ React.createElement("span", null, "\u041F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043E")), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => addToFavorites(item),
      className: "w-8 h-8 bg-white rounded-full flex items-center justify-center shadow-sm hover:bg-gray-50"
    },
    /* @__PURE__ */ React.createElement(Heart, { className: "w-4 h-4 text-gray-600" })
  ))), /* @__PURE__ */ React.createElement("div", { className: "p-5" }, /* @__PURE__ */ React.createElement("div", { className: "flex justify-between items-start mb-2" }, /* @__PURE__ */ React.createElement("h4", { className: "font-semibold text-gray-900 text-sm" }, item.title), /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-1" }, /* @__PURE__ */ React.createElement(Star, { className: "w-4 h-4 text-yellow-400 fill-current" }), /* @__PURE__ */ React.createElement("span", { className: "text-sm text-gray-600" }, item.rating))), /* @__PURE__ */ React.createElement("p", { className: "text-sm text-gray-600 mb-3" }, item.provider), /* @__PURE__ */ React.createElement("p", { className: "text-xs text-gray-500 mb-3" }, item.description), /* @__PURE__ */ React.createElement("div", { className: "flex flex-wrap gap-1 mb-4" }, item.features.map((feature, index) => /* @__PURE__ */ React.createElement("span", { key: index, className: "px-2 py-1 bg-gray-100 text-gray-600 rounded text-xs" }, feature))), /* @__PURE__ */ React.createElement("div", { className: "flex justify-between items-center" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("span", { className: "text-lg font-bold text-blue-600" }, item.price), /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-1 text-xs text-gray-500" }, /* @__PURE__ */ React.createElement(MapPin, { className: "w-3 h-3" }), /* @__PURE__ */ React.createElement("span", null, item.location))), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => addToRecentViews(item),
      className: "px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors text-sm"
    },
    "\u041F\u043E\u0434\u0440\u043E\u0431\u043D\u0435\u0435"
  ))))))), /* @__PURE__ */ React.createElement("div", { className: "mb-8 bg-gradient-to-r from-green-500 to-blue-600 rounded-xl p-6 text-white" }, /* @__PURE__ */ React.createElement("h3", { className: "text-lg font-semibold mb-4 flex items-center" }, /* @__PURE__ */ React.createElement(Shield, { className: "w-6 h-6 mr-2" }), "\u041E\u0444\u0438\u0446\u0438\u0430\u043B\u044C\u043D\u044B\u0435 \u0438\u0441\u0442\u043E\u0447\u043D\u0438\u043A\u0438 \u0434\u0430\u043D\u043D\u044B\u0445 \u0420\u0435\u0441\u043F\u0443\u0431\u043B\u0438\u043A\u0438 \u0423\u0437\u0431\u0435\u043A\u0438\u0441\u0442\u0430\u043D"), /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4 text-sm" }, /* @__PURE__ */ React.createElement("div", { className: "space-y-2" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-2" }, /* @__PURE__ */ React.createElement(Globe, { className: "w-4 h-4" }), /* @__PURE__ */ React.createElement("span", null, /* @__PURE__ */ React.createElement("strong", null, "gov.uz/oz"), " - \u0413\u043E\u0441\u0443\u0434\u0430\u0440\u0441\u0442\u0432\u0435\u043D\u043D\u044B\u0439 \u043F\u043E\u0440\u0442\u0430\u043B (3 \u044F\u0437\u044B\u043A\u0430)")), /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-2" }, /* @__PURE__ */ React.createElement(Package, { className: "w-4 h-4" }), /* @__PURE__ */ React.createElement("span", null, /* @__PURE__ */ React.createElement("strong", null, "lex.uz"), " - \u041C\u0438\u043D\u044E\u0441\u0442: \u0437\u0430\u043A\u043E\u043D\u044B \u0438 \u0430\u043A\u0442\u044B"))), /* @__PURE__ */ React.createElement("div", { className: "space-y-2" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-2" }, /* @__PURE__ */ React.createElement(Truck, { className: "w-4 h-4" }), /* @__PURE__ */ React.createElement("span", null, /* @__PURE__ */ React.createElement("strong", null, "26,000 \u0444\u0443\u0440"), " + 240,917 \u0433\u0440\u0443\u0437\u043E\u0432\u044B\u0445 \u0422\u0421")), /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-2" }, /* @__PURE__ */ React.createElement(Zap, { className: "w-4 h-4" }), /* @__PURE__ */ React.createElement("span", null, /* @__PURE__ */ React.createElement("strong", null, "CAREC \u043A\u043E\u0440\u0438\u0434\u043E\u0440\u044B"), " + TRACECA \u0438\u043D\u0442\u0435\u0433\u0440\u0430\u0446\u0438\u044F"))))), /* @__PURE__ */ React.createElement("div", { className: "bg-white rounded-xl p-6 border border-gray-200" }, /* @__PURE__ */ React.createElement("h3", { className: "text-lg font-semibold text-gray-900 mb-4" }, "\u041F\u0440\u0435\u0438\u043C\u0443\u0449\u0435\u0441\u0442\u0432\u0430 Terra Ubique"), /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-6" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-3" }, /* @__PURE__ */ React.createElement("div", { className: "w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center" }, /* @__PURE__ */ React.createElement(Shield, { className: "w-5 h-5 text-green-600" })), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h4", { className: "font-medium text-gray-900" }, "\u0413\u043E\u0441\u0443\u0434\u0430\u0440\u0441\u0442\u0432\u0435\u043D\u043D\u0430\u044F \u0432\u0435\u0440\u0438\u0444\u0438\u043A\u0430\u0446\u0438\u044F"), /* @__PURE__ */ React.createElement("p", { className: "text-sm text-gray-600" }, "\u041E\u0444\u0438\u0446\u0438\u0430\u043B\u044C\u043D\u044B\u0435 \u0438\u0441\u0442\u043E\u0447\u043D\u0438\u043A\u0438 gov.uz/lex.uz"))), /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-3" }, /* @__PURE__ */ React.createElement("div", { className: "w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center" }, /* @__PURE__ */ React.createElement(Zap, { className: "w-5 h-5 text-blue-600" })), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h4", { className: "font-medium text-gray-900" }, "CAREC \u043A\u043E\u0440\u0438\u0434\u043E\u0440\u044B"), /* @__PURE__ */ React.createElement("p", { className: "text-sm text-gray-600" }, "\u041C\u0435\u0436\u0434\u0443\u043D\u0430\u0440\u043E\u0434\u043D\u044B\u0435 \u0442\u0440\u0430\u043D\u0441\u043F\u043E\u0440\u0442\u043D\u044B\u0435 \u043C\u0430\u0440\u0448\u0440\u0443\u0442\u044B"))), /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-3" }, /* @__PURE__ */ React.createElement("div", { className: "w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center" }, /* @__PURE__ */ React.createElement(Globe, { className: "w-5 h-5 text-purple-600" })), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h4", { className: "font-medium text-gray-900" }, "Terra Ecosystem AIUZ"), /* @__PURE__ */ React.createElement("p", { className: "text-sm text-gray-600" }, "Phoenix Protocol + \u041E\u0444\u0438\u0446\u0438\u0430\u043B\u044C\u043D\u044B\u0435 \u0434\u0430\u043D\u043D\u044B\u0435")))))), /* @__PURE__ */ React.createElement("footer", { className: "bg-gray-900 text-white mt-12 py-8" }, /* @__PURE__ */ React.createElement("div", { className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" }, /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-1 md:grid-cols-4 gap-6" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-2 mb-4" }, /* @__PURE__ */ React.createElement(Globe, { className: "w-6 h-6 text-blue-400" }), /* @__PURE__ */ React.createElement("span", { className: "font-bold" }, "Terra Ubique")), /* @__PURE__ */ React.createElement("p", { className: "text-gray-400 text-sm" }, "\u0423\u043D\u0438\u0432\u0435\u0440\u0441\u0430\u043B\u044C\u043D\u0430\u044F \u0430\u0433\u0440\u0435\u0433\u0430\u0446\u0438\u043E\u043D\u043D\u0430\u044F \u043F\u043B\u0430\u0442\u0444\u043E\u0440\u043C\u0430 \u0434\u043B\u044F \u0423\u0437\u0431\u0435\u043A\u0438\u0441\u0442\u0430\u043D\u0430 \u0438 \u043C\u0438\u0440\u0430")), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h4", { className: "font-semibold mb-3" }, "\u041A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u0438"), /* @__PURE__ */ React.createElement("ul", { className: "space-y-2 text-sm text-gray-400" }, /* @__PURE__ */ React.createElement("li", null, "\u041B\u043E\u0433\u0438\u0441\u0442\u0438\u043A\u0430"), /* @__PURE__ */ React.createElement("li", null, "\u0420\u0430\u0431\u043E\u0442\u0430"), /* @__PURE__ */ React.createElement("li", null, "\u0422\u0435\u0445\u043D\u0438\u043A\u0430"), /* @__PURE__ */ React.createElement("li", null, "\u0423\u0441\u043B\u0443\u0433\u0438"), /* @__PURE__ */ React.createElement("li", null, "\u0410\u0440\u0435\u043D\u0434\u0430"))), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h4", { className: "font-semibold mb-3" }, "\u041F\u043E\u0434\u0434\u0435\u0440\u0436\u043A\u0430"), /* @__PURE__ */ React.createElement("ul", { className: "space-y-2 text-sm text-gray-400" }, /* @__PURE__ */ React.createElement("li", null, "\u0421\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u044B\u0439 \u0446\u0435\u043D\u0442\u0440"), /* @__PURE__ */ React.createElement("li", null, "\u0421\u0432\u044F\u0437\u0430\u0442\u044C\u0441\u044F \u0441 \u043D\u0430\u043C\u0438"), /* @__PURE__ */ React.createElement("li", null, "\u041F\u043E\u043B\u0438\u0442\u0438\u043A\u0430 \u043A\u043E\u043D\u0444\u0438\u0434\u0435\u043D\u0446\u0438\u0430\u043B\u044C\u043D\u043E\u0441\u0442\u0438"), /* @__PURE__ */ React.createElement("li", null, "\u0423\u0441\u043B\u043E\u0432\u0438\u044F \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u043D\u0438\u044F"))), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h4", { className: "font-semibold mb-3" }, "\u041A\u043E\u043D\u0442\u0430\u043A\u0442\u044B"), /* @__PURE__ */ React.createElement("div", { className: "space-y-2 text-sm text-gray-400" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-2" }, /* @__PURE__ */ React.createElement(Phone, { className: "w-4 h-4" }), /* @__PURE__ */ React.createElement("span", null, "+998 (71) 295-08-85")), /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-2" }, /* @__PURE__ */ React.createElement(Mail, { className: "w-4 h-4" }), /* @__PURE__ */ React.createElement("span", null, "info@terraubique.uz")), /* @__PURE__ */ React.createElement("div", { className: "flex items-center space-x-2" }, /* @__PURE__ */ React.createElement(MapPin, { className: "w-4 h-4" }), /* @__PURE__ */ React.createElement("span", null, "\u0422\u0430\u0448\u043A\u0435\u043D\u0442, \u0423\u0437\u0431\u0435\u043A\u0438\u0441\u0442\u0430\u043D"))))), /* @__PURE__ */ React.createElement("div", { className: "border-t border-gray-800 mt-8 pt-6 text-center text-sm text-gray-400" }, /* @__PURE__ */ React.createElement("p", null, "\xA9 2025 Terra Ubique. Powered by Terra Ecosystem v4.0. \u0412\u0441\u0435 \u043F\u0440\u0430\u0432\u0430 \u0437\u0430\u0449\u0438\u0449\u0435\u043D\u044B."), /* @__PURE__ */ React.createElement("p", { className: "mt-1" }, "\u{1F525} Phoenix Protocol Cycle 14 - Gefunden Ethical Validation \u2705")))));
};
var stdin_default = TerraUbique;
export {
  stdin_default as default
};
