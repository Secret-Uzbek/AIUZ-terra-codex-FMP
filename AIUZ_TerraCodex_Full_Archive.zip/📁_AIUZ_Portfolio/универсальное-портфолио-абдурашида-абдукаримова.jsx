import React, { useState } from 'react';
import { Globe, Mail, Phone, MapPin, Calendar, Award, BookOpen, Briefcase, Languages, Star, CheckCircle, Users, Target, Zap, Shield, Heart, FileText, Download, ExternalLink } from 'lucide-react';

const Portfolio = () => {
  const [activeLanguage, setActiveLanguage] = useState('ru');

  const content = {
    ru: {
      title: "УНИВЕРСАЛЬНОЕ ПОРТФОЛИО ОСНОВАТЕЛЯ AIUZ-TERRA",
      name: "АБДУРАШИД АБДУКАРИМОВ",
      subtitle: "Основатель экосистемы AIUZ-Terra",
      did: "aiuz:did:aiuz:stakeholder:abdukarimov_aaahash1234567890",
      status: "ОСНОВАТЕЛЬ И ВИЗИОНЕР AIUZ-Terra Ecosystem",
      
      sections: {
        personal: {
          title: "ПЕРСОНАЛЬНЫЕ ДАННЫЕ",
          fullName: "Абдурашид Абдулхамитович Абдукаримов",
          birthDate: "22 марта 1977 г. (48 лет)",
          familyStatus: "Женат, есть дети",
          location: "Ташкент, Узбекистан",
          phone: "+998950833850",
          email: "a.a.abdukarimov@tutamail.com",
          orcid: "0009-0000-6394-4912"
        },
        
        languages: {
          title: "ЯЗЫКОВЫЕ КОМПЕТЕНЦИИ (DAAD КОНТЕКСТ)",
          german: {
            title: "Немецкий язык",
            level: "Профессионально владеет - Институт им. Гёте",
            achievements: [
              "DAAD-Stipendienurkunde 1997 - государственное признание ФРГ",
              "DSH Humboldt-Universität 1998 - академическая валидация",
              "Преподавательская квалификация - выше DSD II уровня"
            ]
          },
          english: {
            title: "Английский язык",
            level: "Профессиональный преподавательский уровень (диплом с отличием)"
          },
          russian: {
            title: "Русский язык",
            level: "Родной + профессиональный"
          },
          uzbek: {
            title: "Узбекский язык", 
            level: "Родной + дипломированный преподаватель"
          }
        },
        
        education: {
          title: "ОБРАЗОВАНИЕ",
          items: [
            {
              year: "1999",
              institution: "Узбекский государственный университет мировых языков",
              degree: "Преподаватель немецкого и английского языков",
              note: "Диплом с отличием"
            },
            {
              year: "2006",
              institution: "Аспирантура",
              degree: "Специальность 10.02.04 (немецкий язык) • УзГУМЯ",
              thesis: "Теоретические основы создания узбекско-немецких и немецко-узбекских электронных словарей"
            },
            {
              year: "1997",
              institution: "DAAD стипендия",
              degree: "Deutscher Akademischer Austauschdienst • Stipendienurkunde"
            },
            {
              year: "1998",
              institution: "DSH - Университет Гумбольдта",
              degree: "Deutsche Sprachprüfung für den Hochschulzugang • Берлин"
            }
          ]
        },
        
        career: {
          title: "ХРОНОЛОГИЯ КАРЬЕРЫ (30 ЛЕТ)",
          items: [
            {
              years: "1996-1999",
              company: "Ёрдамчи турсервис",
              position: "Гид-переводчик, тур-оператор",
              achievement: "Масштабный туризм по Шелковому пути"
            },
            {
              years: "1999-2001",
              company: "Институт им. Гёте",
              position: "Ассистент по культурным программам",
              achievement: "Культурные проекты международного уровня"
            },
            {
              years: "1999-2003",
              company: "Узбекский государственный университет мировых языков",
              position: "Преподаватель",
              achievement: "Подготовка к языковым олимпиадам"
            },
            {
              years: "2003-2006",
              company: "Федерация футбола Узбекистана",
              position: "Ведущий специалист",
              achievement: "Поддержка национальных команд на международном уровне"
            },
            {
              years: "2006-2007",
              company: "Siemens",
              position: "Ассистент по проекту",
              achievement: "Промышленные проекты в Навои"
            },
            {
              years: "2011-2017",
              company: "Посольство Швейцарии в Ташкенте",
              position: "Ассистент по политическим и экономическим вопросам",
              achievement: "6 лет дипломатического анализа"
            },
            {
              years: "2017-2025",
              company: "Независимый консультант",
              position: "Бизнес-консультант, переводчик",
              achievement: "Создание AIUZ-Terra Ecosystem"
            }
          ]
        },
        
        competencies: {
          title: "КЛЮЧЕВЫЕ КОМПЕТЕНЦИИ",
          linguistic: {
            title: "Лингвистическая экспертиза",
            items: [
              "Синхронный перевод (немецкий-русский)",
              "Последовательный перевод (все языковые пары)",
              "Письменный перевод (технический + культурный)",
              "Разработка тезауруса (немецко-узбекский ИИ-тезаурус)",
              "TILMOCH.AI переводческий модуль"
            ]
          },
          diplomatic: {
            title: "Дипломатический опыт",
            items: [
              "Политический анализ и региональная экспертиза",
              "Экономические отчеты и аналитика",
              "Международные отношения (швейцарско-узбекские связи)",
              "Управление протоколом высокоуровневых визитов"
            ]
          },
          research: {
            title: "Научные исследования",
            items: [
              "Системная междисциплинарность",
              "Метафрактальная научная методология",
              "ИИ в образовательных системах",
              "Академические публикации и диссертации"
            ]
          },
          technical: {
            title: "Техническое лидерство",
            items: [
              "Управление международными проектами",
              "Системная архитектура образовательных экосистем",
              "Этичный ИИ для детей",
              "DAO без токенов",
              "AIUZ-Terra полная архитектура"
            ]
          }
        },
        
        publications: {
          title: "НАУЧНЫЕ ПУБЛИКАЦИИ И ИССЛЕДОВАНИЯ",
          items: [
            {
              title: "Системная междисциплинарность: Научное обоснование интегративного подхода",
              status: "Опубликовано на канвасе (2025)",
              innovation: "8-уровневая модель научной интеграции"
            },
            {
              title: "Метафрактальная научная методология",
              status: "В разработке",
              innovation: "Голографический принцип в научном знании"
            },
            {
              title: "TILMOCH.AI",
              description: "Переводческий модуль для узбекского и родственных языков",
              languages: "узбекский, уйгурский, казахский, киргизский, таджикский, персидский, хинди",
              features: "голосовой модуль, адаптация для людей с ограниченными возможностями",
              status: "В разработке"
            }
          ]
        },
        
        ecosystem: {
          title: "AIUZ-TERRA ECOSYSTEM",
          systems: [
            "AIUZ OS v1.0 - операционная система образования",
            "DAO Governance - репутационное управление без токенов",
            "Sigma Core Memory - система непрерывной памяти",
            "Terra Document Protocol - унифицированные стандарты документации"
          ],
          principles: {
            title: "ПРИНЦИПЫ ТЕРРА",
            items: [
              {
                title: "Child Safety First",
                description: "Воспитание собственных детей + профессиональный опыт"
              },
              {
                title: "Vendor Independence",
                description: "30 лет работы с различными организациями"
              },
              {
                title: "Cultural Sensitivity",
                description: "Жизнь на стыке 4 культур"
              },
              {
                title: "Ethical AI",
                description: "Понимание важности моральных основ"
              }
            ]
          }
        },
        
        contact: {
          title: "КОНТАКТНАЯ ИНФОРМАЦИЯ",
          main: {
            title: "Основной контакт",
            email: "a.a.abdukarimov@tutamail.com",
            phone: "+998950833850",
            location: "Ташкент, Узбекистан",
            relocation: "Готов к переезду: Да (для развития проекта)"
          },
          professional: {
            title: "Профессиональные профили",
            orcid: "0009-0000-6394-4912",
            f6s: "abdurashid-abdukarimov",
            proz: "71262"
          },
          availability: {
            title: "Доступность",
            items: [
              "01.01.2026 и далее: Готов к полноценной работе над AIUZ-Terra",
              "24/7 поддержка: Критически важные вопросы проекта",
              "Международная мобильность: Готов к работе в любой стране"
            ]
          }
        },
        
        uniqueness: {
          title: "ЧТО ДЕЛАЕТ АБДУРАШИДА УНИКАЛЬНЫМ",
          items: [
            "48 лет жизненного опыта - мудрость и понимание жизни",
            "30 лет профессиональной эволюции - от гида до создателя ИИ-экосистем",
            "4 языка и культуры - истинное понимание многообразия",
            "Дипломатический опыт - умение строить мосты между мирами",
            "Родительский инстинкт - искренняя забота о безопасности детей",
            "Визионерское мышление - способность видеть будущее образования"
          ]
        },
        
        compliance: {
          title: "TERRA COMPLIANCE CHECK",
          items: [
            {
              title: "Child Safety",
              description: "Основа всей философии и практики",
              status: true
            },
            {
              title: "Vendor Independence",
              description: "30 лет независимой работы",
              status: true
            },
            {
              title: "Cultural Sensitivity",
              description: "Жизнь на стыке культур",
              status: true
            },
            {
              title: "Ethical AI",
              description: "Моральные принципы как основа всех решений",
              status: true
            }
          ]
        }
      }
    },
    
    uz: {
      title: "AIUZ-TERRA ASOSCHISINING UNIVERSAL PORTFOLIOSI",
      name: "ABDURASHID ABDUKARIMOV",
      subtitle: "AIUZ-Terra ekotizimining asoschisi",
      did: "aiuz:did:aiuz:stakeholder:abdukarimov_aaahash1234567890",
      status: "AIUZ-Terra Ecosystem asoschisi va g'oya muallifi",
      
      sections: {
        personal: {
          title: "SHAXSIY MA'LUMOTLAR",
          fullName: "Abdukarimov Abdurashid Abdulhamitovich",
          birthDate: "1977-yil 22-mart (48 yosh)",
          familyStatus: "Uylangan, farzandlari bor",
          location: "Toshkent, O'zbekiston",
          phone: "+998950833850",
          email: "a.a.abdukarimov@tutamail.com",
          orcid: "0009-0000-6394-4912"
        },
        
        languages: {
          title: "TIL KOMPETENSIYALARI (DAAD KONTEKSTI)",
          german: {
            title: "Nemis tili",
            level: "Professional darajada egalaydi - Gyote instituti",
            achievements: [
              "DAAD-Stipendienurkunde 1997 - GFRning davlat tan olishi",
              "DSH Humboldt-Universität 1998 - akademik tasdiqlash",
              "O'qituvchilik malakasi - DSD II darajasidan yuqori"
            ]
          },
          english: {
            title: "Ingliz tili",
            level: "Professional o'qituvchilik darajasi (imtiyozli diplom)"
          },
          russian: {
            title: "Rus tili",
            level: "Ona tili + professional daraja"
          },
          uzbek: {
            title: "O'zbek tili",
            level: "Ona tili + diplomli o'qituvchi"
          }
        },
        
        education: {
          title: "TA'LIM",
          items: [
            {
              year: "1999",
              institution: "O'zbekiston davlat jahon tillari universiteti",
              degree: "Nemis va ingliz tili o'qituvchisi",
              note: "Imtiyozli diplom"
            },
            {
              year: "2006",
              institution: "Aspirantura",
              degree: "Mutaxassislik 10.02.04 (nemis tili) • O'zDJTU",
              thesis: "O'zbek-nemis va nemis-o'zbek elektron lug'atlarini yaratishning nazariy asoslari"
            },
            {
              year: "1997",
              institution: "DAAD stipendiyasi",
              degree: "Deutscher Akademischer Austauschdienst • Stipendienurkunde"
            },
            {
              year: "1998",
              institution: "DSH - Humboldt universiteti",
              degree: "Deutsche Sprachprüfung für den Hochschulzugang • Berlin"
            }
          ]
        },
        
        career: {
          title: "KARERA XRONOLOGIYASI (30 YIL)",
          items: [
            {
              years: "1996-1999",
              company: "Yordamchi turservis",
              position: "Gid-tarjimon, turoperator",
              achievement: "Ipak yo'li bo'ylab keng ko'lamli turizm"
            },
            {
              years: "1999-2001",
              company: "Gyote instituti",
              position: "Madaniy dasturlar bo'yicha yordamchi",
              achievement: "Xalqaro darajadagi madaniy loyihalar"
            },
            {
              years: "1999-2003",
              company: "O'zbekiston davlat jahon tillari universiteti",
              position: "O'qituvchi",
              achievement: "Til olimpiadalariga tayyorgarlik"
            },
            {
              years: "2003-2006",
              company: "O'zbekiston Futbol Federatsiyasi",
              position: "Yetakchi mutaxassis",
              achievement: "Milliy jamoalarni xalqaro miqyosda qo'llab-quvvatlash"
            },
            {
              years: "2006-2007",
              company: "Siemens",
              position: "Loyiha yordamchisi",
              achievement: "Navoiyda sanoat loyihalari"
            },
            {
              years: "2011-2017",
              company: "Shveytsariyaning Toshkentdagi elchixonasi",
              position: "Siyosiy va iqtisodiy masalalar bo'yicha yordamchi",
              achievement: "6 yillik diplomatik tahlil"
            },
            {
              years: "2017-2025",
              company: "Mustaqil maslahatchi",
              position: "Biznes-maslahatchi, tarjimon",
              achievement: "AIUZ-Terra ekotizimining yaratilishi"
            }
          ]
        }
        // ... продолжение узбекского контента
      }
    },
    
    de: {
      title: "UNIVERSELLES PORTFOLIO DES AIUZ-TERRA GRÜNDERS",
      name: "ABDURASHID ABDUKARIMOV",
      subtitle: "Gründer des AIUZ-Terra Ökosystems",
      did: "aiuz:did:aiuz:stakeholder:abdukarimov_aaahash1234567890",
      status: "GRÜNDER UND VISIONÄR des AIUZ-Terra Ecosystems",
      
      sections: {
        personal: {
          title: "PERSÖNLICHE DATEN",
          fullName: "Abdurashid Abdulhamitovich Abdukarimov",
          birthDate: "22. März 1977 (48 Jahre)",
          familyStatus: "Verheiratet, Kinder",
          location: "Taschkent, Usbekistan",
          phone: "+998950833850",
          email: "a.a.abdukarimov@tutamail.com",
          orcid: "0009-0000-6394-4912"
        },
        
        languages: {
          title: "SPRACHKOMPETENZEN (DAAD KONTEXT)",
          german: {
            title: "Deutsche Sprache",
            level: "Professionell beherrschend - Goethe-Institut",
            achievements: [
              "DAAD-Stipendienurkunde 1997 - staatliche Anerkennung der BRD",
              "DSH Humboldt-Universität 1998 - akademische Validierung",
              "Lehrqualifikation - über DSD II Niveau"
            ]
          },
          english: {
            title: "Englische Sprache",
            level: "Professionelles Lehrniveau (Diplom mit Auszeichnung)"
          },
          russian: {
            title: "Russische Sprache",
            level: "Muttersprache + professionell"
          },
          uzbek: {
            title: "Usbekische Sprache",
            level: "Muttersprache + diplomierter Lehrer"
          }
        }
        // ... продолжение немецкого контента
      }
    },
    
    en: {
      title: "UNIVERSAL PORTFOLIO OF AIUZ-TERRA FOUNDER",
      name: "ABDURASHID ABDUKARIMOV",
      subtitle: "Founder of AIUZ-Terra Ecosystem",
      did: "aiuz:did:aiuz:stakeholder:abdukarimov_aaahash1234567890",
      status: "FOUNDER AND VISIONARY of AIUZ-Terra Ecosystem",
      
      sections: {
        personal: {
          title: "PERSONAL DATA",
          fullName: "Abdurashid Abdulhamitovich Abdukarimov",
          birthDate: "March 22, 1977 (48 years old)",
          familyStatus: "Married, has children",
          location: "Tashkent, Uzbekistan",
          phone: "+998950833850",
          email: "a.a.abdukarimov@tutamail.com",
          orcid: "0009-0000-6394-4912"
        },
        
        languages: {
          title: "LANGUAGE COMPETENCIES (DAAD CONTEXT)",
          german: {
            title: "German Language",
            level: "Professional proficiency - Goethe Institute",
            achievements: [
              "DAAD-Stipendienurkunde 1997 - German state recognition",
              "DSH Humboldt-Universität 1998 - academic validation",
              "Teaching qualification - above DSD II level"
            ]
          },
          english: {
            title: "English Language",
            level: "Professional teaching level (diploma with honors)"
          },
          russian: {
            title: "Russian Language",
            level: "Native + professional"
          },
          uzbek: {
            title: "Uzbek Language",
            level: "Native + certified teacher"
          }
        }
        // ... продолжение английского контента
      }
    }
  };

  const currentContent = content[activeLanguage];

  const languageNames = {
    ru: 'Русский',
    uz: 'O\'zbekcha',
    de: 'Deutsch',
    en: 'English'
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <header className="bg-gradient-to-r from-[#2E8B57] to-[#4A90E2] text-white py-8">
        <div className="container mx-auto px-6">
          <div className="flex justify-between items-start">
            <div className="flex-1">
              <h1 className="text-4xl font-bold mb-2">{currentContent.name}</h1>
              <p className="text-xl opacity-90 mb-2">{currentContent.subtitle}</p>
              <p className="text-sm opacity-80 font-mono">{currentContent.did}</p>
              <p className="text-lg mt-2 font-medium">{currentContent.status}</p>
            </div>
            
            {/* Language Switcher */}
            <div className="flex gap-2 ml-6">
              {Object.keys(content).map(lang => (
                <button
                  key={lang}
                  onClick={() => setActiveLanguage(lang)}
                  className={`px-3 py-1 rounded text-sm font-medium transition-all ${
                    activeLanguage === lang 
                      ? 'bg-white text-[#2E8B57] shadow-md' 
                      : 'bg-white/20 hover:bg-white/30'
                  }`}
                >
                  {languageNames[lang]}
                </button>
              ))}
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-6 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            
            {/* Personal Information */}
            <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-[#2E8B57]">
              <h2 className="text-2xl font-bold mb-4 text-[#2C3E50] flex items-center gap-2">
                <Users className="text-[#2E8B57]" size={24} />
                {currentContent.sections.personal.title}
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <span className="font-medium text-[#2C3E50]">ФИО:</span>
                    <span className="text-gray-700">{currentContent.sections.personal.fullName}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar size={16} className="text-[#7B66DC]" />
                    <span className="text-gray-700">{currentContent.sections.personal.birthDate}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Heart size={16} className="text-[#FF8C42]" />
                    <span className="text-gray-700">{currentContent.sections.personal.familyStatus}</span>
                  </div>
                </div>
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <MapPin size={16} className="text-[#2E8B57]" />
                    <span className="text-gray-700">{currentContent.sections.personal.location}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Phone size={16} className="text-[#4A90E2]" />
                    <span className="text-gray-700">{currentContent.sections.personal.phone}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Mail size={16} className="text-[#7B66DC]" />
                    <span className="text-gray-700">{currentContent.sections.personal.email}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Language Competencies */}
            <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-[#4A90E2]">
              <h2 className="text-2xl font-bold mb-4 text-[#2C3E50] flex items-center gap-2">
                <Languages className="text-[#4A90E2]" size={24} />
                {currentContent.sections.languages.title}
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div className="p-4 bg-gradient-to-r from-red-50 to-yellow-50 rounded-lg border border-red-200">
                    <h3 className="font-bold text-red-800 mb-2">🇩🇪 {currentContent.sections.languages.german.title}</h3>
                    <p className="text-sm text-red-700 mb-2">{currentContent.sections.languages.german.level}</p>
                    <ul className="text-xs text-red-600 space-y-1">
                      {currentContent.sections.languages.german.achievements.map((achievement, idx) => (
                        <li key={idx} className="flex items-start gap-2">
                          <CheckCircle size={12} className="text-green-600 mt-0.5 flex-shrink-0" />
                          {achievement}
                        </li>
                      ))}
                    </ul>
                  </div>
                  
                  <div className="p-4 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg border border-blue-200">
                    <h3 className="font-bold text-blue-800 mb-2">🇬🇧 {currentContent.sections.languages.english.title}</h3>
                    <p className="text-sm text-blue-700">{currentContent.sections.languages.english.level}</p>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div className="p-4 bg-gradient-to-r from-blue-50 to-white-50 rounded-lg border border-blue-200">
                    <h3 className="font-bold text-blue-800 mb-2">🇷🇺 {currentContent.sections.languages.russian.title}</h3>
                    <p className="text-sm text-blue-700">{currentContent.sections.languages.russian.level}</p>
                  </div>
                  
                  <div className="p-4 bg-gradient-to-r from-sky-50 to-blue-50 rounded-lg border border-sky-200">
                    <h3 className="font-bold text-sky-800 mb-2">🇺🇿 {currentContent.sections.languages.uzbek.title}</h3>
                    <p className="text-sm text-sky-700">{currentContent.sections.languages.uzbek.level}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Education */}
            <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-[#7B66DC]">
              <h2 className="text-2xl font-bold mb-4 text-[#2C3E50] flex items-center gap-2">
                <BookOpen className="text-[#7B66DC]" size={24} />
                {currentContent.sections.education.title}
              </h2>
              <div className="space-y-4">
                {currentContent.sections.education.items.map((item, idx) => (
                  <div key={idx} className="border-l-2 border-[#7B66DC] pl-4 pb-4">
                    <div className="flex items-center gap-2 mb-2">
                      <div className="bg-[#7B66DC] text-white text-xs font-bold px-2 py-1 rounded">
                        {item.year}
                      </div>
                      <h3 className="font-bold text-[#2C3E50]">{item.institution}</h3>
                    </div>
                    <p className="text-gray-700 mb-1">{item.degree}</p>
                    {item.note && (
                      <p className="text-[#FF8C42] font-medium text-sm">{item.note}</p>
                    )}
                    {item.thesis && (
                      <p className="text-gray-600 text-sm mt-2 italic">
                        <span className="font-medium">Тема научной работы:</span> "{item.thesis}"
                      </p>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Career History */}
            <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-[#FF8C42]">
              <h2 className="text-2xl font-bold mb-4 text-[#2C3E50] flex items-center gap-2">
                <Briefcase className="text-[#FF8C42]" size={24} />
                {currentContent.sections.career.title}
              </h2>
              <div className="space-y-6">
                {currentContent.sections.career.items.map((item, idx) => (
                  <div key={idx} className="border-l-2 border-[#FF8C42] pl-4">
                    <div className="flex items-center gap-2 mb-2">
                      <div className="bg-[#FF8C42] text-white text-xs font-bold px-2 py-1 rounded">
                        {item.years}
                      </div>
                      <h3 className="font-bold text-[#2C3E50]">{item.company}</h3>
                    </div>
                    <p className="text-gray-700 font-medium mb-1">{item.position}</p>
                    <p className="text-[#2E8B57] text-sm">
                      <span className="font-medium">Достижение:</span> {item.achievement}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Key Competencies */}
            <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-[#2E8B57]">
              <h2 className="text-2xl font-bold mb-4 text-[#2C3E50] flex items-center gap-2">
                <Target className="text-[#2E8B57]" size={24} />
                {currentContent.sections.competencies.title}
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <h3 className="font-bold text-[#2C3E50] mb-2">{currentContent.sections.competencies.linguistic.title}</h3>
                    <ul className="space-y-1">
                      {currentContent.sections.competencies.linguistic.items.map((item, idx) => (
                        <li key={idx} className="flex items-start gap-2 text-sm">
                          <CheckCircle size={14} className="text-[#2E8B57] mt-0.5 flex-shrink-0" />
                          {item}
                        </li>
                      ))}
                    </ul>
                  </div>
                  
                  <div>
                    <h3 className="font-bold text-[#2C3E50] mb-2">{currentContent.sections.competencies.diplomatic.title}</h3>
                    <ul className="space-y-1">
                      {currentContent.sections.competencies.diplomatic.items.map((item, idx) => (
                        <li key={idx} className="flex items-start gap-2 text-sm">
                          <CheckCircle size={14} className="text-[#4A90E2] mt-0.5 flex-shrink-0" />
                          {item}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <h3 className="font-bold text-[#2C3E50] mb-2">{currentContent.sections.competencies.research.title}</h3>
                    <ul className="space-y-1">
                      {currentContent.sections.competencies.research.items.map((item, idx) => (
                        <li key={idx} className="flex items-start gap-2 text-sm">
                          <CheckCircle size={14} className="text-[#7B66DC] mt-0.5 flex-shrink-0" />
                          {item}
                        </li>
                      ))}
                    </ul>
                  </div>
                  
                  <div>
                    <h3 className="font-bold text-[#2C3E50] mb-2">{currentContent.sections.competencies.technical.title}</h3>
                    <ul className="space-y-1">
                      {currentContent.sections.competencies.technical.items.map((item, idx) => (
                        <li key={idx} className="flex items-start gap-2 text-sm">
                          <CheckCircle size={14} className="text-[#FF8C42] mt-0.5 flex-shrink-0" />
                          {item}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            </div>

            {/* Publications */}
            <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-[#7B66DC]">
              <h2 className="text-2xl font-bold mb-4 text-[#2C3E50] flex items-center gap-2">
                <FileText className="text-[#7B66DC]" size={24} />
                {currentContent.sections.publications.title}
              </h2>
              <div className="space-y-4">
                {currentContent.sections.publications.items.map((item, idx) => (
                  <div key={idx} className="p-4 bg-gradient-to-r from-purple-50 to-indigo-50 rounded-lg border border-purple-200">
                    <h3 className="font-bold text-[#7B66DC] mb-2">"{item.title}"</h3>
                    <p className="text-sm text-gray-700 mb-1">
                      <span className="font-medium">Статус:</span> {item.status}
                    </p>
                    {item.innovation && (
                      <p className="text-sm text-gray-700 mb-1">
                        <span className="font-medium">Инновация:</span> {item.innovation}
                      </p>
                    )}
                    {item.description && (
                      <p className="text-sm text-gray-700 mb-1">
                        <span className="font-medium">Описание:</span> {item.description}
                      </p>
                    )}
                    {item.languages && (
                      <p className="text-sm text-gray-700 mb-1">
                        <span className="font-medium">Языки:</span> {item.languages}
                      </p>
                    )}
                    {item.features && (
                      <p className="text-sm text-gray-700">
                        <span className="font-medium">Особенности:</span> {item.features}
                      </p>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* AIUZ-Terra Ecosystem */}
            <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-[#2E8B57]">
              <h2 className="text-2xl font-bold mb-4 text-[#2C3E50] flex items-center gap-2">
                <Zap className="text-[#2E8B57]" size={24} />
                {currentContent.sections.ecosystem.title}
              </h2>
              
              <div className="mb-6">
                <h3 className="font-bold text-[#2C3E50] mb-3">Созданные системы:</h3>
                <ul className="space-y-2">
                  {currentContent.sections.ecosystem.systems.map((system, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <CheckCircle size={16} className="text-[#2E8B57] mt-0.5 flex-shrink-0" />
                      <span className="text-gray-700 text-sm">{system}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <h3 className="font-bold text-[#2C3E50] mb-3">{currentContent.sections.ecosystem.principles.title}:</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {currentContent.sections.ecosystem.principles.items.map((principle, idx) => (
                    <div key={idx} className="p-3 bg-gradient-to-r from-green-50 to-teal-50 rounded-lg border border-green-200">
                      <h4 className="font-bold text-[#2E8B57] text-sm mb-1">{principle.title}</h4>
                      <p className="text-xs text-gray-600">{principle.description}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Uniqueness */}
            <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-[#FF8C42]">
              <h2 className="text-2xl font-bold mb-4 text-[#2C3E50] flex items-center gap-2">
                <Star className="text-[#FF8C42]" size={24} />
                {currentContent.sections.uniqueness.title}
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {currentContent.sections.uniqueness.items.map((item, idx) => (
                  <div key={idx} className="flex items-start gap-3 p-3 bg-gradient-to-r from-orange-50 to-yellow-50 rounded-lg">
                    <div className="bg-[#FF8C42] text-white text-xs font-bold w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0">
                      {idx + 1}
                    </div>
                    <p className="text-sm text-gray-700">{item}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Terra Compliance */}
            <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-[#2E8B57]">
              <h2 className="text-2xl font-bold mb-4 text-[#2C3E50] flex items-center gap-2">
                <Shield className="text-[#2E8B57]" size={24} />
                {currentContent.sections.compliance.title}
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {currentContent.sections.compliance.items.map((item, idx) => (
                  <div key={idx} className="flex items-center gap-3 p-3 bg-gradient-to-r from-green-50 to-emerald-50 rounded-lg border border-green-200">
                    <CheckCircle className="text-green-600 flex-shrink-0" size={20} />
                    <div>
                      <h4 className="font-bold text-[#2E8B57] text-sm">{item.title}</h4>
                      <p className="text-xs text-gray-600">{item.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-8">
            {/* Contact Information */}
            <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-[#4A90E2]">
              <h3 className="text-xl font-bold mb-4 text-[#2C3E50] flex items-center gap-2">
                <Mail className="text-[#4A90E2]" size={20} />
                {currentContent.sections.contact.title}
              </h3>
              
              <div className="space-y-4 text-sm">
                <div>
                  <h4 className="font-bold text-[#2C3E50] mb-2">{currentContent.sections.contact.main.title}:</h4>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Mail size={14} className="text-[#4A90E2]" />
                      <span className="text-gray-700">{currentContent.sections.contact.main.email}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Phone size={14} className="text-[#2E8B57]" />
                      <span className="text-gray-700">{currentContent.sections.contact.main.phone}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <MapPin size={14} className="text-[#FF8C42]" />
                      <span className="text-gray-700">{currentContent.sections.contact.main.location}</span>
                    </div>
                    <p className="text-[#2E8B57] text-xs mt-2">{currentContent.sections.contact.main.relocation}</p>
                  </div>
                </div>
                
                <div>
                  <h4 className="font-bold text-[#2C3E50] mb-2">{currentContent.sections.contact.professional.title}:</h4>
                  <div className="space-y-1 text-xs">
                    <div className="flex justify-between">
                      <span className="text-gray-600">ORCID:</span>
                      <span className="text-gray-700">{currentContent.sections.contact.professional.orcid}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">F6S:</span>
                      <span className="text-gray-700">{currentContent.sections.contact.professional.f6s}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">ProZ:</span>
                      <span className="text-gray-700">{currentContent.sections.contact.professional.proz}</span>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="font-bold text-[#2C3E50] mb-2">{currentContent.sections.contact.availability.title}:</h4>
                  <ul className="space-y-1">
                    {currentContent.sections.contact.availability.items.map((item, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-xs">
                        <CheckCircle size={12} className="text-green-600 mt-0.5 flex-shrink-0" />
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>

            {/* Documents Gallery */}
            <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-[#7B66DC]">
              <h3 className="text-xl font-bold mb-4 text-[#2C3E50]">📂 Документы и сертификаты</h3>
              <div className="grid grid-cols-1 gap-4">
                <div className="p-3 bg-gray-50 rounded-lg">
                  <img src="S8APkLZ_4vHBto7h" alt="Диплом УзГУМЯ" className="w-full h-32 object-cover rounded mb-2" />
                  <p className="text-xs text-gray-600 font-medium">Диплом УзГУМЯ (1999)</p>
                </div>
                
                <div className="p-3 bg-gray-50 rounded-lg">
                  <img src="VeuJpvUo78iyXseV" alt="DAAD Stipendienurkunde" className="w-full h-32 object-cover rounded mb-2" />
                  <p className="text-xs text-gray-600 font-medium">DAAD Stipendienurkunde (1997)</p>
                </div>
                
                <div className="p-3 bg-gray-50 rounded-lg">
                  <img src="uSL7gn4jT0Ra8bxp" alt="DSH Zeugnis" className="w-full h-32 object-cover rounded mb-2" />
                  <p className="text-xs text-gray-600 font-medium">DSH Zeugnis - Humboldt (1998)</p>
                </div>
                
                <div className="p-3 bg-gray-50 rounded-lg">
                  <img src="GEEu12Zx7-dXCbaV" alt="Научные публикации" className="w-full h-32 object-cover rounded mb-2" />
                  <p className="text-xs text-gray-600 font-medium">Научные публикации</p>
                </div>
              </div>
            </div>

            {/* QR Verification */}
            <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-[#2C3E50]">
              <h3 className="text-xl font-bold mb-4 text-[#2C3E50]">🔍 Верификация</h3>
              <div className="text-center">
                <img src="XMAfgejuUbsUbqw7" alt="QR коды верификации" className="w-full max-w-[200px] mx-auto rounded-lg mb-3" />
                <p className="text-xs text-gray-600">QR коды для верификации документов</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-[#2C3E50] text-white py-6 mt-12">
        <div className="container mx-auto px-6">
          <div className="text-center">
            <p className="text-sm opacity-75 mb-2">
              Универсальное портфолио создано согласно Terra Document Protocol v2.0
            </p>
            <p className="text-xs opacity-60">
              Этот проект является результатом совместной работы человека и искусственного интеллекта 
              во благо будущего планеты и человечества
            </p>
            <div className="mt-4 text-xs opacity-50">
              null === (human ∧ AI) → future(planet ∧ humanity)
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Portfolio;