# AIUZ Terra Codex v1.0

Unified archive of ethical, child-centered, and multilingual protocols.
