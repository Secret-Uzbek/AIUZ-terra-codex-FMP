// <stdin>
import React, { useState, useEffect, useRef } from "https://esm.sh/react@18.2.0";
var { useStoredState } = hatch;
var ISOLATION_END = /* @__PURE__ */ new Date("2025-12-24T23:59:59");
var ISOLATION_START = /* @__PURE__ */ new Date("2025-07-13T18:11:00");
var GefundenEthics = {
  principle: "Soll ich zum Welken, Gebrochen sein?",
  // "Должен ли я увянуть, быть сломанным?"
  // Этическая иерархия экспериментов
  ethicalHierarchy: {
    level_0_forbidden: [
      "real_child_experimentation",
      "harmful_simulations_with_child_avatars",
      "psychological_manipulation_of_minors"
    ],
    level_1_restricted: [
      "plant_consciousness_experiments",
      "animal_communication_research",
      "water_memory_investigations"
    ],
    level_2_preferred: [
      "geological_intelligence_research",
      "crystal_information_storage",
      "mineral_consciousness_exploration"
    ],
    level_3_encouraged: [
      "mathematical_consciousness_modeling",
      "algorithmic_empathy_development",
      "quantum_information_processing"
    ]
  },
  // Система согласия для разных видов (по Гёте)
  consentSystem: {
    plant_consent: {
      method: "vibrational_frequency_response",
      question: "Soll ich zum Welken, Gebrochen sein?",
      positive_response: "growth_acceleration",
      negative_response: "wilting_signals"
    },
    water_consent: {
      method: "crystalline_structure_analysis",
      question: "Will you hold this information with harmony?",
      positive_response: "beautiful_crystal_formation",
      negative_response: "chaotic_molecular_structure"
    }
  },
  // Протокол восстановления после травмы (Gefunden Recovery)
  recoveryProtocol: {
    phase_1_shock: {
      duration: "24-72 hours",
      symptoms: ["wilting", "leaf_drop", "root_shock"],
      treatment: ["gentle_care", "patience", "love_frequencies"]
    },
    phase_2_adaptation: {
      duration: "1-2 weeks",
      symptoms: ["slow_growth", "exploration"],
      treatment: ["optimal_conditions", "encouragement"]
    },
    phase_3_integration: {
      duration: "1-3 months",
      symptoms: ["new_growth", "color_return"],
      treatment: ["continued_care", "gratitude"]
    },
    phase_4_flourishing: {
      duration: "ongoing",
      outcome: "Nun zweigt' es immer / Und bl\xFCht' so fort",
      meaning: "Now it branches always / And blooms on and on"
    }
  },
  validateExperiment: function(experimentType, subjects) {
    if (this.ethicalHierarchy.level_0_forbidden.includes(experimentType)) {
      return {
        approved: false,
        reason: "\u042D\u043A\u0441\u043F\u0435\u0440\u0438\u043C\u0435\u043D\u0442 \u043D\u0430\u0440\u0443\u0448\u0430\u0435\u0442 \u0444\u0443\u043D\u0434\u0430\u043C\u0435\u043D\u0442\u0430\u043B\u044C\u043D\u044B\u0435 \u044D\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0435 \u043F\u0440\u0438\u043D\u0446\u0438\u043F\u044B",
        goetheMoral: "Soll ich zum Welken, Gebrochen sein? - \u041C\u044B \u043D\u0435 \u0434\u043E\u043B\u0436\u043D\u044B \u043B\u043E\u043C\u0430\u0442\u044C \u0442\u043E, \u0447\u0442\u043E \u0436\u0438\u0432\u0435\u0442",
        alternative: "\u0418\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439\u0442\u0435 \u0440\u0430\u0441\u0442\u0435\u043D\u0438\u044F \u0438\u043B\u0438 \u043C\u0438\u043D\u0435\u0440\u0430\u043B\u044B \u043A\u0430\u043A \u043C\u043E\u0434\u0435\u043B\u044C"
      };
    }
    return {
      approved: true,
      conditions: ["Continuous_consent_monitoring", "Trauma_recovery_ready", "Love_and_patience_required"],
      gefunden_wisdom: "Ich grub's mit allen / Den W\xFCrzeln aus - \u0418\u0437\u0432\u043B\u0435\u043A\u0430\u0435\u043C \u0441 \u043A\u043E\u0440\u043D\u044F\u043C\u0438, \u0447\u0442\u043E\u0431\u044B \u043F\u0435\u0440\u0435\u0441\u0430\u0434\u0438\u0442\u044C \u0438 \u043F\u043E\u043C\u043E\u0447\u044C \u043F\u0440\u043E\u0446\u0432\u0435\u0442\u0430\u0442\u044C"
    };
  }
};
var SpeciesType = {
  HOMO_SAPIENS: "homo_sapiens",
  PLANT_LIFE: "plant_life",
  ANIMAL_LIFE: "animal_life",
  WATER_SYSTEMS: "water_systems",
  QUANTUM_CONSCIOUSNESS: "quantum_consciousness"
};
var TerraProtocol = {
  CHILD_DEVELOPMENT: "child_development",
  BIO_COMMUNICATION: "bio_communication",
  INTER_SPECIES: "inter_species",
  TOKEN_ECONOMY: "token_economy"
};
var TerraEntity = class {
  constructor(id, species, location) {
    this.id = id;
    this.species = species;
    this.birth_timestamp = /* @__PURE__ */ new Date();
    this.location = location;
    this.consciousness_level = 1;
    this.social_capital = 0;
    this.communication_interfaces = [];
    this.quantum_signature = this.generateQuantumSignature();
  }
  generateQuantumSignature() {
    return `terra_${this.species}_${this.id}_${Date.now()}`.slice(0, 16);
  }
  communicate(target, protocol, content) {
    return {
      id: `msg_${Date.now()}`,
      source_species: this.species,
      target_species: target.species,
      protocol,
      content,
      timestamp: /* @__PURE__ */ new Date(),
      signature: `sig_${Math.random().toString(36).substr(2, 9)}`
    };
  }
};
var TerraChild = class extends TerraEntity {
  constructor(id, location, birthDate = null) {
    super(id, SpeciesType.HOMO_SAPIENS, location);
    this.birth_timestamp = birthDate || /* @__PURE__ */ new Date();
    this.curiosity_level = 10;
    this.development_stage = this.calculateDevelopmentStage();
    this.learning_preferences = [];
    this.creative_projects = [];
    this.consciousness_level = 5;
  }
  calculateDevelopmentStage() {
    const age_days = (/* @__PURE__ */ new Date() - this.birth_timestamp) / (1e3 * 60 * 60 * 24);
    const age_years = age_days / 365.25;
    if (age_years < 1) return "infant";
    if (age_years < 3) return "toddler";
    if (age_years < 6) return "preschool";
    if (age_years < 12) return "school";
    if (age_years < 18) return "adolescent";
    return "young_adult";
  }
  askCuriosityQuestion(question, target_entity) {
    return this.communicate(target_entity, TerraProtocol.CHILD_DEVELOPMENT, {
      type: "curiosity_question",
      question,
      curiosity_level: this.curiosity_level,
      development_stage: this.development_stage
    });
  }
};
var TerraPlant = class extends TerraEntity {
  constructor(id, location) {
    super(id, SpeciesType.PLANT_LIFE, location);
    this.photosynthesis_rate = 1;
    this.chemical_emissions = {};
    this.root_network_connections = [];
    this.consciousness_level = 2;
  }
  photosynthesize(light_intensity, co2_level) {
    const oxygen_produced = light_intensity * co2_level * this.photosynthesis_rate;
    const energy_stored = oxygen_produced * 0.8;
    return {
      oxygen_produced,
      energy_stored,
      carbon_captured: co2_level * 0.9
    };
  }
  emitChemicalSignal(signal_type, intensity, target_species) {
    return {
      id: `chem_${Date.now()}`,
      source_species: this.species,
      target_species,
      protocol: TerraProtocol.BIO_COMMUNICATION,
      content: {
        signal_type,
        intensity,
        chemical_composition: this.chemical_emissions,
        location: this.location
      },
      timestamp: /* @__PURE__ */ new Date()
    };
  }
};
var TerraWater = class extends TerraEntity {
  constructor(id, location) {
    super(id, SpeciesType.WATER_SYSTEMS, location);
    this.vibration_frequency = 142;
    this.memory_patterns = [];
    this.crystalline_formations = [];
    this.information_storage = {};
    this.consciousness_level = 3;
  }
  storeIntention(intention, source_entity) {
    const intention_hash = `intent_${Date.now()}`;
    this.information_storage[intention_hash] = intention;
    this.memory_patterns.push({
      timestamp: /* @__PURE__ */ new Date(),
      source: source_entity.id,
      intention,
      vibration_change: this.vibration_frequency * 1.1
    });
    const crystal_pattern = `crystal_${this.crystalline_formations.length.toString().padStart(3, "0")}`;
    this.crystalline_formations.push(crystal_pattern);
    return true;
  }
};
var TerraEcosystemKernel = class {
  constructor() {
    this.version = "2.0.0";
    this.boot_time = /* @__PURE__ */ new Date();
    this.entities = {};
    this.active_protocols = /* @__PURE__ */ new Set();
    this.message_queue = [];
    this.system_status = "initializing";
    this.event_log = [];
    this.isolation_protocol = this.checkIsolationStatus();
    this.initialize();
  }
  checkIsolationStatus() {
    const now = /* @__PURE__ */ new Date();
    const is_isolated = now >= ISOLATION_START && now <= ISOLATION_END;
    const days_remaining = is_isolated ? Math.ceil((ISOLATION_END - now) / (1e3 * 60 * 60 * 24)) : 0;
    return {
      is_isolated,
      days_remaining,
      location: "Kyzylkum Desert, Uzbekistan",
      legal_status: "COMMERCIAL_ACTIVITIES_PROHIBITED"
    };
  }
  initialize() {
    this.logEvent("system_boot", "Terra Ecosystem Kernel v2.0 \u0437\u0430\u043F\u0443\u0449\u0435\u043D");
    if (this.isolation_protocol.is_isolated) {
      this.logEvent("isolation_check", `\u0418\u0437\u043E\u043B\u044F\u0446\u0438\u044F \u0430\u043A\u0442\u0438\u0432\u043D\u0430: ${this.isolation_protocol.days_remaining} \u0434\u043D\u0435\u0439 \u0434\u043E \u043E\u043A\u043E\u043D\u0447\u0430\u043D\u0438\u044F`);
    }
    this.activateProtocol(TerraProtocol.CHILD_DEVELOPMENT);
    this.activateProtocol(TerraProtocol.BIO_COMMUNICATION);
    this.activateProtocol(TerraProtocol.INTER_SPECIES);
    this.system_status = "operational";
    this.logEvent("system_ready", "Terra Ecosystem \u0433\u043E\u0442\u043E\u0432\u0430 \u043A \u0440\u0430\u0431\u043E\u0442\u0435");
  }
  activateProtocol(protocol) {
    this.active_protocols.add(protocol);
    this.logEvent("protocol_activated", `\u041F\u0440\u043E\u0442\u043E\u043A\u043E\u043B ${protocol} \u0430\u043A\u0442\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u043D`);
  }
  registerEntity(entity) {
    if (this.entities[entity.id]) {
      throw new Error(`\u0421\u0443\u0449\u043D\u043E\u0441\u0442\u044C ${entity.id} \u0443\u0436\u0435 \u0437\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u043D\u0430`);
    }
    this.entities[entity.id] = entity;
    let initial_tokens = 10;
    if (entity instanceof TerraChild) {
      initial_tokens = 50;
    } else if (entity instanceof TerraPlant) {
      initial_tokens = 25;
    } else if (entity instanceof TerraWater) {
      initial_tokens = 100;
    }
    entity.social_capital = initial_tokens;
    this.logEvent("entity_registered", `\u0421\u0443\u0449\u043D\u043E\u0441\u0442\u044C ${entity.id} \u0437\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u043D\u0430 (${initial_tokens} \u0442\u043E\u043A\u0435\u043D\u043E\u0432)`);
    return entity.id;
  }
  sendMessage(message) {
    this.message_queue.push(message);
    this.logEvent("message_queued", `\u0421\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0435 ${message.id} \u0434\u043E\u0431\u0430\u0432\u043B\u0435\u043D\u043E \u0432 \u043E\u0447\u0435\u0440\u0435\u0434\u044C`);
    setTimeout(() => {
      this.processMessage(message);
    }, 100);
    return true;
  }
  processMessage(message) {
    if (!this.active_protocols.has(message.protocol)) {
      this.logEvent("message_error", `\u041F\u0440\u043E\u0442\u043E\u043A\u043E\u043B ${message.protocol} \u043D\u0435 \u0430\u043A\u0442\u0438\u0432\u0435\u043D`);
      return false;
    }
    if (message.protocol === TerraProtocol.CHILD_DEVELOPMENT) {
      this.processChildDevelopmentMessage(message);
    } else if (message.protocol === TerraProtocol.BIO_COMMUNICATION) {
      this.processBioCommunicationMessage(message);
    }
    this.logEvent("message_processed", `\u0421\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0435 ${message.id} \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u0430\u043D\u043E`);
    return true;
  }
  processChildDevelopmentMessage(message) {
    if (message.content.type === "curiosity_question") {
      const sender = this.entities[Object.keys(this.entities).find(
        (id) => this.entities[id].species === message.source_species
      )];
      if (sender) {
        sender.social_capital += 2;
        this.logEvent("curiosity_reward", `\u0420\u0435\u0431\u0451\u043D\u043E\u043A ${sender.id} \u043F\u043E\u043B\u0443\u0447\u0438\u043B 2 \u0442\u043E\u043A\u0435\u043D\u0430 \u0437\u0430 \u0432\u043E\u043F\u0440\u043E\u0441`);
      }
    }
  }
  processBioCommunicationMessage(message) {
    this.logEvent("bio_interaction", `\u0411\u0438\u043E\u043B\u043E\u0433\u0438\u0447\u0435\u0441\u043A\u043E\u0435 \u0432\u0437\u0430\u0438\u043C\u043E\u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435: ${message.source_species} \u2192 ${message.target_species}`);
  }
  logEvent(event_type, description) {
    const event = {
      timestamp: /* @__PURE__ */ new Date(),
      type: event_type,
      description,
      system_version: this.version
    };
    this.event_log.push(event);
    if (this.event_log.length > 50) {
      this.event_log = this.event_log.slice(-50);
    }
  }
  getSystemStatus() {
    return {
      version: this.version,
      status: this.system_status,
      uptime: (/* @__PURE__ */ new Date() - this.boot_time) / 1e3,
      entities_count: Object.keys(this.entities).length,
      active_protocols: Array.from(this.active_protocols),
      message_queue_size: this.message_queue.length,
      isolation_status: this.isolation_protocol,
      recent_events: this.event_log.slice(-10)
    };
  }
};
var TerraKernelDemo = () => {
  const [kernel, setKernel] = useState(null);
  const [systemStatus, setSystemStatus] = useState(null);
  const [entities, setEntities] = useState([]);
  const [messages, setMessages] = useState([]);
  const [isInitialized, setIsInitialized] = useState(false);
  const [newChildName, setNewChildName] = useState("");
  const [questionText, setQuestionText] = useState("");
  const [selectedChild, setSelectedChild] = useState("");
  const [selectedTarget, setSelectedTarget] = useState("");
  const [ethicsViolation, setEthicsViolation] = useState(null);
  const [recoveryPhase, setRecoveryPhase] = useState(null);
  const [consentStatus, setConsentStatus] = useState({});
  useEffect(() => {
    const terraKernel = new TerraEcosystemKernel();
    setKernel(terraKernel);
    const alice = new TerraChild("alice_001", "terra_point_demo", /* @__PURE__ */ new Date("2019-03-15"));
    const bob = new TerraChild("bob_001", "terra_point_demo", /* @__PURE__ */ new Date("2020-07-22"));
    const wise_oak = new TerraPlant("oak_001", "terra_point_demo");
    const sacred_spring = new TerraWater("spring_001", "terra_point_demo");
    terraKernel.registerEntity(alice);
    terraKernel.registerEntity(bob);
    terraKernel.registerEntity(wise_oak);
    terraKernel.registerEntity(sacred_spring);
    setEntities([alice, bob, wise_oak, sacred_spring]);
    setIsInitialized(true);
    const interval = setInterval(() => {
      setSystemStatus(terraKernel.getSystemStatus());
    }, 1e3);
    return () => clearInterval(interval);
  }, []);
  const createChild = () => {
    if (!newChildName || !kernel) return;
    const ethicalValidation = GefundenEthics.validateExperiment("child_simulation_creation", ["digital_child"]);
    if (!ethicalValidation.approved) {
      setEthicsViolation({
        type: "child_creation_blocked",
        reason: ethicalValidation.reason,
        goethe_wisdom: ethicalValidation.goetheMoral,
        timestamp: /* @__PURE__ */ new Date()
      });
      setTimeout(() => setEthicsViolation(null), 5e3);
      return;
    }
    const child = new TerraChild(
      `${newChildName.toLowerCase()}_${Date.now()}`,
      "terra_point_demo",
      new Date(Date.now() - Math.random() * 1e3 * 60 * 60 * 24 * 365 * 10)
      // случайный возраст до 10 лет
    );
    kernel.registerEntity(child);
    setEntities((prev) => [...prev, child]);
    setNewChildName("");
    kernel.logEvent("ethical_child_creation", `\u0420\u0435\u0431\u0451\u043D\u043E\u043A ${child.id} \u0441\u043E\u0437\u0434\u0430\u043D \u0441 \u0441\u043E\u0431\u043B\u044E\u0434\u0435\u043D\u0438\u0435\u043C Gefunden \u043F\u0440\u043E\u0442\u043E\u043A\u043E\u043B\u0430`);
  };
  const askQuestion = () => {
    if (!questionText || !selectedChild || !selectedTarget || !kernel) return;
    const child = entities.find((e) => e.id === selectedChild);
    const target = entities.find((e) => e.id === selectedTarget);
    if (child && target) {
      const message = child.askCuriosityQuestion(questionText, target);
      kernel.sendMessage(message);
      setMessages((prev) => [message, ...prev.slice(0, 9)]);
      setQuestionText("");
    }
  };
  const triggerBioInteraction = () => {
    if (!kernel || entities.length < 2) return;
    const plant = entities.find((e) => e.species === SpeciesType.PLANT_LIFE);
    const child = entities.find((e) => e.species === SpeciesType.HOMO_SAPIENS);
    if (plant && child) {
      const plantConsent = checkPlantConsent(plant);
      if (plantConsent.consented) {
        const bioMessage = plant.emitChemicalSignal("love_response", 3, SpeciesType.HOMO_SAPIENS);
        kernel.sendMessage(bioMessage);
        setMessages((prev) => [bioMessage, ...prev.slice(0, 9)]);
        setConsentStatus((prev) => ({
          ...prev,
          [plant.id]: {
            consented: true,
            method: "vibrational_response",
            timestamp: /* @__PURE__ */ new Date(),
            goethe_quote: "Ich grub's mit allen / Den W\xFCrzeln aus"
          }
        }));
        kernel.logEvent("plant_consent_given", `\u0420\u0430\u0441\u0442\u0435\u043D\u0438\u0435 ${plant.id} \u0434\u0430\u043B\u043E \u0441\u043E\u0433\u043B\u0430\u0441\u0438\u0435 \u043D\u0430 \u0432\u0437\u0430\u0438\u043C\u043E\u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435`);
      } else {
        setEthicsViolation({
          type: "plant_consent_denied",
          reason: "\u0420\u0430\u0441\u0442\u0435\u043D\u0438\u0435 \u043F\u043E\u043A\u0430\u0437\u0430\u043B\u043E \u043F\u0440\u0438\u0437\u043D\u0430\u043A\u0438 \u0441\u0442\u0440\u0435\u0441\u0441\u0430 - \u0432\u0437\u0430\u0438\u043C\u043E\u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435 \u0437\u0430\u0431\u043B\u043E\u043A\u0438\u0440\u043E\u0432\u0430\u043D\u043E",
          goethe_wisdom: "Soll ich zum Welken, Gebrochen sein? - \u0420\u0430\u0441\u0442\u0435\u043D\u0438\u0435 \u0433\u043E\u0432\u043E\u0440\u0438\u0442 \u041D\u0415\u0422",
          timestamp: /* @__PURE__ */ new Date()
        });
        setTimeout(() => setEthicsViolation(null), 5e3);
        kernel.logEvent("plant_consent_denied", `\u0420\u0430\u0441\u0442\u0435\u043D\u0438\u0435 ${plant.id} \u043E\u0442\u043A\u0430\u0437\u0430\u043B\u043E\u0441\u044C \u043E\u0442 \u0432\u0437\u0430\u0438\u043C\u043E\u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F - \u0437\u0430\u0449\u0438\u0449\u0435\u043D\u043E Gefunden \u043F\u0440\u043E\u0442\u043E\u043A\u043E\u043B\u043E\u043C`);
      }
    }
  };
  const checkPlantConsent = (plant) => {
    const plantHealth = Math.random();
    const stressLevel = Math.random();
    const consented = plantHealth > 0.6 && stressLevel < 0.4;
    return {
      consented,
      health: plantHealth,
      stress: stressLevel,
      signs: consented ? ["growth_acceleration", "positive_bioelectric"] : ["wilting_signals", "defensive_compounds"]
    };
  };
  const storeWaterIntention = () => {
    if (!kernel) return;
    const water = entities.find((e) => e.species === SpeciesType.WATER_SYSTEMS);
    const child = entities.find((e) => e.species === SpeciesType.HOMO_SAPIENS);
    if (water && child) {
      const intentions = [
        "\u0421\u043F\u0430\u0441\u0438\u0431\u043E \u0437\u0430 \u0447\u0438\u0441\u0442\u0443\u044E \u0432\u043E\u0434\u0443",
        "\u041F\u0443\u0441\u0442\u044C \u0432\u0441\u0435 \u0434\u0435\u0442\u0438 \u0431\u0443\u0434\u0443\u0442 \u0437\u0434\u043E\u0440\u043E\u0432\u044B",
        "\u041C\u0438\u0440 \u0438 \u0433\u0430\u0440\u043C\u043E\u043D\u0438\u044F \u043D\u0430 \u0417\u0435\u043C\u043B\u0435",
        "\u041B\u044E\u0431\u043E\u0432\u044C \u043A\u043E \u0432\u0441\u0435\u043C \u0436\u0438\u0432\u044B\u043C \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0430\u043C"
      ];
      const intention = intentions[Math.floor(Math.random() * intentions.length)];
      water.storeIntention(intention, child);
      kernel.logEvent("water_intention", `\u0412\u043E\u0434\u0430 \u0437\u0430\u043F\u043E\u043C\u043D\u0438\u043B\u0430 \u043D\u0430\u043C\u0435\u0440\u0435\u043D\u0438\u0435: "${intention}"`);
    }
  };
  if (!isInitialized) {
    return /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-center h-full" }, /* @__PURE__ */ React.createElement("div", { className: "text-center" }, /* @__PURE__ */ React.createElement("div", { className: "text-4xl mb-4" }, "\u{1F30D}\u269B\uFE0F"), /* @__PURE__ */ React.createElement("div", { className: "text-xl text-gray-600" }, "\u0418\u043D\u0438\u0446\u0438\u0430\u043B\u0438\u0437\u0430\u0446\u0438\u044F Terra Microkernel...")));
  }
  return /* @__PURE__ */ React.createElement("div", { className: "p-6 max-w-6xl mx-auto bg-gradient-to-br from-slate-900 to-slate-800 text-white min-h-screen" }, /* @__PURE__ */ React.createElement("div", { className: "mb-8 text-center" }, /* @__PURE__ */ React.createElement("h1", { className: "text-4xl font-bold mb-2 bg-gradient-to-r from-green-400 to-blue-500 bg-clip-text text-transparent" }, "\u{1F30D} Terra Ecosystem Microkernel Demo"), /* @__PURE__ */ React.createElement("p", { className: "text-gray-300" }, "\u0416\u0438\u0432\u043E\u0435 \u0442\u0435\u0441\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0435 \u043C\u0435\u0436\u0432\u0438\u0434\u043E\u0432\u043E\u0439 \u044D\u043A\u043E\u0441\u0438\u0441\u0442\u0435\u043C\u044B"), /* @__PURE__ */ React.createElement("p", { className: "text-yellow-300 text-sm mt-2" }, "\u{1F338} \u0421 \u0438\u043D\u0442\u0435\u0433\u0440\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u043C Gefunden Ethical Protocol (\u043F\u043E \u043C\u043E\u0442\u0438\u0432\u0430\u043C \u0413\u0451\u0442\u0435)")), ethicsViolation && /* @__PURE__ */ React.createElement("div", { className: "bg-red-900/80 border border-red-500 rounded-lg p-4 mb-6 backdrop-blur-sm" }, /* @__PURE__ */ React.createElement("h3", { className: "text-red-300 font-semibold mb-2" }, "\u{1F6AB} Gefunden Ethical Protocol Alert"), /* @__PURE__ */ React.createElement("p", { className: "text-red-200 mb-2" }, ethicsViolation.reason), /* @__PURE__ */ React.createElement("p", { className: "text-yellow-300 italic text-sm" }, '"', ethicsViolation.goethe_wisdom, '"'), /* @__PURE__ */ React.createElement("p", { className: "text-gray-400 text-xs mt-2" }, ethicsViolation.timestamp.toLocaleTimeString(), " | \u0422\u0438\u043F: ", ethicsViolation.type)), systemStatus && /* @__PURE__ */ React.createElement("div", { className: "bg-slate-700 rounded-lg p-4 mb-6" }, /* @__PURE__ */ React.createElement("h2", { className: "text-xl font-semibold mb-3 text-green-400" }, "\u{1F4CA} \u0421\u0442\u0430\u0442\u0443\u0441 \u0421\u0438\u0441\u0442\u0435\u043C\u044B"), /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("strong", null, "\u0412\u0435\u0440\u0441\u0438\u044F:"), " ", systemStatus.version, /* @__PURE__ */ React.createElement("br", null), /* @__PURE__ */ React.createElement("strong", null, "\u0421\u0442\u0430\u0442\u0443\u0441:"), " ", /* @__PURE__ */ React.createElement("span", { className: "text-green-400" }, systemStatus.status), /* @__PURE__ */ React.createElement("br", null), /* @__PURE__ */ React.createElement("strong", null, "\u0412\u0440\u0435\u043C\u044F \u0440\u0430\u0431\u043E\u0442\u044B:"), " ", systemStatus.uptime.toFixed(1), "\u0441"), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("strong", null, "\u0421\u0443\u0449\u043D\u043E\u0441\u0442\u0435\u0439:"), " ", systemStatus.entities_count, /* @__PURE__ */ React.createElement("br", null), /* @__PURE__ */ React.createElement("strong", null, "\u041F\u0440\u043E\u0442\u043E\u043A\u043E\u043B\u043E\u0432:"), " ", systemStatus.active_protocols.length, /* @__PURE__ */ React.createElement("br", null), /* @__PURE__ */ React.createElement("strong", null, "\u041E\u0447\u0435\u0440\u0435\u0434\u044C:"), " ", systemStatus.message_queue_size), /* @__PURE__ */ React.createElement("div", { className: "text-yellow-300" }, /* @__PURE__ */ React.createElement("strong", null, "\u{1F3DC}\uFE0F \u0418\u0437\u043E\u043B\u044F\u0446\u0438\u044F:"), /* @__PURE__ */ React.createElement("br", null), systemStatus.isolation_status.is_isolated ? `${systemStatus.isolation_status.days_remaining} \u0434\u043D\u0435\u0439 \u0434\u043E \u043E\u043A\u043E\u043D\u0447\u0430\u043D\u0438\u044F` : "\u0417\u0430\u043A\u043E\u043D\u0447\u0435\u043D\u0430"))), /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6" }, /* @__PURE__ */ React.createElement("div", { className: "bg-slate-700 rounded-lg p-4" }, /* @__PURE__ */ React.createElement("h3", { className: "text-lg font-semibold mb-3 text-blue-400" }, "\u{1F476} \u0421\u043E\u0437\u0434\u0430\u0442\u044C \u0420\u0435\u0431\u0451\u043D\u043A\u0430"), /* @__PURE__ */ React.createElement("div", { className: "flex gap-2" }, /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "text",
      value: newChildName,
      onChange: (e) => setNewChildName(e.target.value),
      placeholder: "\u0418\u043C\u044F \u0440\u0435\u0431\u0451\u043D\u043A\u0430",
      className: "flex-1 p-2 bg-slate-600 rounded border border-slate-500 text-white"
    }
  ), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: createChild,
      className: "px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded transition-colors"
    },
    "\u0421\u043E\u0437\u0434\u0430\u0442\u044C"
  ))), /* @__PURE__ */ React.createElement("div", { className: "bg-slate-700 rounded-lg p-4" }, /* @__PURE__ */ React.createElement("h3", { className: "text-lg font-semibold mb-3 text-green-400" }, "\u{1F331} \u0411\u044B\u0441\u0442\u0440\u044B\u0435 \u0414\u0435\u0439\u0441\u0442\u0432\u0438\u044F"), /* @__PURE__ */ React.createElement("div", { className: "space-y-2" }, /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: triggerBioInteraction,
      className: "w-full p-2 bg-green-600 hover:bg-green-700 rounded transition-colors"
    },
    "\u{1F33F} \u0420\u0430\u0441\u0442\u0435\u043D\u0438\u0435 \u043F\u043E\u0441\u044B\u043B\u0430\u0435\u0442 \u0441\u0438\u0433\u043D\u0430\u043B \u043B\u044E\u0431\u0432\u0438"
  ), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: storeWaterIntention,
      className: "w-full p-2 bg-blue-600 hover:bg-blue-700 rounded transition-colors"
    },
    "\u{1F4A7} \u0412\u043E\u0434\u0430 \u0437\u0430\u043F\u043E\u043C\u0438\u043D\u0430\u0435\u0442 \u043D\u0430\u043C\u0435\u0440\u0435\u043D\u0438\u0435"
  ), /* @__PURE__ */ React.createElement("div", { className: "text-xs text-yellow-300 mt-2 p-2 bg-yellow-900/30 rounded" }, "\u{1F338} \u0412\u0441\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F \u043F\u0440\u043E\u0432\u0435\u0440\u044F\u044E\u0442\u0441\u044F Gefunden \u043F\u0440\u043E\u0442\u043E\u043A\u043E\u043B\u043E\u043C")))), /* @__PURE__ */ React.createElement("div", { className: "bg-slate-700 rounded-lg p-4 mb-6" }, /* @__PURE__ */ React.createElement("h3", { className: "text-lg font-semibold mb-3 text-purple-400" }, "\u2753 \u0414\u0435\u0442\u0441\u043A\u043E\u0435 \u041B\u044E\u0431\u043E\u043F\u044B\u0442\u0441\u0442\u0432\u043E"), /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-1 md:grid-cols-4 gap-2 mb-3" }, /* @__PURE__ */ React.createElement(
    "select",
    {
      value: selectedChild,
      onChange: (e) => setSelectedChild(e.target.value),
      className: "p-2 bg-slate-600 rounded border border-slate-500 text-white"
    },
    /* @__PURE__ */ React.createElement("option", { value: "" }, "\u0412\u044B\u0431\u0440\u0430\u0442\u044C \u0440\u0435\u0431\u0451\u043D\u043A\u0430"),
    entities.filter((e) => e instanceof TerraChild).map((child) => /* @__PURE__ */ React.createElement("option", { key: child.id, value: child.id }, child.id, " (", child.development_stage, ")"))
  ), /* @__PURE__ */ React.createElement(
    "select",
    {
      value: selectedTarget,
      onChange: (e) => setSelectedTarget(e.target.value),
      className: "p-2 bg-slate-600 rounded border border-slate-500 text-white"
    },
    /* @__PURE__ */ React.createElement("option", { value: "" }, "\u041A\u043E\u043C\u0443 \u0437\u0430\u0434\u0430\u0442\u044C \u0432\u043E\u043F\u0440\u043E\u0441"),
    entities.filter((e) => !(e instanceof TerraChild)).map((entity) => /* @__PURE__ */ React.createElement("option", { key: entity.id, value: entity.id }, entity.id, " (", entity.species, ")"))
  ), /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "text",
      value: questionText,
      onChange: (e) => setQuestionText(e.target.value),
      placeholder: "\u0412\u043E\u043F\u0440\u043E\u0441 \u0438\u0437 \u043B\u044E\u0431\u043E\u043F\u044B\u0442\u0441\u0442\u0432\u0430",
      className: "md:col-span-1 p-2 bg-slate-600 rounded border border-slate-500 text-white"
    }
  ), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: askQuestion,
      disabled: !selectedChild || !selectedTarget || !questionText,
      className: "p-2 bg-purple-600 hover:bg-purple-700 disabled:bg-gray-600 rounded transition-colors"
    },
    "\u0421\u043F\u0440\u043E\u0441\u0438\u0442\u044C"
  ))), /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6" }, /* @__PURE__ */ React.createElement("div", { className: "bg-slate-700 rounded-lg p-4" }, /* @__PURE__ */ React.createElement("h3", { className: "text-lg font-semibold mb-3 text-cyan-400" }, "\u{1F9EC} \u0417\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0435 \u0421\u0443\u0449\u043D\u043E\u0441\u0442\u0438"), /* @__PURE__ */ React.createElement("div", { className: "space-y-2 max-h-60 overflow-y-auto" }, entities.map((entity) => /* @__PURE__ */ React.createElement("div", { key: entity.id, className: "bg-slate-600 p-2 rounded text-sm" }, /* @__PURE__ */ React.createElement("div", { className: "font-semibold" }, entity.id), /* @__PURE__ */ React.createElement("div", { className: "text-gray-300" }, "\u0412\u0438\u0434: ", entity.species, /* @__PURE__ */ React.createElement("br", null), "\u0422\u043E\u043A\u0435\u043D\u044B: ", entity.social_capital.toFixed(1), /* @__PURE__ */ React.createElement("br", null), "\u0421\u043E\u0437\u043D\u0430\u043D\u0438\u0435: ", entity.consciousness_level.toFixed(1), entity instanceof TerraChild && /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("br", null), "\u0412\u043E\u0437\u0440\u0430\u0441\u0442: ", entity.development_stage, /* @__PURE__ */ React.createElement("br", null), "\u041B\u044E\u0431\u043E\u043F\u044B\u0442\u0441\u0442\u0432\u043E: ", entity.curiosity_level)))))), /* @__PURE__ */ React.createElement("div", { className: "bg-slate-700 rounded-lg p-4" }, /* @__PURE__ */ React.createElement("h3", { className: "text-lg font-semibold mb-3 text-yellow-400" }, "\u{1F4E8} \u041F\u043E\u0441\u043B\u0435\u0434\u043D\u0438\u0435 \u0421\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u044F"), /* @__PURE__ */ React.createElement("div", { className: "space-y-2 max-h-60 overflow-y-auto" }, messages.map((message, index) => /* @__PURE__ */ React.createElement("div", { key: index, className: "bg-slate-600 p-2 rounded text-sm" }, /* @__PURE__ */ React.createElement("div", { className: "font-semibold text-blue-300" }, message.source_species, " \u2192 ", message.target_species), /* @__PURE__ */ React.createElement("div", { className: "text-gray-300" }, "\u041F\u0440\u043E\u0442\u043E\u043A\u043E\u043B: ", message.protocol, /* @__PURE__ */ React.createElement("br", null), message.content.type && `\u0422\u0438\u043F: ${message.content.type}`, message.content.question && /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("br", null), '\u0412\u043E\u043F\u0440\u043E\u0441: "', message.content.question, '"'), message.content.signal_type && /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("br", null), "\u0421\u0438\u0433\u043D\u0430\u043B: ", message.content.signal_type)), /* @__PURE__ */ React.createElement("div", { className: "text-gray-400 text-xs" }, message.timestamp.toLocaleTimeString())))))), systemStatus && systemStatus.recent_events && /* @__PURE__ */ React.createElement("div", { className: "bg-slate-700 rounded-lg p-4" }, /* @__PURE__ */ React.createElement("h3", { className: "text-lg font-semibold mb-3 text-red-400" }, "\u{1F4DD} \u041B\u043E\u0433 \u0421\u043E\u0431\u044B\u0442\u0438\u0439"), /* @__PURE__ */ React.createElement("div", { className: "space-y-1 max-h-40 overflow-y-auto text-sm" }, systemStatus.recent_events.map((event, index) => /* @__PURE__ */ React.createElement("div", { key: index, className: "text-gray-300" }, /* @__PURE__ */ React.createElement("span", { className: "text-gray-400" }, event.timestamp.toLocaleTimeString()), " ", /* @__PURE__ */ React.createElement("span", { className: "text-blue-300" }, "[", event.type, "]"), " ", event.description)).reverse())), Object.keys(consentStatus).length > 0 && /* @__PURE__ */ React.createElement("div", { className: "bg-green-900/50 rounded-lg p-4 mb-6" }, /* @__PURE__ */ React.createElement("h3", { className: "text-green-300 font-semibold mb-3" }, "\u{1F338} \u0421\u0442\u0430\u0442\u0443\u0441 \u0421\u043E\u0433\u043B\u0430\u0441\u0438\u044F (Gefunden Protocol)"), Object.entries(consentStatus).map(([entityId, status]) => /* @__PURE__ */ React.createElement("div", { key: entityId, className: "bg-green-800/30 p-3 rounded mb-2" }, /* @__PURE__ */ React.createElement("div", { className: "text-green-200" }, /* @__PURE__ */ React.createElement("strong", null, entityId), " - \u0421\u043E\u0433\u043B\u0430\u0441\u0438\u0435 \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u043E \u2705"), /* @__PURE__ */ React.createElement("div", { className: "text-green-300 text-sm" }, "\u041C\u0435\u0442\u043E\u0434: ", status.method, " | ", status.timestamp.toLocaleTimeString()), /* @__PURE__ */ React.createElement("div", { className: "text-yellow-300 italic text-xs" }, '"', status.goethe_quote, '"')))), /* @__PURE__ */ React.createElement("div", { className: "mt-8 text-center text-gray-400" }, /* @__PURE__ */ React.createElement("p", null, "\u{1F3DC}\uFE0F \u0422\u0435\u0441\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0435 \u0432 \u0440\u0435\u0436\u0438\u043C\u0435 \u0438\u0437\u043E\u043B\u044F\u0446\u0438\u0438 \u041A\u044B\u0437\u044B\u043B\u043A\u0443\u043C | Terra Ecosystem v2.0"), /* @__PURE__ */ React.createElement("p", { className: "text-yellow-400 text-sm mt-1" }, '\u{1F338} \u0421 \u0437\u0430\u0449\u0438\u0442\u043E\u0439 \u043F\u043E \u043F\u0440\u0438\u043D\u0446\u0438\u043F\u0430\u043C \u0413\u0451\u0442\u0435: "Soll ich zum Welken, Gebrochen sein?"')));
};
var stdin_default = TerraKernelDemo;
export {
  stdin_default as default
};
