// Core app logic
console.log('App loaded');