// <stdin>
import React, { useState, useEffect } from "https://esm.sh/react@18.2.0";
var { useStoredState } = hatch;
var GreenStationPlanner = () => {
  const [currentProject, setCurrentProject] = useStoredState("terra_project", {
    name: "\u0417\u0435\u043B\u0435\u043D\u0430\u044F \u0421\u0442\u0430\u043D\u0446\u0438\u044F \u0422\u0430\u0448\u043A\u0435\u043D\u0442-1",
    location: "\u0422\u0430\u0448\u043A\u0435\u043D\u0442, \u0423\u0437\u0431\u0435\u043A\u0438\u0441\u0442\u0430\u043D",
    climate: "\u043A\u043E\u043D\u0442\u0438\u043D\u0435\u043D\u0442\u0430\u043B\u044C\u043D\u044B\u0439",
    area: 1e3,
    capacity: 500,
    energySource: "solar",
    waterSystem: "recycling",
    materials: ["eco-concrete", "local-stone"],
    budget: 25e4,
    timeline: 18
  });
  const [calculations, setCalculations] = useState({});
  const [language, setLanguage] = useStoredState("terra_language", "ru");
  const translations = {
    ru: {
      title: "\u{1F3D7}\uFE0F \u0410\u0440\u0445\u0438\u0442\u0435\u043A\u0442\u0443\u0440\u043D\u044B\u0439 \u041F\u043B\u0430\u043D\u0438\u0440\u043E\u0432\u0449\u0438\u043A \u0417\u0435\u043B\u0435\u043D\u044B\u0445 \u0421\u0442\u0430\u043D\u0446\u0438\u0439",
      subtitle: "TERRA v6.0 - \u041F\u043B\u0430\u043D\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0435 \u0434\u043B\u044F \u043A\u043B\u0438\u043C\u0430\u0442\u0430 \u0423\u0437\u0431\u0435\u043A\u0438\u0441\u0442\u0430\u043D\u0430",
      project: "\u041F\u0440\u043E\u0435\u043A\u0442",
      location: "\u041C\u0435\u0441\u0442\u043E\u043F\u043E\u043B\u043E\u0436\u0435\u043D\u0438\u0435",
      climate: "\u041A\u043B\u0438\u043C\u0430\u0442",
      area: "\u041F\u043B\u043E\u0449\u0430\u0434\u044C (\u043C\xB2)",
      capacity: "\u0412\u043C\u0435\u0441\u0442\u0438\u043C\u043E\u0441\u0442\u044C (\u0447\u0435\u043B)",
      energySource: "\u0418\u0441\u0442\u043E\u0447\u043D\u0438\u043A \u044D\u043D\u0435\u0440\u0433\u0438\u0438",
      waterSystem: "\u0421\u0438\u0441\u0442\u0435\u043C\u0430 \u0432\u043E\u0434\u043E\u0441\u043D\u0430\u0431\u0436\u0435\u043D\u0438\u044F",
      materials: "\u041C\u0430\u0442\u0435\u0440\u0438\u0430\u043B\u044B",
      budget: "\u0411\u044E\u0434\u0436\u0435\u0442 ($)",
      timeline: "\u0421\u0440\u043E\u043A (\u043C\u0435\u0441\u044F\u0446\u044B)",
      calculate: "\u0420\u0430\u0441\u0441\u0447\u0438\u0442\u0430\u0442\u044C \u043F\u0440\u043E\u0435\u043A\u0442",
      results: "\u0420\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442\u044B \u0440\u0430\u0441\u0447\u0435\u0442\u0430"
    },
    uz: {
      title: "\u{1F3D7}\uFE0F Yashil Stansiyalar Arxitektura Rejalashtiruvchisi",
      subtitle: "TERRA v6.0 - O'zbekiston iqlimi uchun rejalashtirish",
      project: "Loyiha",
      location: "Joylashuv",
      climate: "Iqlim",
      area: "Maydon (m\xB2)",
      capacity: "Sig'im (kishi)",
      energySource: "Energiya manbai",
      waterSystem: "Suv ta'minoti tizimi",
      materials: "Materiallar",
      budget: "Byudjet ($)",
      timeline: "Muddat (oy)",
      calculate: "Loyihani hisoblash",
      results: "Hisoblash natijalari"
    },
    de: {
      title: "\u{1F3D7}\uFE0F Architektur-Planer f\xFCr Gr\xFCne Stationen",
      subtitle: "TERRA v6.0 - Planung f\xFCr Usbekistans Klima",
      project: "Projekt",
      location: "Standort",
      climate: "Klima",
      area: "Fl\xE4che (m\xB2)",
      capacity: "Kapazit\xE4t (Pers.)",
      energySource: "Energiequelle",
      waterSystem: "Wassersystem",
      materials: "Materialien",
      budget: "Budget ($)",
      timeline: "Zeitrahmen (Monate)",
      calculate: "Projekt berechnen",
      results: "Berechnungsergebnisse"
    },
    en: {
      title: "\u{1F3D7}\uFE0F Architectural Planner for Green Stations",
      subtitle: "TERRA v6.0 - Planning for Uzbekistan Climate",
      project: "Project",
      location: "Location",
      climate: "Climate",
      area: "Area (m\xB2)",
      capacity: "Capacity (people)",
      energySource: "Energy Source",
      waterSystem: "Water System",
      materials: "Materials",
      budget: "Budget ($)",
      timeline: "Timeline (months)",
      calculate: "Calculate Project",
      results: "Calculation Results"
    }
  };
  const t = translations[language];
  const climateZones = {
    ru: ["\u043A\u043E\u043D\u0442\u0438\u043D\u0435\u043D\u0442\u0430\u043B\u044C\u043D\u044B\u0439", "\u043F\u0443\u0441\u0442\u044B\u043D\u043D\u044B\u0439", "\u0441\u0442\u0435\u043F\u043D\u043E\u0439", "\u0433\u043E\u0440\u043D\u044B\u0439"],
    uz: ["kontinental", "cho'l", "dasht", "tog'li"],
    de: ["kontinental", "W\xFCste", "Steppe", "Gebirge"],
    en: ["continental", "desert", "steppe", "mountain"]
  };
  const energySources = {
    ru: ["solar", "wind", "geothermal", "hybrid"],
    uz: ["quyosh", "shamol", "geotermal", "gibrid"],
    de: ["Solar", "Wind", "Geothermie", "Hybrid"],
    en: ["solar", "wind", "geothermal", "hybrid"]
  };
  const waterSystems = {
    ru: ["recycling", "rainwater", "groundwater", "mixed"],
    uz: ["qayta ishlash", "yomg'ir suvi", "yer osti suvi", "aralash"],
    de: ["Recycling", "Regenwasser", "Grundwasser", "Gemischt"],
    en: ["recycling", "rainwater", "groundwater", "mixed"]
  };
  const calculateProject = () => {
    const calc = {
      energyNeeds: Math.round(currentProject.area * 0.15 * currentProject.capacity / 100),
      solarPanels: Math.round(currentProject.area * 0.15 * currentProject.capacity / 100 / 0.3),
      waterNeeds: Math.round(currentProject.capacity * 150),
      constructionCost: Math.round(currentProject.area * 450 + currentProject.capacity * 800),
      operationalCost: Math.round((currentProject.area * 450 + currentProject.capacity * 800) * 0.08),
      co2Reduction: Math.round(currentProject.area * 0.025 + currentProject.capacity * 0.5),
      timelineOptimized: Math.max(12, Math.round(currentProject.timeline * 0.85)),
      roi: Math.round((currentProject.budget - (currentProject.area * 450 + currentProject.capacity * 800)) / currentProject.budget * 100)
    };
    setCalculations(calc);
  };
  useEffect(() => {
    calculateProject();
  }, [currentProject]);
  return /* @__PURE__ */ React.createElement("div", { className: "min-h-screen bg-gradient-to-br from-blue-900 via-purple-900 to-green-800 p-6" }, /* @__PURE__ */ React.createElement("div", { className: "max-w-7xl mx-auto" }, /* @__PURE__ */ React.createElement("div", { className: "text-center mb-8" }, /* @__PURE__ */ React.createElement("div", { className: "inline-block bg-yellow-400 text-black px-6 py-2 rounded-full mb-4 font-bold" }, "\u{1F9EC} TERRA v6.0 QUANTUM PLANNER"), /* @__PURE__ */ React.createElement("h1", { className: "text-4xl font-bold text-white mb-2" }, t.title), /* @__PURE__ */ React.createElement("p", { className: "text-xl text-blue-200" }, t.subtitle), /* @__PURE__ */ React.createElement("div", { className: "flex justify-center gap-4 mt-6" }, ["ru", "uz", "de", "en"].map((lang) => /* @__PURE__ */ React.createElement(
    "button",
    {
      key: lang,
      onClick: () => setLanguage(lang),
      className: `px-4 py-2 rounded-lg font-semibold transition-all ${language === lang ? "bg-yellow-400 text-black" : "bg-white/20 text-white hover:bg-white/30"}`
    },
    lang === "ru" && "\u{1F1F7}\u{1F1FA} \u0420\u0423",
    lang === "uz" && "\u{1F1FA}\u{1F1FF} UZ",
    lang === "de" && "\u{1F1E9}\u{1F1EA} DE",
    lang === "en" && "\u{1F1EC}\u{1F1E7} EN"
  )))), /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-1 lg:grid-cols-2 gap-8" }, /* @__PURE__ */ React.createElement("div", { className: "bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20" }, /* @__PURE__ */ React.createElement("h2", { className: "text-2xl font-bold text-white mb-6" }, "\u{1F4CB} ", t.project), /* @__PURE__ */ React.createElement("div", { className: "space-y-4" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("label", { className: "block text-white mb-2" }, t.project, ":"), /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "text",
      value: currentProject.name,
      onChange: (e) => setCurrentProject({ ...currentProject, name: e.target.value }),
      className: "w-full p-3 rounded-lg bg-white/20 text-white placeholder-white/60 border border-white/30"
    }
  )), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("label", { className: "block text-white mb-2" }, t.location, ":"), /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "text",
      value: currentProject.location,
      onChange: (e) => setCurrentProject({ ...currentProject, location: e.target.value }),
      className: "w-full p-3 rounded-lg bg-white/20 text-white placeholder-white/60 border border-white/30"
    }
  )), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("label", { className: "block text-white mb-2" }, t.climate, ":"), /* @__PURE__ */ React.createElement(
    "select",
    {
      value: currentProject.climate,
      onChange: (e) => setCurrentProject({ ...currentProject, climate: e.target.value }),
      className: "w-full p-3 rounded-lg bg-white/20 text-white border border-white/30"
    },
    climateZones[language].map((zone) => /* @__PURE__ */ React.createElement("option", { key: zone, value: zone, className: "bg-gray-800" }, zone))
  )), /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-2 gap-4" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("label", { className: "block text-white mb-2" }, t.area, ":"), /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "number",
      value: currentProject.area,
      onChange: (e) => setCurrentProject({ ...currentProject, area: parseInt(e.target.value) || 0 }),
      className: "w-full p-3 rounded-lg bg-white/20 text-white border border-white/30"
    }
  )), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("label", { className: "block text-white mb-2" }, t.capacity, ":"), /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "number",
      value: currentProject.capacity,
      onChange: (e) => setCurrentProject({ ...currentProject, capacity: parseInt(e.target.value) || 0 }),
      className: "w-full p-3 rounded-lg bg-white/20 text-white border border-white/30"
    }
  ))), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("label", { className: "block text-white mb-2" }, t.energySource, ":"), /* @__PURE__ */ React.createElement(
    "select",
    {
      value: currentProject.energySource,
      onChange: (e) => setCurrentProject({ ...currentProject, energySource: e.target.value }),
      className: "w-full p-3 rounded-lg bg-white/20 text-white border border-white/30"
    },
    energySources[language].map((source) => /* @__PURE__ */ React.createElement("option", { key: source, value: source, className: "bg-gray-800" }, source))
  )), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("label", { className: "block text-white mb-2" }, t.waterSystem, ":"), /* @__PURE__ */ React.createElement(
    "select",
    {
      value: currentProject.waterSystem,
      onChange: (e) => setCurrentProject({ ...currentProject, waterSystem: e.target.value }),
      className: "w-full p-3 rounded-lg bg-white/20 text-white border border-white/30"
    },
    waterSystems[language].map((system) => /* @__PURE__ */ React.createElement("option", { key: system, value: system, className: "bg-gray-800" }, system))
  )), /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-2 gap-4" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("label", { className: "block text-white mb-2" }, t.budget, ":"), /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "number",
      value: currentProject.budget,
      onChange: (e) => setCurrentProject({ ...currentProject, budget: parseInt(e.target.value) || 0 }),
      className: "w-full p-3 rounded-lg bg-white/20 text-white border border-white/30"
    }
  )), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("label", { className: "block text-white mb-2" }, t.timeline, ":"), /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "number",
      value: currentProject.timeline,
      onChange: (e) => setCurrentProject({ ...currentProject, timeline: parseInt(e.target.value) || 0 }),
      className: "w-full p-3 rounded-lg bg-white/20 text-white border border-white/30"
    }
  ))), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: calculateProject,
      className: "w-full bg-gradient-to-r from-green-500 to-blue-500 text-white p-4 rounded-lg font-bold hover:from-green-600 hover:to-blue-600 transition-all"
    },
    "\u{1F504} ",
    t.calculate
  ))), /* @__PURE__ */ React.createElement("div", { className: "bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20" }, /* @__PURE__ */ React.createElement("h2", { className: "text-2xl font-bold text-white mb-6" }, "\u{1F4CA} ", t.results), calculations.energyNeeds && /* @__PURE__ */ React.createElement("div", { className: "space-y-4" }, /* @__PURE__ */ React.createElement("div", { className: "bg-green-500/20 p-4 rounded-lg border border-green-400" }, /* @__PURE__ */ React.createElement("h3", { className: "text-green-300 font-bold mb-2" }, "\u26A1 \u042D\u043D\u0435\u0440\u0433\u0435\u0442\u0438\u043A\u0430"), /* @__PURE__ */ React.createElement("p", { className: "text-white" }, "\u041F\u043E\u0442\u0440\u0435\u0431\u043D\u043E\u0441\u0442\u044C: ", calculations.energyNeeds, " \u043A\u0412\u0442/\u0447"), /* @__PURE__ */ React.createElement("p", { className: "text-white" }, "\u0421\u043E\u043B\u043D\u0435\u0447\u043D\u044B\u0435 \u043F\u0430\u043D\u0435\u043B\u0438: ", calculations.solarPanels, " \u0448\u0442")), /* @__PURE__ */ React.createElement("div", { className: "bg-blue-500/20 p-4 rounded-lg border border-blue-400" }, /* @__PURE__ */ React.createElement("h3", { className: "text-blue-300 font-bold mb-2" }, "\u{1F4A7} \u0412\u043E\u0434\u043E\u0441\u043D\u0430\u0431\u0436\u0435\u043D\u0438\u0435"), /* @__PURE__ */ React.createElement("p", { className: "text-white" }, "\u041F\u043E\u0442\u0440\u0435\u0431\u043D\u043E\u0441\u0442\u044C: ", calculations.waterNeeds, " \u043B/\u0434\u0435\u043D\u044C"), /* @__PURE__ */ React.createElement("p", { className: "text-white" }, "\u0421\u0438\u0441\u0442\u0435\u043C\u0430: ", currentProject.waterSystem)), /* @__PURE__ */ React.createElement("div", { className: "bg-yellow-500/20 p-4 rounded-lg border border-yellow-400" }, /* @__PURE__ */ React.createElement("h3", { className: "text-yellow-300 font-bold mb-2" }, "\u{1F4B0} \u042D\u043A\u043E\u043D\u043E\u043C\u0438\u043A\u0430"), /* @__PURE__ */ React.createElement("p", { className: "text-white" }, "\u0421\u0442\u0440\u043E\u0438\u0442\u0435\u043B\u044C\u0441\u0442\u0432\u043E: $", calculations.constructionCost.toLocaleString()), /* @__PURE__ */ React.createElement("p", { className: "text-white" }, "\u042D\u043A\u0441\u043F\u043B\u0443\u0430\u0442\u0430\u0446\u0438\u044F: $", calculations.operationalCost.toLocaleString(), "/\u0433\u043E\u0434"), /* @__PURE__ */ React.createElement("p", { className: "text-white" }, "ROI: ", calculations.roi, "%")), /* @__PURE__ */ React.createElement("div", { className: "bg-purple-500/20 p-4 rounded-lg border border-purple-400" }, /* @__PURE__ */ React.createElement("h3", { className: "text-purple-300 font-bold mb-2" }, "\u{1F331} \u042D\u043A\u043E\u043B\u043E\u0433\u0438\u044F"), /* @__PURE__ */ React.createElement("p", { className: "text-white" }, "\u0421\u043D\u0438\u0436\u0435\u043D\u0438\u0435 CO\u2082: ", calculations.co2Reduction, " \u0442\u043E\u043D\u043D/\u0433\u043E\u0434"), /* @__PURE__ */ React.createElement("p", { className: "text-white" }, "\u041A\u043B\u0430\u0441\u0441 \u044D\u0444\u0444\u0435\u043A\u0442\u0438\u0432\u043D\u043E\u0441\u0442\u0438: A+")), /* @__PURE__ */ React.createElement("div", { className: "bg-orange-500/20 p-4 rounded-lg border border-orange-400" }, /* @__PURE__ */ React.createElement("h3", { className: "text-orange-300 font-bold mb-2" }, "\u23F1\uFE0F \u0421\u0440\u043E\u043A\u0438"), /* @__PURE__ */ React.createElement("p", { className: "text-white" }, "\u041E\u043F\u0442\u0438\u043C\u0438\u0437\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0439 \u0441\u0440\u043E\u043A: ", calculations.timelineOptimized, " \u043C\u0435\u0441\u044F\u0446\u0435\u0432"), /* @__PURE__ */ React.createElement("p", { className: "text-white" }, "\u042D\u043A\u043E\u043D\u043E\u043C\u0438\u044F \u0432\u0440\u0435\u043C\u0435\u043D\u0438: ", currentProject.timeline - calculations.timelineOptimized, " \u043C\u0435\u0441\u044F\u0446\u0435\u0432")), /* @__PURE__ */ React.createElement("div", { className: "bg-gray-500/20 p-4 rounded-lg border border-gray-400" }, /* @__PURE__ */ React.createElement("h3", { className: "text-gray-300 font-bold mb-2" }, "\u{1F3D7}\uFE0F \u0410\u0440\u0445\u0438\u0442\u0435\u043A\u0442\u0443\u0440\u0430"), /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-3 gap-2 text-center" }, /* @__PURE__ */ React.createElement("div", { className: "bg-green-600/40 p-2 rounded" }, /* @__PURE__ */ React.createElement("div", { className: "text-2xl" }, "\u{1F333}"), /* @__PURE__ */ React.createElement("div", { className: "text-xs text-white" }, "\u0417\u0435\u043B\u0435\u043D\u0430\u044F \u0437\u043E\u043D\u0430")), /* @__PURE__ */ React.createElement("div", { className: "bg-blue-600/40 p-2 rounded" }, /* @__PURE__ */ React.createElement("div", { className: "text-2xl" }, "\u{1F3E2}"), /* @__PURE__ */ React.createElement("div", { className: "text-xs text-white" }, "\u0413\u043B\u0430\u0432\u043D\u043E\u0435 \u0437\u0434\u0430\u043D\u0438\u0435")), /* @__PURE__ */ React.createElement("div", { className: "bg-yellow-600/40 p-2 rounded" }, /* @__PURE__ */ React.createElement("div", { className: "text-2xl" }, "\u2600\uFE0F"), /* @__PURE__ */ React.createElement("div", { className: "text-xs text-white" }, "\u0421\u043E\u043B\u043D. \u043F\u0430\u043D\u0435\u043B\u0438"))))))), /* @__PURE__ */ React.createElement("div", { className: "text-center mt-8 text-white/80" }, /* @__PURE__ */ React.createElement("div", { className: "bg-yellow-400/20 rounded-lg p-4 border border-yellow-400/30" }, /* @__PURE__ */ React.createElement("p", { className: "font-bold" }, "\u{1F9EC} TERRA v6.0 QUANTUM ARCHITECTURE ENGINE"), /* @__PURE__ */ React.createElement("p", null, "CREATOR: \u0410\u0431\u0434\u0443\u0440\u0430\u0448\u0438\u0434 \u0410\u0431\u0434\u0443\u043A\u0430\u0440\u0438\u043C\u043E\u0432 | secret.uzbek@tutamail.com"), /* @__PURE__ */ React.createElement("p", null, "\u0421\u043F\u0435\u0446\u0438\u0430\u043B\u044C\u043D\u043E \u0434\u043B\u044F \u0437\u0435\u043B\u0435\u043D\u044B\u0445 \u0441\u0442\u0430\u043D\u0446\u0438\u0439 \u0423\u0437\u0431\u0435\u043A\u0438\u0441\u0442\u0430\u043D\u0430 | ", (/* @__PURE__ */ new Date()).toLocaleString("ru-RU"))))));
};
var stdin_default = GreenStationPlanner;
export {
  stdin_default as default
};
