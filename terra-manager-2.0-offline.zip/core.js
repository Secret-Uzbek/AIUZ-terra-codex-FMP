
const fileInput = document.getElementById('file-input');
const fileList = document.getElementById('file-list');
const thesaurus = document.getElementById('thesaurus');

fileInput.addEventListener('change', event => {
  const files = Array.from(event.target.files);
  files.forEach(file => {
    const li = document.createElement('li');
    li.textContent = file.name + ' (' + file.type + ')';
    fileList.appendChild(li);
    const reader = new FileReader();
    reader.onload = e => {
      const text = e.target.result;
      const terms = extractTerms(text);
      terms.forEach(term => {
        const item = document.createElement('li');
        item.textContent = term;
        thesaurus.appendChild(item);
      });
      saveToLocal(file.name, text, terms);
    };
    if (file.type.startsWith('text')) {
      reader.readAsText(file);
    } else {
      console.log('Unsupported type: ' + file.type);
    }
  });
});

function extractTerms(text) {
  const words = text.toLowerCase().match(/\b[a-zа-яё]{5,}\b/gi);
  const freq = {};
  if (!words) return [];
  words.forEach(w => freq[w] = (freq[w] || 0) + 1);
  return Object.keys(freq).sort((a, b) => freq[b] - freq[a]).slice(0, 20);
}

function saveToLocal(filename, content, terms) {
  const db = JSON.parse(localStorage.getItem('terra_core') || '{}');
  db[filename] = { content, terms, date: new Date().toISOString() };
  localStorage.setItem('terra_core', JSON.stringify(db));
}
