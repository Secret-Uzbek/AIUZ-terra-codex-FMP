// <stdin>
import React, { useState, useEffect } from "https://esm.sh/react@18.2.0";
var FMPPublicationStrategy = () => {
  const [activePhase, setActivePhase] = useState("phase1");
  const [completedTasks, setCompletedTasks] = useState(/* @__PURE__ */ new Set());
  const [timeRemaining, setTimeRemaining] = useState({});
  const phases = {
    phase1: {
      title: "Preprint & Open Access",
      timeline: "0-3 months",
      color: "bg-green-500",
      platforms: [
        { name: "arXiv", format: "PDF + LaTeX", audience: "International researchers", status: "ready" },
        { name: "ResearchGate", format: "PDF + materials", audience: "Academic network", status: "ready" },
        { name: "Academia.edu", format: "Formatted chapters", audience: "Broader academic", status: "ready" },
        { name: "SSRN", format: "Social science focus", audience: "Policy researchers", status: "ready" }
      ]
    },
    phase2: {
      title: "Peer-Reviewed Journals",
      timeline: "3-18 months",
      color: "bg-blue-500",
      platforms: [
        { name: "Complexity", impact: "2.3", focus: "Complex systems", status: "targeting" },
        { name: "Systems Research", impact: "1.8", focus: "Systems thinking", status: "targeting" },
        { name: "Futures", impact: "3.0", focus: "Future studies", status: "targeting" },
        { name: "AI & Society", impact: "3.5", focus: "AI ethics/philosophy", status: "targeting" }
      ]
    },
    phase3: {
      title: "Russian Academic Integration",
      timeline: "6-12 months",
      color: "bg-purple-500",
      platforms: [
        { name: "\u0412\u043E\u043F\u0440\u043E\u0441\u044B \u0444\u0438\u043B\u043E\u0441\u043E\u0444\u0438\u0438", focus: "Philosophical foundations", status: "translation-needed" },
        { name: "\u041E\u0431\u0440\u0430\u0437\u043E\u0432\u0430\u043D\u0438\u0435 \u0438 \u043D\u0430\u0443\u043A\u0430", focus: "Educational applications", status: "translation-needed" },
        { name: "\u0418\u0441\u043A\u0443\u0441\u0441\u0442\u0432\u0435\u043D\u043D\u044B\u0439 \u0438\u043D\u0442\u0435\u043B\u043B\u0435\u043A\u0442", focus: "AI applications", status: "translation-needed" },
        { name: "\u0421\u0438\u0441\u0442\u0435\u043C\u043D\u044B\u0439 \u0430\u043D\u0430\u043B\u0438\u0437", focus: "Systems thinking", status: "translation-needed" }
      ]
    },
    phase4: {
      title: "Central Asian Integration",
      timeline: "12+ months",
      color: "bg-orange-500",
      platforms: [
        { name: "\u041D\u0423\u0423\u0437 \u0438\u043C. \u041C\u0438\u0440\u0437\u043E \u0423\u043B\u0443\u0433\u0431\u0435\u043A\u0430", focus: "National University", status: "cultural-adaptation" },
        { name: "\u0422\u0423\u0418\u0422", focus: "IT University", status: "cultural-adaptation" },
        { name: "\u0423\u0437\u0431\u0435\u043A\u0441\u043A\u0438\u0439 \u0436\u0443\u0440\u043D\u0430\u043B \u043E\u0431\u0440\u0430\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u044B\u0445 \u0442\u0435\u0445\u043D\u043E\u043B\u043E\u0433\u0438\u0439", focus: "Educational Technology", status: "cultural-adaptation" }
      ]
    }
  };
  const conferences = [
    { name: "NetSci 2025", date: "May 2025", location: "Vienna", deadline: "January 2025", relevance: "Network science", priority: "high" },
    { name: "ICCS 2025", date: "June 2025", location: "Barcelona", deadline: "February 2025", relevance: "Complex systems", priority: "high" },
    { name: "AERA 2025", date: "April 2025", location: "Chicago", deadline: "October 2024", relevance: "Educational applications", priority: "medium" },
    { name: "AIES 2025", date: "August 2025", location: "Berkeley", deadline: "March 2025", relevance: "AI ethics", priority: "high" }
  ];
  const immediateActions = [
    { task: "arXiv submission preparation", timeframe: "This Week", priority: "critical", completed: false },
    { task: "Journal target list refinement", timeframe: "This Week", priority: "high", completed: false },
    { task: "Network activation", timeframe: "This Week", priority: "high", completed: false },
    { task: "Conference submissions", timeframe: "This Month", priority: "medium", completed: false },
    { task: "Peer review registration", timeframe: "This Month", priority: "medium", completed: false },
    { task: "Collaboration outreach", timeframe: "This Month", priority: "medium", completed: false }
  ];
  const successMetrics = {
    quantitative: [
      { metric: "Citation count", target: "100+ in first year", current: "0" },
      { metric: "Downloads/views", target: "10,000+ views", current: "0" },
      { metric: "H-index contribution", target: "+3 points", current: "0" },
      { metric: "Media mentions", target: "50+ mentions", current: "0" }
    ],
    qualitative: [
      { metric: "Keynote invitations", status: "pending" },
      { metric: "Editorial board appointments", status: "pending" },
      { metric: "Collaboration requests", status: "pending" },
      { metric: "Course adoptions", status: "pending" }
    ]
  };
  const toggleTask = (index) => {
    const newCompleted = new Set(completedTasks);
    if (newCompleted.has(index)) {
      newCompleted.delete(index);
    } else {
      newCompleted.add(index);
    }
    setCompletedTasks(newCompleted);
  };
  const getStatusColor = (status) => {
    switch (status) {
      case "ready":
        return "bg-green-100 text-green-800";
      case "targeting":
        return "bg-blue-100 text-blue-800";
      case "translation-needed":
        return "bg-purple-100 text-purple-800";
      case "cultural-adaptation":
        return "bg-orange-100 text-orange-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };
  const getPriorityColor = (priority) => {
    switch (priority) {
      case "critical":
        return "bg-red-100 text-red-800 border-red-300";
      case "high":
        return "bg-orange-100 text-orange-800 border-orange-300";
      case "medium":
        return "bg-yellow-100 text-yellow-800 border-yellow-300";
      default:
        return "bg-gray-100 text-gray-800 border-gray-300";
    }
  };
  return /* @__PURE__ */ React.createElement("div", { className: "max-w-7xl mx-auto p-6 bg-gradient-to-br from-indigo-50 to-purple-50 min-h-screen" }, /* @__PURE__ */ React.createElement("div", { className: "mb-8 text-center" }, /* @__PURE__ */ React.createElement("h1", { className: "text-4xl font-bold text-gray-800 mb-4" }, "\u{1F30D} FMP Global Publication Strategy"), /* @__PURE__ */ React.createElement("p", { className: "text-lg text-gray-600 mb-4" }, "Fractal Metascience Paradigm: Strategic Dissemination for Scientific Revolution"), /* @__PURE__ */ React.createElement("div", { className: "bg-white rounded-lg p-4 shadow-lg inline-block" }, /* @__PURE__ */ React.createElement("div", { className: "text-2xl font-bold text-indigo-600" }, "127+ References \u2022 50K+ Words \u2022 4 Publication Phases"))), /* @__PURE__ */ React.createElement("div", { className: "mb-8" }, /* @__PURE__ */ React.createElement("div", { className: "flex flex-wrap justify-center gap-2" }, Object.entries(phases).map(([key, phase]) => /* @__PURE__ */ React.createElement(
    "button",
    {
      key,
      onClick: () => setActivePhase(key),
      className: `px-6 py-3 rounded-lg font-semibold transition-all ${activePhase === key ? `${phase.color} text-white shadow-lg transform scale-105` : "bg-white text-gray-700 hover:bg-gray-100 shadow-md"}`
    },
    /* @__PURE__ */ React.createElement("div", { className: "text-sm opacity-75" }, phase.timeline),
    /* @__PURE__ */ React.createElement("div", null, phase.title)
  )))), /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8" }, /* @__PURE__ */ React.createElement("div", { className: "lg:col-span-2" }, /* @__PURE__ */ React.createElement("div", { className: "bg-white rounded-lg shadow-lg p-6" }, /* @__PURE__ */ React.createElement("h2", { className: "text-2xl font-bold text-gray-800 mb-4 flex items-center" }, /* @__PURE__ */ React.createElement("div", { className: `w-4 h-4 rounded-full ${phases[activePhase].color} mr-3` }), phases[activePhase].title), /* @__PURE__ */ React.createElement("div", { className: "space-y-4" }, phases[activePhase].platforms.map((platform, index) => /* @__PURE__ */ React.createElement("div", { key: index, className: "border rounded-lg p-4 hover:shadow-md transition-shadow" }, /* @__PURE__ */ React.createElement("div", { className: "flex justify-between items-start mb-2" }, /* @__PURE__ */ React.createElement("h3", { className: "font-semibold text-gray-800" }, platform.name), /* @__PURE__ */ React.createElement("span", { className: `px-2 py-1 rounded-full text-xs ${getStatusColor(platform.status)}` }, platform.status.replace("-", " "))), /* @__PURE__ */ React.createElement("div", { className: "text-sm text-gray-600" }, platform.format && /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("strong", null, "Format:"), " ", platform.format), platform.audience && /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("strong", null, "Audience:"), " ", platform.audience), platform.impact && /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("strong", null, "Impact Factor:"), " ", platform.impact), platform.focus && /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("strong", null, "Focus:"), " ", platform.focus))))))), /* @__PURE__ */ React.createElement("div", { className: "space-y-6" }, /* @__PURE__ */ React.createElement("div", { className: "bg-white rounded-lg shadow-lg p-6" }, /* @__PURE__ */ React.createElement("h3", { className: "text-lg font-bold text-gray-800 mb-4" }, "\u{1F4CA} Success Metrics"), /* @__PURE__ */ React.createElement("div", { className: "space-y-4" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h4", { className: "font-semibold text-green-600 mb-2" }, "Quantitative"), successMetrics.quantitative.map((metric, index) => /* @__PURE__ */ React.createElement("div", { key: index, className: "text-sm mb-2" }, /* @__PURE__ */ React.createElement("div", { className: "flex justify-between" }, /* @__PURE__ */ React.createElement("span", null, metric.metric), /* @__PURE__ */ React.createElement("span", { className: "text-gray-500" }, metric.current)), /* @__PURE__ */ React.createElement("div", { className: "text-xs text-gray-500" }, "Target: ", metric.target)))), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h4", { className: "font-semibold text-blue-600 mb-2" }, "Qualitative"), successMetrics.qualitative.map((metric, index) => /* @__PURE__ */ React.createElement("div", { key: index, className: "text-sm mb-2 flex justify-between" }, /* @__PURE__ */ React.createElement("span", null, metric.metric), /* @__PURE__ */ React.createElement("span", { className: "text-xs bg-gray-100 px-2 py-1 rounded" }, metric.status)))))), /* @__PURE__ */ React.createElement("div", { className: "bg-gradient-to-r from-purple-500 to-indigo-600 rounded-lg p-4 text-white" }, /* @__PURE__ */ React.createElement("h4", { className: "font-bold mb-2" }, "\u{1F4A1} Innovation"), /* @__PURE__ */ React.createElement("div", { className: "text-sm" }, /* @__PURE__ */ React.createElement("strong", null, '"Living Document" Strategy'), /* @__PURE__ */ React.createElement("ul", { className: "mt-2 text-xs opacity-90" }, /* @__PURE__ */ React.createElement("li", null, "\u2022 Version control"), /* @__PURE__ */ React.createElement("li", null, "\u2022 Community contributions"), /* @__PURE__ */ React.createElement("li", null, "\u2022 Recursive refinement"), /* @__PURE__ */ React.createElement("li", null, "\u2022 Multi-format adaptations")))))), /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8" }, /* @__PURE__ */ React.createElement("div", { className: "bg-white rounded-lg shadow-lg p-6" }, /* @__PURE__ */ React.createElement("h3", { className: "text-xl font-bold text-gray-800 mb-4" }, "\u{1F3AF} Target Conferences 2025"), /* @__PURE__ */ React.createElement("div", { className: "space-y-3" }, conferences.map((conf, index) => /* @__PURE__ */ React.createElement("div", { key: index, className: "border rounded-lg p-3 hover:shadow-md transition-shadow" }, /* @__PURE__ */ React.createElement("div", { className: "flex justify-between items-start mb-2" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h4", { className: "font-semibold" }, conf.name), /* @__PURE__ */ React.createElement("div", { className: "text-sm text-gray-600" }, conf.date, " \u2022 ", conf.location)), /* @__PURE__ */ React.createElement("span", { className: `px-2 py-1 rounded-full text-xs ${conf.priority === "high" ? "bg-red-100 text-red-800" : "bg-yellow-100 text-yellow-800"}` }, conf.priority)), /* @__PURE__ */ React.createElement("div", { className: "text-xs text-gray-500" }, /* @__PURE__ */ React.createElement("strong", null, "Deadline:"), " ", conf.deadline, " \u2022 ", /* @__PURE__ */ React.createElement("strong", null, "Focus:"), " ", conf.relevance))))), /* @__PURE__ */ React.createElement("div", { className: "bg-white rounded-lg shadow-lg p-6" }, /* @__PURE__ */ React.createElement("h3", { className: "text-xl font-bold text-gray-800 mb-4" }, "\u{1F680} Immediate Actions"), /* @__PURE__ */ React.createElement("div", { className: "space-y-3" }, immediateActions.map((action, index) => /* @__PURE__ */ React.createElement("div", { key: index, className: `border rounded-lg p-3 ${getPriorityColor(action.priority)}` }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center" }, /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "checkbox",
      checked: completedTasks.has(index),
      onChange: () => toggleTask(index),
      className: "mr-3 h-4 w-4"
    }
  ), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("div", { className: `font-medium ${completedTasks.has(index) ? "line-through opacity-60" : ""}` }, action.task), /* @__PURE__ */ React.createElement("div", { className: "text-xs opacity-75" }, action.timeframe))), /* @__PURE__ */ React.createElement("span", { className: "text-xs font-semibold uppercase tracking-wider" }, action.priority))))))), /* @__PURE__ */ React.createElement("div", { className: "bg-gradient-to-r from-green-500 to-blue-600 rounded-lg p-6 text-white text-center" }, /* @__PURE__ */ React.createElement("h2", { className: "text-2xl font-bold mb-4" }, "\u{1F31F} Strategic Revolution Status"), /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-1 md:grid-cols-4 gap-4 mb-4" }, /* @__PURE__ */ React.createElement("div", { className: "bg-white bg-opacity-20 rounded-lg p-3" }, /* @__PURE__ */ React.createElement("div", { className: "text-2xl font-bold" }, "4"), /* @__PURE__ */ React.createElement("div", { className: "text-sm" }, "Publication Phases")), /* @__PURE__ */ React.createElement("div", { className: "bg-white bg-opacity-20 rounded-lg p-3" }, /* @__PURE__ */ React.createElement("div", { className: "text-2xl font-bold" }, "15+"), /* @__PURE__ */ React.createElement("div", { className: "text-sm" }, "Target Journals")), /* @__PURE__ */ React.createElement("div", { className: "bg-white bg-opacity-20 rounded-lg p-3" }, /* @__PURE__ */ React.createElement("div", { className: "text-2xl font-bold" }, "4"), /* @__PURE__ */ React.createElement("div", { className: "text-sm" }, "Key Conferences")), /* @__PURE__ */ React.createElement("div", { className: "bg-white bg-opacity-20 rounded-lg p-3" }, /* @__PURE__ */ React.createElement("div", { className: "text-2xl font-bold" }, completedTasks.size, "/", immediateActions.length), /* @__PURE__ */ React.createElement("div", { className: "text-sm" }, "Tasks Complete"))), /* @__PURE__ */ React.createElement("p", { className: "text-lg opacity-90" }, "Following FMP principles: recursive refinement, fractal dissemination, living document evolution")));
};
var stdin_default = FMPPublicationStrategy;
export {
  stdin_default as default
};
