AIUZ / Terra Ecosystem Grant Package

This package contains the required documentation for grant submission, including:
- Executive summary
- Licensing terms
- Annotated descriptions
- Technical specs
- Research article

Version: 1.0
