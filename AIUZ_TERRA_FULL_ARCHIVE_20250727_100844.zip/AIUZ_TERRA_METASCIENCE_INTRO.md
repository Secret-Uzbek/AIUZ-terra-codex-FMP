# I. Introduction: Metascience and Recursive Foundations
(versioned content...)