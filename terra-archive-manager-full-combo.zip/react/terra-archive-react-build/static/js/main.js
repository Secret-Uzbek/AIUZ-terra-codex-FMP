document.getElementById('root').innerHTML = `
  <main style='font-family:sans-serif;padding:2rem;'>
    <h1>🌍 Terra Archive Manager React</h1>
    <p>Фронтенд-сборка загружена успешно!</p>
    <p>Это базовый React билд, работающий как обычная HTML-страница.</p>
  </main>
`;