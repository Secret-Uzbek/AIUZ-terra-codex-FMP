
document.getElementById('file-input').addEventListener('change', event => {
  const files = Array.from(event.target.files);
  const list = document.getElementById('file-list');
  const terms = document.getElementById('terms-list');
  const db = JSON.parse(localStorage.getItem('terra_core') || '{}');

  files.forEach(file => {
    const li = document.createElement('li');
    li.textContent = file.name;
    list.appendChild(li);

    if (file.type.startsWith('text')) {
      const reader = new FileReader();
      reader.onload = e => {
        const text = e.target.result;
        const words = text.toLowerCase().match(/\b[\wа-яё]{4,}\b/gi) || [];
        const freq = {};
        words.forEach(w => freq[w] = (freq[w] || 0) + 1);
        const top = Object.entries(freq).sort((a,b)=>b[1]-a[1]).slice(0, 10);
        db[file.name] = { content: text, terms: top.map(t => t[0]) };
        top.forEach(([word]) => {
          const t = document.createElement('li');
          t.textContent = word;
          terms.appendChild(t);
        });
        localStorage.setItem('terra_core', JSON.stringify(db));
      };
      reader.readAsText(file);
    }
  });
});
