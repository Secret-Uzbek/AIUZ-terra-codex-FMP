// Работа с изображениями, аудио, видео
console.log('Media Handler Ready');