// Энциклопедия: генерация статей
console.log('Encyclopedia Ready');