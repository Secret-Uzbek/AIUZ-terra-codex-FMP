// Парсер файлов (PDF, TXT, DOCX)
console.log('Parser Module Ready');