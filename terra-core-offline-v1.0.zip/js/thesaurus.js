// Тезаурус: ключевые слова и связи
console.log('Thesaurus Ready');