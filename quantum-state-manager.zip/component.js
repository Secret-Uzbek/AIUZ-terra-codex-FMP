// <stdin>
import React, { useState, useEffect } from "https://esm.sh/react@18.2.0";
var QuantumStateManager = () => {
  const [quantumState, setQuantumState] = useState({
    mode: "SUPERPOSITION",
    coherenceTime: 100,
    entanglementLevel: 85,
    measurementCount: 0,
    qubits: [
      { id: 1, state: "|0\u27E9 + |1\u27E9", probability: [0.7, 0.3], entangled: true },
      { id: 2, state: "|+\u27E9", probability: [0.5, 0.5], entangled: true },
      { id: 3, state: "|0\u27E9", probability: [1, 0], entangled: false },
      { id: 4, state: "|1\u27E9", probability: [0, 1], entangled: false },
      { id: 5, state: "|\u03C8\u27E9", probability: [0.6, 0.4], entangled: true }
    ],
    decoherenceRate: 2.3
  });
  const [animationActive, setAnimationActive] = useState(true);
  const [measurements, setMeasurements] = useState([]);
  useEffect(() => {
    if (quantumState.mode === "SUPERPOSITION" && animationActive) {
      const interval = setInterval(() => {
        setQuantumState((prev) => ({
          ...prev,
          coherenceTime: Math.max(0, prev.coherenceTime - prev.decoherenceRate),
          entanglementLevel: Math.max(0, prev.entanglementLevel - 0.5)
        }));
      }, 1e3);
      return () => clearInterval(interval);
    }
  }, [quantumState.mode, animationActive]);
  const switchQuantumMode = (newMode) => {
    setQuantumState((prev) => ({
      ...prev,
      mode: newMode,
      coherenceTime: newMode === "SUPERPOSITION" ? 100 : prev.coherenceTime,
      entanglementLevel: newMode === "ENTANGLEMENT" ? 95 : prev.entanglementLevel
    }));
  };
  const performQuantumMeasurement = () => {
    const measurementResult = quantumState.qubits.map((qubit) => ({
      qubitId: qubit.id,
      measuredState: Math.random() < qubit.probability[0] ? "|0\u27E9" : "|1\u27E9",
      probability: qubit.probability[0]
    }));
    const newMeasurement = {
      timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString(),
      results: measurementResult,
      coherenceBefore: quantumState.coherenceTime,
      entanglementBefore: quantumState.entanglementLevel
    };
    setMeasurements((prev) => [newMeasurement, ...prev.slice(0, 4)]);
    setQuantumState((prev) => ({
      ...prev,
      measurementCount: prev.measurementCount + 1,
      coherenceTime: Math.max(20, prev.coherenceTime - 15),
      entanglementLevel: Math.max(30, prev.entanglementLevel - 20),
      qubits: prev.qubits.map((qubit) => ({
        ...qubit,
        entangled: Math.random() > 0.3
      }))
    }));
  };
  const restoreQuantumState = () => {
    setQuantumState((prev) => ({
      ...prev,
      coherenceTime: 100,
      entanglementLevel: 85,
      qubits: prev.qubits.map((qubit) => ({
        ...qubit,
        entangled: qubit.id <= 2
      }))
    }));
  };
  const createEntanglement = () => {
    setQuantumState((prev) => ({
      ...prev,
      mode: "ENTANGLEMENT",
      entanglementLevel: Math.min(100, prev.entanglementLevel + 30),
      qubits: prev.qubits.map((qubit) => ({
        ...qubit,
        entangled: true,
        state: "|\u03C8\u27E9\u2297|\u03C6\u27E9"
      }))
    }));
  };
  const getModeColor = (mode) => {
    switch (mode) {
      case "SUPERPOSITION":
        return "text-purple-400 bg-purple-900";
      case "ENTANGLEMENT":
        return "text-blue-400 bg-blue-900";
      case "CLASSICAL":
        return "text-gray-400 bg-gray-700";
      case "MEASUREMENT":
        return "text-yellow-400 bg-yellow-900";
      default:
        return "text-purple-400 bg-purple-900";
    }
  };
  const getCoherenceColor = (coherence) => {
    if (coherence > 70) return "text-green-400";
    if (coherence > 40) return "text-yellow-400";
    return "text-red-400";
  };
  return /* @__PURE__ */ React.createElement("div", { className: "w-full h-full bg-gray-900 text-white p-6 overflow-auto", style: { minHeight: "700px" } }, /* @__PURE__ */ React.createElement("div", { className: "mb-6 text-center" }, /* @__PURE__ */ React.createElement("h1", { className: "text-2xl font-bold mb-2 text-cyan-400" }, "\u{1F300} QUANTUM STATE MANAGER"), /* @__PURE__ */ React.createElement("p", { className: "text-gray-400" }, "TerraMemoryDNA v5.0 Quantum Controller")), /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4 mb-6" }, /* @__PURE__ */ React.createElement("div", { className: "bg-gray-800 p-4 rounded-lg" }, /* @__PURE__ */ React.createElement("div", { className: "text-sm text-gray-400" }, "\u041A\u0432\u0430\u043D\u0442\u043E\u0432\u044B\u0439 \u0440\u0435\u0436\u0438\u043C"), /* @__PURE__ */ React.createElement("div", { className: `text-lg font-bold px-2 py-1 rounded mt-1 ${getModeColor(quantumState.mode)}` }, quantumState.mode)), /* @__PURE__ */ React.createElement("div", { className: "bg-gray-800 p-4 rounded-lg" }, /* @__PURE__ */ React.createElement("div", { className: "text-sm text-gray-400" }, "\u0412\u0440\u0435\u043C\u044F \u043A\u043E\u0433\u0435\u0440\u0435\u043D\u0442\u043D\u043E\u0441\u0442\u0438"), /* @__PURE__ */ React.createElement("div", { className: `text-xl font-bold ${getCoherenceColor(quantumState.coherenceTime)}` }, quantumState.coherenceTime.toFixed(1), "%")), /* @__PURE__ */ React.createElement("div", { className: "bg-gray-800 p-4 rounded-lg" }, /* @__PURE__ */ React.createElement("div", { className: "text-sm text-gray-400" }, "\u0423\u0440\u043E\u0432\u0435\u043D\u044C \u0437\u0430\u043F\u0443\u0442\u044B\u0432\u0430\u043D\u0438\u044F"), /* @__PURE__ */ React.createElement("div", { className: "text-xl font-bold text-blue-400" }, quantumState.entanglementLevel.toFixed(1), "%"))), /* @__PURE__ */ React.createElement("div", { className: "mb-6 bg-gray-800 p-4 rounded-lg" }, /* @__PURE__ */ React.createElement("h3", { className: "text-lg font-bold mb-3 text-cyan-400" }, "\u{1F52E} \u041A\u0432\u0430\u043D\u0442\u043E\u0432\u044B\u0435 \u0440\u0435\u0436\u0438\u043C\u044B"), /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-2 md:grid-cols-4 gap-2" }, ["SUPERPOSITION", "ENTANGLEMENT", "CLASSICAL", "MEASUREMENT"].map((mode) => /* @__PURE__ */ React.createElement(
    "button",
    {
      key: mode,
      onClick: () => switchQuantumMode(mode),
      className: `p-3 rounded transition-colors ${quantumState.mode === mode ? getModeColor(mode) : "bg-gray-700 text-gray-300 hover:bg-gray-600"}`
    },
    /* @__PURE__ */ React.createElement("div", { className: "text-xs font-medium" }, mode)
  )))), /* @__PURE__ */ React.createElement("div", { className: "mb-6 bg-gray-800 p-4 rounded-lg" }, /* @__PURE__ */ React.createElement("h3", { className: "text-lg font-bold mb-3 text-cyan-400" }, "\u269B\uFE0F \u0421\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0435 \u043A\u0443\u0431\u0438\u0442\u043E\u0432"), /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-1 md:grid-cols-5 gap-3" }, quantumState.qubits.map((qubit) => /* @__PURE__ */ React.createElement("div", { key: qubit.id, className: "bg-gray-700 p-3 rounded" }, /* @__PURE__ */ React.createElement("div", { className: "text-center mb-2" }, /* @__PURE__ */ React.createElement("div", { className: "text-lg font-bold text-purple-400" }, "Q", qubit.id)), /* @__PURE__ */ React.createElement("div", { className: "text-center mb-2" }, /* @__PURE__ */ React.createElement("div", { className: "text-sm text-yellow-400 font-mono" }, qubit.state)), /* @__PURE__ */ React.createElement("div", { className: "flex justify-between text-xs text-gray-400" }, /* @__PURE__ */ React.createElement("span", null, "|0\u27E9: ", (qubit.probability[0] * 100).toFixed(0), "%"), /* @__PURE__ */ React.createElement("span", null, "|1\u27E9: ", (qubit.probability[1] * 100).toFixed(0), "%")), /* @__PURE__ */ React.createElement("div", { className: "mt-2 text-center" }, /* @__PURE__ */ React.createElement("span", { className: `text-xs px-2 py-1 rounded ${qubit.entangled ? "bg-blue-600 text-white" : "bg-gray-600 text-gray-300"}` }, qubit.entangled ? "\u0417\u0410\u041F\u0423\u0422\u0410\u041D" : "\u0421\u0412\u041E\u0411\u041E\u0414\u0415\u041D")))))), /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6" }, /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: performQuantumMeasurement,
      className: "bg-yellow-600 hover:bg-yellow-700 p-4 rounded-lg transition-colors"
    },
    /* @__PURE__ */ React.createElement("div", { className: "font-bold" }, "\u{1F4CF} \u0418\u0437\u043C\u0435\u0440\u0435\u043D\u0438\u0435"),
    /* @__PURE__ */ React.createElement("div", { className: "text-sm text-yellow-200" }, "\u041A\u043E\u043B\u043B\u0430\u043F\u0441 \u0441\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u044F")
  ), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: createEntanglement,
      className: "bg-blue-600 hover:bg-blue-700 p-4 rounded-lg transition-colors"
    },
    /* @__PURE__ */ React.createElement("div", { className: "font-bold" }, "\u{1F517} \u0417\u0430\u043F\u0443\u0442\u044B\u0432\u0430\u043D\u0438\u0435"),
    /* @__PURE__ */ React.createElement("div", { className: "text-sm text-blue-200" }, "\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u0441\u0432\u044F\u0437\u0438")
  ), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: restoreQuantumState,
      className: "bg-green-600 hover:bg-green-700 p-4 rounded-lg transition-colors"
    },
    /* @__PURE__ */ React.createElement("div", { className: "font-bold" }, "\u{1F504} \u0412\u043E\u0441\u0441\u0442\u0430\u043D\u043E\u0432\u0438\u0442\u044C"),
    /* @__PURE__ */ React.createElement("div", { className: "text-sm text-green-200" }, "\u0421\u0431\u0440\u043E\u0441 \u0441\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u044F")
  ), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => setAnimationActive(!animationActive),
      className: `p-4 rounded-lg transition-colors ${animationActive ? "bg-red-600 hover:bg-red-700" : "bg-gray-600 hover:bg-gray-700"}`
    },
    /* @__PURE__ */ React.createElement("div", { className: "font-bold" }, "\u23F8\uFE0F ", animationActive ? "\u041F\u0430\u0443\u0437\u0430" : "\u0421\u0442\u0430\u0440\u0442"),
    /* @__PURE__ */ React.createElement("div", { className: "text-sm text-gray-200" }, "\u0414\u0435\u043A\u043E\u0433\u0435\u0440\u0435\u043D\u0446\u0438\u044F")
  )), /* @__PURE__ */ React.createElement("div", { className: "bg-gray-800 p-4 rounded-lg mb-6" }, /* @__PURE__ */ React.createElement("h3", { className: "text-lg font-bold mb-3 text-cyan-400" }, "\u{1F4CA} \u0418\u0441\u0442\u043E\u0440\u0438\u044F \u043A\u0432\u0430\u043D\u0442\u043E\u0432\u044B\u0445 \u0438\u0437\u043C\u0435\u0440\u0435\u043D\u0438\u0439"), measurements.length === 0 ? /* @__PURE__ */ React.createElement("div", { className: "text-gray-400 text-center py-4" }, "\u0418\u0437\u043C\u0435\u0440\u0435\u043D\u0438\u0439 \u043F\u043E\u043A\u0430 \u043D\u0435 \u043F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u0438\u043B\u043E\u0441\u044C") : /* @__PURE__ */ React.createElement("div", { className: "space-y-3 max-h-48 overflow-y-auto" }, measurements.map((measurement, index) => /* @__PURE__ */ React.createElement("div", { key: index, className: "bg-gray-700 p-3 rounded" }, /* @__PURE__ */ React.createElement("div", { className: "flex justify-between items-center mb-2" }, /* @__PURE__ */ React.createElement("span", { className: "text-sm text-gray-400" }, measurement.timestamp), /* @__PURE__ */ React.createElement("span", { className: "text-xs text-yellow-400" }, "\u0418\u0437\u043C\u0435\u0440\u0435\u043D\u0438\u0435 #", quantumState.measurementCount - index)), /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-5 gap-2" }, measurement.results.map((result, i) => /* @__PURE__ */ React.createElement("div", { key: i, className: "text-center" }, /* @__PURE__ */ React.createElement("div", { className: "text-xs text-gray-400" }, "Q", result.qubitId), /* @__PURE__ */ React.createElement("div", { className: "text-sm font-mono text-purple-400" }, result.measuredState)))))))), /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-2 md:grid-cols-4 gap-4" }, /* @__PURE__ */ React.createElement("div", { className: "bg-gray-800 p-3 rounded text-center" }, /* @__PURE__ */ React.createElement("div", { className: "text-2xl font-bold text-purple-400" }, quantumState.measurementCount), /* @__PURE__ */ React.createElement("div", { className: "text-sm text-gray-400" }, "\u0418\u0437\u043C\u0435\u0440\u0435\u043D\u0438\u0439")), /* @__PURE__ */ React.createElement("div", { className: "bg-gray-800 p-3 rounded text-center" }, /* @__PURE__ */ React.createElement("div", { className: "text-2xl font-bold text-blue-400" }, quantumState.qubits.filter((q) => q.entangled).length), /* @__PURE__ */ React.createElement("div", { className: "text-sm text-gray-400" }, "\u0417\u0430\u043F\u0443\u0442\u0430\u043D\u043D\u044B\u0445")), /* @__PURE__ */ React.createElement("div", { className: "bg-gray-800 p-3 rounded text-center" }, /* @__PURE__ */ React.createElement("div", { className: "text-2xl font-bold text-green-400" }, quantumState.decoherenceRate.toFixed(1)), /* @__PURE__ */ React.createElement("div", { className: "text-sm text-gray-400" }, "\u0414\u0435\u043A\u043E\u0433\u0435\u0440\u0435\u043D\u0446\u0438\u044F")), /* @__PURE__ */ React.createElement("div", { className: "bg-gray-800 p-3 rounded text-center" }, /* @__PURE__ */ React.createElement("div", { className: "text-2xl font-bold text-cyan-400" }, "v5.0"), /* @__PURE__ */ React.createElement("div", { className: "text-sm text-gray-400" }, "\u0412\u0435\u0440\u0441\u0438\u044F"))), /* @__PURE__ */ React.createElement("div", { className: "mt-6 text-center text-xs text-gray-500" }, "Quantum State Manager | TerraMemoryDNA v5.0 | secret.uzbek@tutamail.com"));
};
var stdin_default = QuantumStateManager;
export {
  stdin_default as default
};
